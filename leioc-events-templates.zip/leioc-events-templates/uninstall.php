<?php

 /**
  *
  *This file unistalls the LEIOC Events plugin
  *
  *@package leioc-events-plugin 
  */

// Exit if accessed directly.
defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

//Clear stored data