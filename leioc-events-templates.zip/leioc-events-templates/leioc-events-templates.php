<?php
 /**
  *
  *@package leioc-events-plugin
  *
  *
  *Plugin Name: LEIOC Events Database
  *Description: This plugin works with the Genesis Custom Blocks plugin or Shortcodes and the LEIOC events and results databases to create Gutenberg Event and Reults Blocks.
  *Version: 0.1.2
  *Author: Roger Phillips
  *Requires PHP: 7.3.1
  *License: GPLv2 or later
  *Text Domain: leioc-events-plugin
  *
*/

/* 
Copyright (C) 2021  Roger Phillips

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

//Require once the Composer Autoload
if ( file_exists( dirname( __FILE__ ) . '/vendor/autoload.php') ) {
    require_once dirname( __FILE__ ) . '/vendor/autoload.php' ;
}

// WP_List_Table is not loaded automatically so we need to load it in our application
if( ! class_exists( 'WP_List_Table' ) ) {
    require_once( ABSPATH . 'wp-admin/includes/class-wp-list-table.php' );
}

/** 
 * The code that runs during plugin activation
*/
function activate_leioc_events_plugin(){
    LEIOCevents\Base\Activate::activate();
}
register_activation_hook( __FILE__ , 'activate_leioc_events_plugin' );

/** 
 * The code that runs during plugin deactivation
*/
function deactivate_leioc_events_plugin(){
    LEIOCevents\Base\Deactivate::deactivate();
}
register_deactivation_hook( __FILE__ , 'deactivate_leioc_events_plugin' );

/** 
 * The code registers leioc database tables
*/
function register_leioc_events_templates_database_tables(){
    LEIOCevents\Base\dbController::register();
}
register_activation_hook( __FILE__, 'register_leioc_events_templates_database_tables' );

/** 
 * The load fees data to leioc database tables
*/
function install_leioc_events_templates_database_data(){
    LEIOCevents\Base\dbController::install_fees();;
}
register_activation_hook( __FILE__, 'install_leioc_events_templates_database_data' );


if ( class_exists( 'LEIOCevents\\Init') ){
    LEIOCevents\Init::register_services();
}

/**
 * Adds an alternative path for Genesis Custom Blocks templates.
 *
 * @param string $path The path of Genesis Custom Blocks templates.
 * @return string $path The path of Genesis Custom Blocks templates.
 */
add_filter( 'genesis_custom_blocks_template_path', function( $path ) {
	unset( $path );
	return __DIR__;
} );