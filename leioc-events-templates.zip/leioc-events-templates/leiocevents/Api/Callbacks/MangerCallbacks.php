<?php
/**
* @package leioc-events-plugin
*
*/

namespace LEIOCevents\Api\Callbacks;

use \LEIOCevents\Base\BaseController;


class MangerCallbacks extends BaseController
{

  public function feesSanitize( $input )
  {
    $option = get_option( 'leioc_events_fees' );

    return sanitize_option( $option, $input );
  }

  public function feesSectionManger()
  {
    echo 'Manage events fees for all LEIOC events.';
  }

  public function textField( $args )
  {
    $name = $args['label_for'];
    $option_name = $args['option_name'];

    $value = '';
    $disabled = '';

    $type = isset($args['type']) ? $args['type']: 'text';
    $placeholder = isset($args['placeholder']) ? $args['placeholder'] : '';

    echo '<input type="'.$type.'" class="regular-text" id="' . $name . '" name="' . $name . '" value="' . $value . '" placeholder="' . $placeholder . '" required '.$disabled.'>';
  }
  
  public function textArea( $args )
  {
    $name = $args['label_for'];
    $option_name = $args['option_name'];

    $value = '';
    $disabled = '';

    echo '<textarea class="regular-text" id="' . $name . '" name="' . $name . '" placeholder="' . $args['placeholder'] . '" required '.$disabled.'>'.$value.'</textarea>';

  }

  public function optionField( $args )
  {
    $name = $args['label_for'];
    $option_name = $args['option_name'];

    $options = $args['options'];
    $selected = '';

    $option = '';
    foreach($options as $key => $value){
        $option .= '<option '.($selected == $key ? 'selected' : ( empty($selected) ? '' : 'disabled')).' value="'.$key.'">'.$value.'</option>';
    }

    echo '<select class="leioc-options '. ($selected == '' ? : 'disabled').'" id="'. $name.'" name="' . $name . '" required >'.$option.'</select>';
  }

}