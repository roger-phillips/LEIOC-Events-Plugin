<?php
/**
* @package leioc-events-plugin
*
*/

namespace LEIOCevents\Api\Callbacks;

use \LEIOCevents\Base\BaseController;


class AdminCallbacks extends BaseController
{
    public function adminDashboard(){
        return require_once( "$this->plugin_path/templates/admin-page.php" );
    }

    public function EventsDashboard(){
        return require_once( "$this->plugin_path/templates/events-page.php" );
    }

    public function settingsDashboard(){
        return require_once( "$this->plugin_path/templates/settings-page.php" );
    }

}