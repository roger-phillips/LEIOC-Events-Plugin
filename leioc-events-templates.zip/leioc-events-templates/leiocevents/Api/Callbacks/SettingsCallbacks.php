<?php
/**
* @package leioc-events-plugin
*
*/

namespace LEIOCevents\Api\Callbacks;

class SettingsCallbacks
{
    public function settingsSanitize( $input )
    {
        $option = get_option( 'leioc_events_settings' );

        return sanitize_option($option, $input);
    }

    public function leiocdatabaseSanitize( $input )
    {
        $option = get_option('leioc_events_database');
    
        return sanitize_option($option, $input);
    }

    public function settingsSectionManger()
    {
        echo 'Manage LEIOC event details.';
    }

    public function mapSectionManger()
    {
        echo 'Manage Google Maps API.';
    }

    public function databaseSectionManger()
    {
        echo 'Manage event and results database settings.';
    }

    public function textField( $args )
    {
        $name = $args['label_for'];
        $option_name = $args['option_name'];

        $input = get_option( $option_name );
        $value = isset($input[$name]) ? esc_attr($input[$name]) : '' ;

        $type = isset($args['type']) ? $args['type']: 'text';

        echo '<input type="'.$type.'" class="regular-text" id="' . $name . '" name="' . $option_name . '[' . $name . ']" value="' . $value . '" placeholder="' . $args['placeholder'] . '">';
    }

    public function textArea( $args )
    {
        $name = $args['label_for'];
        $option_name = $args['option_name'];

        $input = get_option( $option_name );
        $value = isset($input[$name]) ? esc_attr($input[$name]) : '' ;

        echo '<textarea class="regular-text" id="' . $name . '" name="' . $option_name . '[' . $name . '] placeholder="' . $args['placeholder'] . '">' . $value . '</textarea>';
    }

    public function checkboxField( $args )
	{
		$name = $args['label_for'];
		$classes = $args['class'];
		$option_name = $args['option_name'];
		$checkbox = get_option( $option_name );
		$checked = isset($checkbox[$name]) ?: false;

		echo '<div class="' . $classes . '"><input type="checkbox" id="' . $name . '" name="' . $option_name . '[' . $name . ']" value="1" class="" ' . ( $checked ? 'checked' : '') . '><label for="' . $name . '"><div></div></label></div>';
	}
}