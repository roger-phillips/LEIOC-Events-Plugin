<?php
/**
* @package leioc-events-plugin
*
*/

namespace LEIOCevents\Api;

final class LeiocDbCall
{
    protected $leioc_db_host;
    protected $leioc_db_user;
    protected $leioc_db_pass;
    protected $leioc_db_name;

    protected $charset;

    /**
     *
     * @param $args['var,var2, etc'] = variables to bind
     */
    public function bindDataQuery($sql, $args, $return = null){

        $connect = $this->connect();

        if($connect == false) return [];

        $stmt = $connect->prepare($sql);
        $stmt->execute($args);

        if(isset($return) ) return;

        $data = [];
        if($stmt->rowCount()){
            while($row = $stmt->fetch()) {
            array_push($data,$row);
            }
        }

        $connect = null;

        return $data;
    }

    public function connect(){

        $set = $this->setDatabase();

        if($set == false) return false;

        try { 
            $dsn = 'mysql:host='.$this->leioc_db_host.';dbname='.$this->leioc_db_name.';charset='.$this->charset;
            $conn = new \PDO($dsn, $this->leioc_db_user, $this->leioc_db_pass );
            $conn->setAttribute(\PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION);

            return $conn;

        } catch(\PDOException $e) {
                return false;
        }
    }

    public function dataquery($sql){

        $connect = $this->connect();

        if($connect == false) return [];

        $stmt = $connect->query($sql);

        $data = [];
        if($stmt->rowCount()){
            while($row = $stmt->fetch()) {
                array_push($data,$row);
            }
        }
        
        $connect = null;

        return $data;
    }

    private function setDatabase(){

        $settings = $this->checkSettings();

        if($settings == false) return false;

        $this->leioc_db_host = trim($settings['leioc_database_host']);
        $this->leioc_db_user = trim($settings['leioc_database_user']);
        $this->leioc_db_pass = trim($settings['leioc_database_password']);
        $this->leioc_db_name = trim($settings['leioc_database_name']);
        $this->charset = 'utf8mb4';

        return true;
    }

    private function checkSettings(){
        $settings = get_option('leioc_events_database');

        //Check if settings saved in Option Database
        if(empty($settings['leioc_database_host']) ) return false;
        if(empty($settings['leioc_database_user']) ) return false;
        if(empty($settings['leioc_database_password']) ) return false;
        if(empty($settings['leioc_database_name']) ) return false;

        return $settings;
    }

    public function checkDB(){

        if($this->checkSettings() === false) return false;
         
        return true;
    }
}