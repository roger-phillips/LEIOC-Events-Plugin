<?php
/**
*@package leioc-events-plugin
*
*/

namespace LEIOCevents\Api\Widgets;

use WP_Widget;
use \LEIOCevents\Api\LeiocDbCall;

class EventsWidget extends WP_Widget
{
    public $widget_ID;

    public $widget_name;

    public $widget_options = array();

    public $control_options = array();

    public function __construct()
    {
        $this->widget_ID = 'leioc_events_widget';

        $this->widget_name = 'LEIOC Events Widget';

        $this->widget_options = array(
            'classname' => $this->widget_ID,
            'description' => $this->widget_name,
            'customize_selective_refresh' => true
        );

        $this->control_options = array(
            'width' => 400,
            'height' => 350
        );

    }

    public function register()
    {
        parent::__construct( $this->widget_ID, $this->widget_name, $this->widget_options, $this->control_options );

        add_action( 'widgets_init', array( $this, 'leioc_events_widgetInit') );
    }

    public function leioc_events_widgetInit()
    {
        register_widget( $this );
    }

    public function widget( $args, $instance )
    {
        echo $args['before_widget'];

        if( !empty($instance['title']) ) echo $args['before_title'] . apply_filters( 'widget_title', $instance['title'] ) . $args['after_title'];

        $db = new LeiocDbCall();
        $options = get_option('leioc_events_settings' );

        $limit = intval(!empty($instance['search-limit']) ? $instance['search-limit'] : 8 );
        $display = intval(!empty($instance['display-limit']) ? $instance['display-limit'] : 1 );
        $inline = $instance['display-inline'] == 1 ? ' leioc-inline-block': '';

        $link = isset($options['event-details-url']) ? $options['event-details-url']: '';
        $str = explode('?',$link);
        $link = $str[0];

        $today = date('Y-m-d');
        $types = empty($inline) ? array('y','a','m') : array('all');

        foreach($types as $type){
            $search = $type == 'all' ? 'AND (event_flag = "y" OR event_flag = "a" OR event_flag = "m")' : 'AND event_flag ="'.$type.'"';

            $sql = "SELECT event_id, event_flag, event_date, event_title FROM events WHERE event_date >= '{$today}' {$search} ORDER BY event_date ASC  LIMIT {$limit}";

            $results = $db->dataquery($sql);

            $title = $type == 'a' ? $instance['act'] :($type == 'm' ? $instance['meet']:'');

            if( !empty($title) && empty($inline) ) echo $args['before_title'] . apply_filters( 'widget_title', $title ) . $args['after_title'];
            
            echo '<div class="leioc-results-widget-wrapper">';
            if(count($results) == 0 || count($results) <= $display) echo '<div>';

            $variables = array(
                'link'    => $link,
                'results' => $results,
                'display' => empty($inline) ? $display : $limit,
                'inline'  => $inline,
                'type'    => $type,
            );

           if(count($results) != 0) $this->leioc_add_events( $variables );

            echo $display >= $limit ? '':'</div>';
            echo '</div>';
        }

        echo $args['after_widget'];

    }

    public function form( $instance )
    {
        $title = !empty( $instance['title'] ) ? $instance['title'] : '';

        $titleID = esc_attr__( $this->get_field_id('title') );

        $act = !empty( $instance['act'] ) ? $instance['act'] : '';

        $actID = esc_attr__( $this->get_field_id('act') );

        $meet = !empty( $instance['meet'] ) ? $instance['meet'] : '';

        $meetID = esc_attr__( $this->get_field_id('meet') );

        $limit = !empty( $instance['search-limit'] ) ? $instance['search-limit'] : 8 ;

        $limitID = esc_attr__( $this->get_field_id('search-limit') );

        $display = !empty( $instance['display-limit'] ) ? $instance['display-limit'] : 1 ;

        $displayID = esc_attr__( $this->get_field_id('display-limit') );

        $inline = !empty( $instance['display-inline'] ) ? $instance['display-inline'] : false ;

        $inlineID = esc_attr__( $this->get_field_id('display-inline') );

    ?>
    <p>
        <label for="<?php echo $titleID; ?>">Main Title</label>
        <input type="text" class="widefat" id="<?php echo $titleID; ?>" name="<?php echo esc_attr__( $this->get_field_name('title') ); ?>" value="<?php echo esc_attr__($title); ?>">
    </p>
    <p>
        <label for="<?php echo $actID; ?>">Activities Title</label>
        <input type="text" class="widefat" id="<?php echo $actID; ?>" name="<?php echo esc_attr__( $this->get_field_name('act') ); ?>" value=" <?php echo esc_attr__($act); ?>">
    </p>
    <p>
        <label for="<?php echo $meetID; ?>">Meetings Title</label>
        <input type="text" class="widefat" id="<?php echo $meetID; ?>" name="<?php echo esc_attr__( $this->get_field_name('meet') ); ?>" value=" <?php echo esc_attr__($meet); ?>">
    </p>
    <p>
        <label for="<?php echo $limitID; ?>">Max No. of Results</label>
        <input type="number" class="widefat" id="<?php echo $limitID; ?>" name="<?php echo esc_attr__( $this->get_field_name('search-limit') ); ?>" value="<?php echo esc_attr__($limit); ?>" min="1" max="10">
    </p>
    <p class="leioc-widget-hide">
        <label for="<?php echo $displayID; ?>">Visible No. of Results on Mobile Devices</label>
        <input type="number" class="widefat" id="<?php echo $displayID; ?>" name="<?php echo esc_attr__( $this->get_field_name('display-limit') ); ?>" value="<?php echo esc_attr__($display); ?>" min="1" max="10">
    </p>
    <p>
        <input type="checkbox" class="leioc-widget-toggle" id="<?php echo $inlineID; ?>" name="<?php echo esc_attr__( $this->get_field_name('display-inline') ); ?>" value="1" <?php echo ( $inline ? 'checked':''); ?> >
        <label for="<?php echo $inlineID; ?>">Display Inline</label>
        <br><br>
        <i class="fas fa-info-circle"></i> Selecting Display Inline will remove all of the titles except the main title and will display all of the events in the database.
    </p>

    <?php
    }

    public function update( $new_instance, $old_instance)
    {
        $instance = $old_instance;

        $instance['title'] = (!empty($new_instance['title'] ) ? wp_strip_all_tags($new_instance['title']) : '');

        $instance['act'] = (!empty($new_instance['act'] ) ? wp_strip_all_tags($new_instance['act']) : '');

        $instance['meet'] = (!empty($new_instance['meet'] ) ? wp_strip_all_tags($new_instance['meet']) : '');

        $instance['search-limit'] = (!empty($new_instance['search-limit'] ) ? $new_instance['search-limit'] : 8);

        $instance['display-limit'] = (!empty($new_instance['display-limit'] ) ? $new_instance['display-limit'] : 1);

        $instance['display-inline'] = (!empty($new_instance['display-inline'] ) ? 1 : 0);

        return $instance;
    }

    public function leioc_add_events( $args )
    { 
        $link = $args['link'];
        $results = $args['results'];
        $display = $args['display'];
        $inline = $args['inline'];
        $type = $args['type'];

        $i = 0;

        foreach($results as $result)
        {
            $href = !empty($link) ? $link . '?item='.rawurlencode(' ' .$result['event_id']) : '';

            if($i == $display)
            {
                echo sprintf('<div class="leioc-results-widget-toggler" data-leioctarget="#%s-widget-collapse-%s">More <i class="fas fa-angle-down"></i></div>', $this->id, $type);
                echo sprintf('<div class="leioc-results-widget-collapse" id="%s-widget-collapse-%s">', $this->id, $type);
            }
    
            echo sprintf('<div class="leioc-results-widget%s"><div class="leioc-results-widget-title">%s</div>', $inline, date('l jS F', strtotime($result['event_date']) ));
            echo sprintf('<div><a href="%s">%s</a></div></div>', esc_url($href), $this->leiocHyphen($result['event_title']));

            $i++;
        }

    }

    public function leiocHyphen( $string )
    {
        $array = explode(' ',$string);

        foreach($array as $key => $word){
            if(strlen($word) >= 12 ) {
                $split = str_split($word, ceil (strlen($word)/2) );
                $array[$key] = '<span class="unbreakable">'.$split[0].'&shy;'.$split[1].'</span>';
            }
        }
        return join(' ',$array);
    }

}