<?php
/**
*@package leioc-events-plugin
*
*/

namespace LEIOCevents\Api\Widgets;

use WP_Widget;
use \LEIOCevents\Api\LeiocDbCall;

class ResultsWidget extends WP_Widget
{
    public $widget_ID;

    public $widget_name;

    public $widget_options = array();

    public $control_options = array();

    public function __construct()
    {
        $this->widget_ID = 'leioc_results_widget';
        $this->widget_name = 'LEIOC Results Widget';

        $this->widget_options = array(
            'classname' => $this->widget_ID,
            'description' => $this->widget_name,
            'customize_selective_refresh' => true
        );

        $this->control_options = array(
            'width' => 400,
            'height' => 350
        );

    }

    public function register()
    {
        parent::__construct( $this->widget_ID, $this->widget_name, $this->widget_options, $this->control_options );

        add_action( 'widgets_init', array( $this, 'leioc_results_widgetInit') );
    }

    public function leioc_results_widgetInit()
    {
        register_widget( $this );
    }

    public function widget( $args, $instance )
    {
        echo $args['before_widget'];

        if( !empty($instance['title']) ) echo $args['before_title'] . apply_filters( 'widget_title', $instance['title'] ) . $args['after_title'];

        if( !empty($instance['info']) )
        {
            echo '<div class="leioc-results-widget-info">';
            echo $instance['info'];
            echo '</div>';
        }

        $db = new LeiocDbCall();

        $limit = intval(!empty($instance['search-limit']) ? $instance['search-limit'] : 8 );
        $display = intval(!empty($instance['display-limit']) ? $instance['display-limit'] : 1 );
        $inline = $instance['display-inline'] == 1 ? ' leioc-inline-block': '';

        $display = ($instance['display-inline'] == 1 ? $limit : $display);

        $sql = "SELECT res_id, res_name, res_type, res_date, res_link FROM results ORDER BY res_date DESC, res_id ASC LIMIT {$limit}";

        $results = $db->dataquery($sql);
        $i = 0;

        echo '<div class="leioc-results-widget-wrapper">';
        if(count($results) == 0 || count($results) <= $display) echo '<div>';

        foreach($results as $result)
        {
            $type = '';

            if($i == $display){
   
                echo sprintf('<div class="leioc-results-widget-toggler" data-leioctarget="#%s-widget-collapse">More Results <i class="fas fa-angle-down"></i></i></div>', $this->id);
                echo sprintf('<div class="leioc-results-widget-collapse" id="%s-widget-collapse">', $this->id);
            }

            if($result['res_type'] == 'wl') $type = ' Winter League Event';
            if($result['res_type'] == 'sl') $type = ' Summer League Event';
    
            echo sprintf('<div class="leioc-results-widget%s"><div class="leioc-results-widget-title">%s</div>', $inline, date('l jS F', strtotime($result['res_date']) ));
            echo sprintf('<div><a href="%s">%s</a></div></div>', esc_url($result['res_link']), $this->leiocHyphen($result['res_name']) . $type);

            $i++;
        }

        echo $display >= $limit ? '':'</div>';
        echo '</div>';

        echo $args['after_widget'];
    }

    public function form( $instance )
    {
        $title = !empty( $instance['title'] ) ? $instance['title'] : '';

        $titleID = esc_attr__( $this->get_field_id('title') );

        $info = !empty( $instance['info'] ) ? $instance['info'] : '';

        $infoID = esc_attr__( $this->get_field_id('info') );

        $limit = !empty( $instance['search-limit'] ) ? $instance['search-limit'] : 8 ;

        $limitID = esc_attr__( $this->get_field_id('search-limit') );

        $display = !empty( $instance['display-limit'] ) ? $instance['display-limit'] : 1 ;

        $displayID = esc_attr__( $this->get_field_id('display-limit') );

        $inline = !empty( $instance['display-inline'] ) ? $instance['display-inline'] : false ;

        $inlineID = esc_attr__( $this->get_field_id('display-inline') );

    ?>
    <p>
        <label for="<?php echo $titleID; ?>">Title</label>
        <input type="text" class="widefat" id="<?php echo $titleID; ?>" name="<?php echo esc_attr__( $this->get_field_name('title') ); ?>" value="<?php echo esc_attr__($title); ?>">
    </p>
    <p>
        <label for="<?php echo $infoID; ?>">Information</label>
        <textarea class="widefat" id="<?php echo $infoID; ?>" name="<?php echo esc_attr__( $this->get_field_name('info') ); ?>"><?php echo esc_textarea($info); ?></textarea>
    </p>
    <p>
        <label for="<?php echo $limitID; ?>">Max No. of Results</label>
        <input type="number" class="widefat" id="<?php echo $limitID; ?>" name="<?php echo esc_attr__( $this->get_field_name('search-limit') ); ?>" value="<?php echo esc_attr__($limit); ?>" min="1" max="10">
    </p>
    <p class="leioc-widget-hide">
        <label for="<?php echo $displayID; ?>">Visible No. of Results on Mobile Devices</label>
        <input type="number" class="widefat" id="<?php echo $displayID; ?>" name="<?php echo esc_attr__( $this->get_field_name('display-limit') ); ?>" value="<?php echo esc_attr__($display); ?>" min="1" max="10">
    </p>
    <p>
        <input type="checkbox" class="leioc-widget-toggle" id="<?php echo $inlineID; ?>" name="<?php echo esc_attr__( $this->get_field_name('display-inline') ); ?>" value="1" <?php echo ( $inline ? 'checked':''); ?> >
        <label for="<?php echo $inlineID; ?>">Display Results Inline</label>
    </p>

    <?php
    }

    public function update( $new_instance, $old_instance)
    {
        $instance = $old_instance;

        $instance['title'] = (!empty($new_instance['title'] ) ? wp_strip_all_tags($new_instance['title']) : '');

        $instance['info'] = (!empty($new_instance['info'] ) ? $new_instance['info'] : '');

        $instance['search-limit'] = (!empty($new_instance['search-limit'] ) ? $new_instance['search-limit'] : 8);

        $instance['display-limit'] = (!empty($new_instance['display-limit'] ) ? $new_instance['display-limit'] : 1);

        $instance['display-inline'] = (!empty($new_instance['display-inline'] ) ? 1 : 0);

        return $instance;
    }

    public function leiocHyphen( $string )
    {
        $array = explode(' ',$string);

        foreach($array as $key => $word){
            if(strlen($word) >= 12 ) {
                $split = str_split($word, ceil (strlen($word)/2) );
                $array[$key] = '<span class="unbreakable">'.$split[0].'&shy;'.$split[1].'</span>';
            }
        }
        return join(' ',$array);
    }

}