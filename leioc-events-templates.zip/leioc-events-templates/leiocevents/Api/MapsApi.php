<?php
/**
* @package leioc-events-plugin
*
*/

namespace LEIOCevents\Api;

use PHPCoord\CoordinateReferenceSystem\Geographic2D;
use PHPCoord\BritishNationalGridPoint;

use \LEIOCevents\Base\BaseController;

class MapsApi extends BaseController
{
    private const GRID_LETTERS = 'VWXYZQRSTULMNOPFGHJKABCDE';

    public function osRefPoint($gref)
    {
        $gref = $this->checkGrid($gref);
        if( $gref == false) return false;

        $point = BritishNationalGridPoint::fromGridReference(trim($gref));
        $isBritishGrid = $point instanceof BritishNationalGridPoint; 

        if($isBritishGrid == false ) return false;
        return $point;
    }

    public function osToLatLong($point)
    {
        $toCRS = Geographic2D::fromSRID(Geographic2D::EPSG_WGS_84);
        $to = $point->convert($toCRS);
        return $to;
    }

    public function setGoogleScript()
    {
        $chk = $this->chkGoogleApi();
        if($chk == false ) return;

        add_action( 'wp_head', array($this->addMapApi()) );

        add_filter( 'script_loader_tag', function ( $tag, $handle ) {
            if ( 'google_api' !== $handle )
                return $tag;
            return str_replace( ' src', ' async defer src', $tag );
        }, 10, 2 );

    }

    public function addMapApi()
    {
        wp_enqueue_script( 'google_api', 'https://maps.googleapis.com/maps/api/js?key='. $this->getGoogleApi(), array( 'jquery' ), '', true );
    }

    public function getMapData($gref, $zoom = null)
    {
        if(empty($gref) ) return;

        $point = $this->osRefPoint( $gref );
        $chk = $this->chkGoogleApi();
        if($point == false || $chk == false ) return;

        $to = $this->osToLatLong($point);
        $lat = round($to->getLatitude()->getValue(), 6);
        $lng = round($to->getLongitude()->getValue(), 6);

        $map = array(
            'zoom'=> empty($zoom) ? 15 : $zoom,
            'lat' => $lat,
            'lng' => $lng,
        );

        return json_encode($map);
    }

    public function googleMapLink($gref, $desc = '')
    {
        $point = $this->osRefPoint( $gref );
        if($point == false ) return;

        $to = $this->osToLatLong($point);
        $lat = round($to->getLatitude()->getValue(), 7);
        $lng = round($to->getLongitude()->getValue(), 7);

        $search = $lat.",".$lng;
        $google_link = 'https://www.google.com/maps/dir/?api=1&destination='.$search.'&travlemode=driving';

        return $google_link;
    }

    public function streetmapLink($gref)
    {   
        $point = $this->osRefPoint( $gref );
        if($point == false ) return;

        $easting = $point->getEasting();
        $northing = $point->getNorthing();
        
        return 'http://www.streetmap.co.uk/grid/'.$easting.','.$northing.',120';
    }

    private function getGoogleApi()
    {
        $output = get_option('leioc_events_settings') ?: '';
        if(empty($output['leioc_map_use']) || empty($output['leioc_map_api']) ) return;

        return trim($output['leioc_map_api']);
    }

    public function chkGoogleApi()
    {
        $chk = $this->getGoogleApi();
        if(empty($chk) ) return false;
        return true;
    }

    //Checks if a Grid Reference
    public function checkGrid( string $ref)
    {
        if(empty($ref) ) return false;
        $ref = $this->removeSpaces($ref);

        //Grid Reference must be an even number of characters
        if (strlen($ref) % 2 !== 0) return false;
        
        $letterchk = substr($ref, 0, 2);
        //Checks if first 2 characters are letters
        if(!ctype_alpha($letterchk) ) return false;
        
        //Checks if remaining characters are numbers
        $numberchk = substr($ref,2);
        if(!is_numeric($numberchk) ) return false;

        //Checks if letters are GRID_LETTERS
        if(strpos(self::GRID_LETTERS, strtoupper($letterchk[0]) ) == false) return false;
        if(strpos(self::GRID_LETTERS, strtoupper($letterchk[1]) ) == false) return false;

        return $ref;
    }

    private function removeSpaces($ref)
    {
        $ref = preg_replace('/\s+/', '', ($ref) );
        return strtoupper($ref);
    }
    
}