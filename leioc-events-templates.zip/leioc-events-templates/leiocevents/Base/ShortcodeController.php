<?php
/**
*@package leioc-events-plugin
*
*/

namespace LEIOCevents\Base;

class ShortcodeController extends BaseController
{
    public function register()
	{
		add_shortcode( 'leioc-event-search', array( $this, 'event_search' ) );
		add_shortcode( 'leioc-results-search', array( $this, 'results_search' ) );
		add_shortcode( 'leioc-event-details', array( $this, 'event_details' ) );
    }

    public function event_search($attr)
    {
        ob_start();
        
        $option = get_option( 'leioc_events_settings' );
        $event_details_url = ( isset($option['event-details-url']) ? esc_url( $option['event-details-url'] ) : get_home_url() );

        include  $this->plugin_path.'blocks/leioc-event-search/templates/shortcode-shared.php';

        return ob_get_clean();
    }

    public function results_search($attr)
    {
        ob_start();

        $args = shortcode_atts( array(
            'results-info' => '',
        ), $attr );
        
        unset($this->allowed_html['p']);
        $results_info =  $this->leioc_esc_html( $args['results-info'] );

        include $this->plugin_path.'blocks/leioc-results/templates/shortcode-shared.php';

        return ob_get_clean();
    }

    public function event_details($attr)
    {
        ob_start();

        $args = shortcode_atts( array(
            'redirect-url' => '',
        ), $attr );

        $event_redirect_url =  esc_url( $args['redirect-url'] ) ;

        include $this->plugin_path.'blocks/leioc-event-details/templates/shortcode-shared.php';

        return ob_get_clean();
    }
}