<?php
/**
*@package leioc-events-plugin
*
*/

namespace LEIOCevents\Base;

class BaseController
{
    public $plugin_path;

    public $plugin_url;

    public $plugin;

    public $allowed_html;

    public function __construct(){
        $this->plugin_path = plugin_dir_path( dirname( __FILE__ , 2) );
        $this->plugin_url = plugin_dir_url( dirname( __FILE__ , 2) );
        $this->plugin = plugin_basename( dirname( __FILE__ , 3) ) . '/leioc-events-templates.php';

        $this->allowed_html = array(
                                'a'     => array(
                                            'href' => [],
                                        ),
                                'b'     => [],
                                'i'     => [],
                                'br'     => [],
                                'p' => [],
                                'table' => [],
                                'thead' => [],
                                'tbody' => [],
                                'tr' => [],
                                'th' => [],
                                'td' => [],
                                'ul' => [],
                                'li' => [],
                                'em' => [],
                            );
    }

    public function leioc_esc_html( $str )
    {
        return nl2br( wp_kses( preg_replace('/\n?<(.*?)>\n/', '<$1>', str_replace("\r\n", "\n", $str) ), $this->allowed_html ) );
    }

    public function br2nl( $str ) {
        return preg_replace( '/<br\s?\/?>/ius', "\n", str_replace("\n","", str_replace("\r","", htmlspecialchars_decode($str) )) );
    }
}