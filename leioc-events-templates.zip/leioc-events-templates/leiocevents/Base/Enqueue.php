<?php
/**
* @package leioc-events-plugin
*
*/

namespace LEIOCevents\Base;

use \LEIOCevents\Base\BaseController;

class Enqueue extends BaseController
{
    public function register()
    {
        add_action( 'admin_enqueue_scripts', array($this,'enqueueAdmin') );
        add_action( 'wp_enqueue_scripts', array($this,'enqueue') );
    }

    //Admin CSS & Scripts Files
    public function enqueueAdmin()
    {
        $version = $this->version_num();
        //enqueue all our scripts
        wp_enqueue_style('leioctemplatepluginadmincss', $this->plugin_url . 'assets/css/plugin-admin-style.min.css', array(), $version );
        wp_enqueue_script('leioctemplatepluginadminscript', $this->plugin_url .'assets/js/plugin-admin.min.js', array ( 'jquery' ), $version );
        wp_enqueue_script( 'leioc-font-awesome', 'https://kit.fontawesome.com/1a4725ab40.js' );
    }

    //CSS & Scripts Files
    public function enqueue()
    {
        $version = $this->version_num();
        //enqueue all our scripts
        wp_enqueue_style('leioctemplateplugincss', $this->plugin_url . 'assets/css/plugin-style.min.css' , array(), $version );
        wp_enqueue_script('leioctemplatepluginscript', $this->plugin_url .'assets/js/plugin.min.js',array ( 'jquery' ), $version );
        wp_enqueue_script( 'leioc-font-awesome', 'https://kit.fontawesome.com/1a4725ab40.js' );
    }

    private function version_num()
    {
        $plugin_data = get_plugin_data( $this->plugin_path . '/leioc-events-templates.php' );
        return $plugin_version = $plugin_data['Version'];
    }
}