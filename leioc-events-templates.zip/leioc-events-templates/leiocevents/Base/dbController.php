<?php
/**
* @package leioc-events-plugin
*
*/

namespace LEIOCevents\Base;

/**
* 
*/
class dbController
{
    protected static $feesArr = array(
                '0'=>array(
                        'type'=>'district',
                        'fee'=>'Seniors £6.00 and Juniors £2.00',
                        'date'=>'2000-01-01', //Fee Start Date
                        'siac'=>'SI Dibber Hire: £1.00 (LEI members can collect vouchers towards card purchase)'),
                '1'=>array(
                        'type'=>'district',
                        'fee'=>'Seniors £7.00 and Juniors £2.50',
                        'date'=>'2014-01-01', //Fee Start Date
                        'siac'=>'SI Dibber Hire: £1.00 (LEI members can collect vouchers towards card purchase)'),
                '2'=>array(
                        'type'=>'district',
                        'fee'=>'Seniors £7.50 and Juniors £3.00 - Seniors on White to Orange courses £3.00',
                        'date'=>'2017-01-01', //Fee Start Date
                        'siac'=>'SI Dibber Hire: £1.00 (LEI members can collect vouchers towards card purchase)'),
                '3'=>array(
                        'type'=>'district',
                        'fee'=>'Seniors £7.50 and Juniors &amp; Full-time students £3.00 - Seniors on White to Orange courses £3.00',
                        'date'=>'2018-02-13', //Fee Start Date
                        'siac'=>'SI Dibber Hire: £1.00 (LEI members can collect vouchers towards card purchase)'),
                '4'=>array(
                        'type'=>'district',
                        'fee'=>'Seniors £8.00 and Juniors &amp; Full-time students £3.00 - Seniors on White to Orange courses £3.00',
                        'date'=>'2018-08-15', //Fee Start Date
                        'siac'=>'SI Dibber Hire: £1.00 (LEI members can collect vouchers towards card purchase)'),
                '5'=>array(
                        'type'=>'district',
                        'fee'=>'Seniors £8, Juniors, Full-time students &amp; unwaged £3 – Seniors on White to Orange courses £4. <em>Refunds will be paid to those needing to withdraw through covid-19 restrictions. Email requests to organiser or Treasurer.</em>',
                        'date'=>'2020-02-20', //Fee Start Date
                        'siac'=>'SI Dibber Hire: £1.00 (LEI members can collect vouchers towards card purchase)'),
                '6'=>array(
                        'type'=>'local',
                        'fee'=>'Seniors £3.50 and Juniors £1.00',
                        'date'=>'2000-01-01', //Fee Start Date
                        'siac'=>'SI Dibber Hire: £1.00 (LEI members can collect vouchers towards card purchase)'),
                '7'=>array(
                        'type'=>'local',
                        'fee'=>'Seniors £4.00 and Juniors £1.00',
                        'date'=>'2012-10-01', //Fee Start Date
                        'siac'=>'SI Dibber Hire: £1.00 (LEI members can collect vouchers towards card purchase)'),
                '8'=>array(
                        'type'=>'local',
                        'fee'=>'Seniors £4.50 and Juniors £1.00',
                        'date'=>'2013-04-01', //Fee Start Date
                        'siac'=>'SI Dibber Hire: £1.00 (LEI members can collect vouchers towards card purchase)'),
                '9'=>array(
                        'type'=>'local',
                        'fee'=>'Seniors £4.50 and Juniors £1.50',
                        'date'=>'2013-10-01', //Fee Start Date
                        'siac'=>'SI Dibber Hire: £1.00 (LEI members can collect vouchers towards card purchase)'),
                '10'=>array(
                        'type'=>'local',
                        'fee'=>'Seniors £4.50, Full-time students £2.50, Juniors (or Family group shadowing their juniors) £1.50',
                        'date'=>'2018-02-13', //Fee Start Date
                        'siac'=>'SI Dibber Hire: £1.00 (LEI members can collect vouchers towards card purchase)'),
                '11'=>array(
                        'type'=>'local',
                        'fee'=>'Seniors £5.00, Full-time students £2.50, Juniors (or Family group shadowing their juniors) £1.50',
                        'date'=>'2018-08-15', //Fee Start Date
                        'siac'=>'SI Dibber Hire: £1.00 (LEI members can collect vouchers towards card purchase)'),
                '12'=>array(
                        'type'=>'local',
                        'fee'=>'Seniors £5, Full-time students &amp; unwaged £2.50, Juniors (or Family group shadowing their juniors) £1.50. <em>Refunds will be paid to those needing to withdraw through covid-19 restrictions. Email requests to organiser or Treasurer.</em>',
                        'date'=>'2020-02-20', //Fee Start Date
                        'siac'=>'SI Dibber Hire: £1.00 (LEI members can collect vouchers towards card purchase)'),
                '13'=>array(
                        'type'=>'local',
                        'fee'=>'Seniors £5, Non BOF Senior £6, Full-time students & working age unwaged £2.50, Juniors (or Family group shadowing their juniors) £1.50.<br><em> Refunds will be paid to those needing to withdraw through covid-19 restrictions. Email requests to organiser or Treasurer.</em>',
                        'date'=>'2021-07-20', //Fee Start Date
                        'siac'=>'SI Dibber Hire: £1.00 (LEI members can collect vouchers towards card purchase)'),
                '14'=>array(
                        'type'=>'activity',
                        'fee'=>'Families £5.00 Seniors £3.00 and Juniors £1.50',
                        'date'=>'2000-01-01', //Fee Start Date
                        'siac'=>'Yes - Card Hire free'),
                );

    public static function register()
    {
        global $wpdb;
        global $db_version;
    
        $db_version = '1.0';

        $charset_collate = $wpdb->get_charset_collate();
    
        $table = $wpdb->prefix . 'leioc_events_fees';

        $sql = "CREATE TABLE $table (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            time TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP NOT NULL,
            fee_type varchar(300) NOT NULL,
            fee_date datetime NOT NULL,
            fee_details MEDIUMTEXT NOT NULL,
            fee_publish int(1) DEFAULT '1' NOT NULL,
            fee_trash int(1) DEFAULT '1' NOT NULL,
            PRIMARY KEY (id)
        ) $charset_collate;";

        require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
                
        dbDelta( $sql );

        add_option( 'leioc_events_templates_db_version', $db_version );
    }

    public static function install_fees()
    {
        global $wpdb;

        $table = $wpdb->prefix . 'leioc_events_fees';

        $chk = $wpdb->get_var( "SELECT COUNT(*) FROM {$table}");
        //Only adds fees data if table is empty
        if($chk < 1){
            $feesArr = self::$feesArr;
            foreach($feesArr as $value){

                $type = sanitize_text_field( $value['type'] );
                $date = sanitize_text_field( $value['date'] );
                $fee = sanitize_text_field( $value['fee'] );
                $siac = sanitize_text_field( $value['siac'] );

                $details = array( 
                    'type' => $type,
                    'fee' => $fee,
                    'date' => $date,
                    'siac' => $siac,
                );

                $args = array(
                    'fee_type' => $type,
                    'fee_date' => $date,
                    'fee_details' =>  maybe_serialize( $details ),
                    'fee_publish' => 1,
                    'fee_trash' => 1,
                 );

                $wpdb->insert($table, $args);
            };

        };
    }
}
