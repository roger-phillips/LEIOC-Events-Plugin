<?php
/**
*@package leioc-events-plugin
*
*/

namespace LEIOCevents\Base;

use WP_List_Table;
use \LEIOCevents\Api\LeiocDbCall;

class EventsWPListTable extends WP_List_Table
{
    private $wpdb;

    private $db;
    
    public $table;

    public $data;

    public $per_page = 35;

    public $page_name;

    public $count;

    public $all_count;

    public $pub_count;

    public $draft_count;

    public $current_count;

    public $past_count;

    //Status 1 = All, 0 = Draft, 2 = Current, 3 = Past
    public $status = 2;

    public $update_bulk;

    public $option = '';

    public function __construct() {

		parent::__construct( 
            array(
                'singular' => 'Event', //singular name of the listed records
                'plural'   => 'Events', //plural name of the listed records
                'ajax'     =>  true, //should this table support ajax?
            )
        );

        global $wpdb;
        $this->wpdb = $wpdb;

        $this->db = new LeiocDbCall();
        $this->table = 'events';

        //Gets Settings Options
        $this->option = get_option( 'leioc_events_settings' );

        $this->page_name = isset($_REQUEST['_wp_http_referer']) ? $_REQUEST['_wp_http_referer'] : $_SERVER['REQUEST_URI'];
    }

    public function get_data()
    {
        $orderby = isset($_REQUEST['orderby'] ) ? $_REQUEST['orderby'] : 'event_date';
        $order = isset($_REQUEST['order']) ? $_REQUEST['order'] : 'DESC';
        $this->status = isset($_REQUEST['status']) ? $_REQUEST['status'] : 2;

        $san_orderby = sanitize_sql_orderby($orderby . ' ' . $order);

        $page_num = isset( $this->update_bulk ) ? $this->update_bulk : $this->get_pagenum() ;
        $offset = ( $page_num * $this->per_page ) - $this->per_page;

        $wild = '%';
        $find = isset($_POST['s']) ? trim($_POST['s']) : '';
        $like = $wild . $this->wpdb->esc_like( $find ) . $wild;

        $date = ($this->status == 1 ? '' : ( $this->status == 2 ? 'event_date >= NOW() AND':'event_date < NOW() AND' ) ) ;

        $sql = "SELECT * FROM {$this->table} WHERE {$date} event_title LIKE ? ORDER BY {$san_orderby} LIMIT {$offset}, {$this->per_page}";

        //Current Search Count
        $count = $this->db->bindDataquery("SELECT count(*) FROM {$this->table} WHERE {$date} event_title LIKE ? ", array($like) );
        $this->count = $count[0][0];

        //All Count
        $all = ($this->status == 1 ? '' : ( $this->status == 2 ? ' WHERE event_date >= NOW()':' WHERE event_date < NOW()' ) ) ;
        // var_dump(array($all));
        $all_count = $this->db->dataquery("SELECT count(*) FROM {$this->table}{$all}");
        $this->all_count = $all_count[0][0];
        // var_dump( 'All count: ' . $this->all_count ) ;
        // var_dump($this->status);

        //Published Count
        $count = $this->db->dataquery("SELECT count(*) FROM {$this->table}");
        $this->pub_count = $count[0][0];
        // var_dump($this->pub_count);

        //Current events
        $count = $this->db->dataquery("SELECT count(*) FROM {$this->table} WHERE event_date >= NOW() ");
        $this->current_count = $count[0][0];
        // var_dump($this->current_count);

        //Past events
        $count = $this->db->dataquery("SELECT count(*) FROM {$this->table} WHERE event_date < NOW() ");
        $this->past_count = $count[0][0];

        //Event Table is missing Trash Column
        $this->draft_count = 0;

        $this->data = $this->db->bindDataquery($sql, array($like) );
    }

    public function get_columns()
    {
        $columns = array(
            'event_date'  => 'Event Date',
            'event_flag' => 'Event Type',
            'event_title' => 'Title',
            'event_org' => 'Organiser',
            'event_id'   => 'ID',
            'details' => 'Event Page',
        );
        return $columns;
    }

    public function column_cb($item)
    {
        return sprintf('<input type="checkbox" name="post_cb[]" value="%s" />',$item['event_id']);
    }

    public function prepare_items()
    {
        $columns = $this->get_columns();
        $hidden = $this->get_hidden_columns();
        $sortable = $this->get_sortable_columns();

        $this->set_pagination_args(
            array(
                'total_items' => $this->count,
                'per_page' => $this->per_page,
                'total_pages'   => ceil( $this->count / $this->per_page ),
                'orderby'   => ! empty( $_REQUEST['orderby'] ) && '' != $_REQUEST['orderby'] ? $_REQUEST['orderby'] : 'event_date',
                'order'     => ! empty( $_REQUEST['order'] ) && '' != $_REQUEST['order'] ? $_REQUEST['order'] : 'DESC',
                'status'     => ! empty( $_REQUEST['status'] ) && '' != $_REQUEST['status'] ? $_REQUEST['status'] : 2,
            )
        );

        $this->_column_headers = array($columns, $hidden, $sortable);
        $this->items = $this->data;
    }

    public function get_hidden_columns()
    {
        return array('');
    }

    public function get_sortable_columns()
    {
        return array(
            'event_date' => array('event_date', true),
            'event_title' => array('event_title', true),
            'event_flag' => array('event_flag', true),
        );
    }

    public function column_default( $item, $column_name )
    {
        switch( $column_name ) { 
            case 'event_id':
            case 'event_title':
            case 'event_org':
                return $item[ $column_name ];
            case 'event_flag':
                return $this->set_event_flag( $item[ $column_name ] );
            case 'event_date':
                return date('D dS M Y', strtotime($item[$column_name]) );
            case 'details':
                return $this->set_details_link($item['event_id']);
            default:
                return 'no value';
        }
    }

    public function set_event_flag($arg)
    {
        $str = trim( strtolower($arg) );
        if( $str == 'y') return 'Event';
        if( $str == 'a') return 'Activity';
        if( $str == 'm') return 'Meeting';

        return trim($arg);
    }

    public function set_details_link($arg)
    {
        $str = explode('?', $this->option['event-details-url'] );
        $url = esc_attr($str[0]) . '?item=' . rawurlencode(' ' . esc_attr($arg) );
        return sprintf('<a href="%s" target="_blank">Event Details</a>', $url);
    }

    public function set_sub_menu()
    {
        $status = $this->status;

        return sprintf('<ul class="subsubsub"><li class="current"><a href="%s&status=2" %s>Current %s</a></li> | <li class="past"><a href="%s&status=3" %s>Past %s</a></li> | <li class="publish"><a href="%s&status=1" %s>All %s</a></li></ul>', $this->page_name, ($status == 2 ? 'class="current"' : '' ), $this->add_span( $this->current_count ), $this->page_name, ($status == 3 ? 'class="current"' : '' ), $this->add_span( $this->past_count ),$this->page_name, ($status == 1 ? 'class="current"' : '' ), $this->add_span( $this->pub_count ) );
    }

    public function add_span($count)
    {
        return sprintf('<span class="count">(%d)</span>', $count);
    }

    public function show_table()
    {
        $this->get_data();

        echo '<form method="post" id="leioc_events_template_table" name="leioc_events_template_table" data-url="' . admin_url('admin-ajax.php') . '" action="' . $this->page_name . '">';
        echo '<div class="leioc-msg"><small class="field-msg js-database-submission">Accessing database, please wait&hellip;</small>
        <small class="field-msg error js-database-error">There was a problem connecting with the database, please try again!</small></div>';
        echo $this->set_sub_menu();
        
        $this->prepare_items();
        $this->search_box('Search Events','leioc_events_id');
        $this->display(); 

        echo '</form>';
    }

    public function ajax_response()
    {
        if (! DOING_AJAX || ! check_ajax_referer('leioc-events-template-wp-nonce', 'nonce') ) {
			return $this->return_json('error');
        }

        if( isset( $_REQUEST['action3'] ) ) $_REQUEST['action'] = $_REQUEST['action3'];

        get_pagenum_link(  $this->get_pagenum(), +1 );

        $this->get_data();
        $this->prepare_items();

        extract( $this->_args );
        extract( $this->_pagination_args, EXTR_SKIP );
       
        ob_start();
        if ( ! empty( $_REQUEST['no_placeholder'] ) )
            $this->display_rows();
        else
            $this->display_rows_or_placeholder();
        $rows = ob_get_clean();

        ob_start();
        $this->print_column_headers();
        $headers = ob_get_clean();

        ob_start();
        $this->pagination('top');
        $pagination_top = ob_get_clean();
    
        ob_start();
        $this->pagination('bottom');
        $pagination_bottom = ob_get_clean();

        ob_start();
        $this->search_box('Search Events','leioc_events_id');
        $search = ob_get_clean();

        ob_start();
        $this->bulk_actions('top');
        $bulk_actions_top = ob_get_clean();

        ob_start();
        $this->bulk_actions('bottom');
        $bulk_actions_bottom = ob_get_clean();

        $response = array( 'rows' => $rows );
        $response['pagination']['top'] = $pagination_top;
        $response['pagination']['bottom'] = $pagination_bottom;
        $response['column_headers'] = $headers;
        $response['count'] = esc_attr( $this->all_count );
        $response['one_page']  = esc_attr( $this->per_page > $this->all_count ? ($this->all_count == 0 ? 'one-page no-pages' : 'one-page' ) : '' );
        $response['sub_menu'] = $this->set_sub_menu();

        if ( isset( $total_items ) )
        $response['total_items_i18n'] = sprintf( _n( '1 item', '%s items', $total_items ), number_format_i18n( $total_items ) );
 
        if ( isset( $total_pages ) ) {
            $response['total_pages'] = $total_pages;
            $response['total_pages_i18n'] = number_format_i18n( $total_pages );
        }

        if ( isset( $search) ) $response['search'] = $search;
            
        if ( isset( $bulk_actions_top) ) $response['bulk_actions_top'] = $bulk_actions_top;
        if ( isset( $bulk_actions_bottom) ) $response['bulk_actions_bottom'] = $bulk_actions_bottom;
        
        if( isset($response) ) return $this->return_json('success', $response);

	    return $this->return_json('error');
    }

    public function return_json($status, $data = null)
	{
		$return = array(
			'status' => $status,
			'data' => $data,
		);
		wp_send_json($return);

		wp_die();
    }

    //Only needed with AJAX
    function display()
    {
        wp_nonce_field( 'leioc-events-template-wp-nonce', 'nonce' );
        echo '<input id="order" type="hidden" name="order" value="' . $this->_pagination_args['order'] . '" />';
        echo '<input id="orderby" type="hidden" name="orderby" value="' . $this->_pagination_args['orderby'] . '" />';
        echo '<input id="status" type="hidden" name="status" value="' . $this->_pagination_args['status'] . '" />';
        echo '<input type="hidden" name="ajax_action" value="admin_event_template_wp_list">';

        parent::display();
    }

    //Only needed with AJAX. Changes $_GET to $_REQUEST['order] and orderby
    public function print_column_headers( $with_id = true ) 
    {
        list( $columns, $hidden, $sortable, $primary ) = $this->get_column_info();
     
        $request_uri =  isset($_REQUEST['_wp_http_referer']) ? $_REQUEST['_wp_http_referer'] : $_SERVER['REQUEST_URI'];

        $current_url = set_url_scheme( 'http://' . $_SERVER['HTTP_HOST'] . $request_uri );
        $current_url = remove_query_arg( 'paged', $current_url );
     
        if ( isset( $_REQUEST['orderby'] ) ) {
            $current_orderby = $_REQUEST['orderby'];
        } else {
            $current_orderby = '';
        }
     
        if ( isset( $_REQUEST['order'] ) && 'desc' === $_REQUEST['order'] ) {
            $current_order = 'desc';
        } else {
            $current_order = 'asc';
        }
     
        if ( ! empty( $columns['cb'] ) ) {
            static $cb_counter = 1;
            $columns['cb']     = '<label class="screen-reader-text" for="cb-select-all-' . $cb_counter . '">' . __( 'Select All' ) . '</label>'
                . '<input id="cb-select-all-' . $cb_counter . '" type="checkbox" />';
            $cb_counter++;
        }
     
        foreach ( $columns as $column_key => $column_display_name ) {
            $class = array( 'manage-column', "column-$column_key" );
     
            if ( in_array( $column_key, $hidden, true ) ) {
                $class[] = 'hidden';
            }
     
            if ( 'cb' === $column_key ) {
                $class[] = 'check-column';
            } elseif ( in_array( $column_key, array( 'posts', 'comments', 'links' ), true ) ) {
                $class[] = 'num';
            }
     
            if ( $column_key === $primary ) {
                $class[] = 'column-primary';
            }
     
            if ( isset( $sortable[ $column_key ] ) ) {
                list( $orderby, $desc_first ) = $sortable[ $column_key ];
     
                if ( $current_orderby === $orderby ) {
                    $order = 'asc' === $current_order ? 'desc' : 'asc';
     
                    $class[] = 'sorted';
                    $class[] = $current_order;
                } else {
                    $order = strtolower( $desc_first );
     
                    if ( ! in_array( $order, array( 'desc', 'asc' ), true ) ) {
                        $order = $desc_first ? 'desc' : 'asc';
                    }
     
                    $class[] = 'sortable';
                    $class[] = 'desc' === $order ? 'asc' : 'desc';
                }
     
                $column_display_name = sprintf(
                    '<a href="%s"><span>%s</span><span class="sorting-indicator"></span></a>',
                    esc_url( add_query_arg( compact( 'orderby', 'order' ), $current_url ) ),
                    $column_display_name
                );
            }
     
            $tag   = ( 'cb' === $column_key ) ? 'td' : 'th';
            $scope = ( 'th' === $tag ) ? 'scope="col"' : '';
            $id    = $with_id ? "id='$column_key'" : '';
     
            if ( ! empty( $class ) ) {
                $class = "class='" . implode( ' ', $class ) . "'";
            }
     
            echo "<$tag $scope $id $class>$column_display_name</$tag>";
        }
    }

    public function search_box( $text, $input_id )
    {
        if ( empty( $_REQUEST['s'] ) && ! $this->has_items() ) {
            return;
        }
 
        $input_id = $input_id . '-search-input';
 
        if ( ! empty( $_REQUEST['post_mime_type'] ) ) {
            echo '<input type="hidden" name="post_mime_type" value="' . esc_attr( $_REQUEST['post_mime_type'] ) . '" />';
        }
        if ( ! empty( $_REQUEST['detached'] ) ) {
            echo '<input type="hidden" name="detached" value="' . esc_attr( $_REQUEST['detached'] ) . '" />';
        }
        ?>
        <p class="search-box">
            <label class="screen-reader-text" for="<?php echo esc_attr( $input_id ); ?>"><?php echo $text; ?>:</label>
            <input type="search" id="<?php echo esc_attr( $input_id ); ?>" name="s" value="<?php _admin_search_query(); ?>" />
                <?php submit_button( $text, '', '', false, array( 'id' => 'search-submit' ) ); ?>
        </p>
                <?php
    }
}