<?php
/**
*@package leioc-events-plugin
*
*/

namespace LEIOCevents\Base;

use \LEIOCevents\Base\BaseController;

class SettingsLinks extends BaseController
{
    public function register(){
       add_filter( 'plugin_action_links_' . $this->plugin , array($this, 'settings_link'));
    }

    public function settings_link( $links ){
        $settings_link = '<a href="'.esc_url( admin_url('/admin.php?page=leioc_events_dashboard') ).'">Settings</a>';
        array_push( $links, $settings_link );
        return $links;
    }
}