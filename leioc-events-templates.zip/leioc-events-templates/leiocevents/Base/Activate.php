<?php
/**
*@package leioc-events-plugin
*
*/

namespace LEIOCevents\Base;

class Activate
{
    public static function activate()
    {
        flush_rewrite_rules();

        $default = array();

        if( ! get_option( 'leioc_events_database' ) ){
            update_option( 'leioc_events_database', $default );
        }

        if( ! get_option( 'leioc_events_settings' ) ){
            update_option( 'leioc_events_settings', $default );
        }

        if( ! get_option( 'leioc_events_templates_db_version' ) ){
            update_option( 'leioc_events_templates_db_version', $default );
        }
    }
}