<?php
/**
*@package leioc-events-plugin
*
*/

namespace LEIOCevents\Base;

use LEIOCevents\Base\BaseController;
use LEIOCevents\Api\Widgets\EventsWidget;
use LEIOCevents\Api\Widgets\ResultsWidget;


class WidgetsController extends BaseController
{

    public function register(){

        $results_widget = new ResultsWidget;

        $results_widget->register();

        $events_widget = new EventsWidget;

        $events_widget->register();

    }

}