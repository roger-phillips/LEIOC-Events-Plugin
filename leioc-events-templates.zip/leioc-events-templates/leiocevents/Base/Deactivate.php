<?php
/**
* @package leioc-events-plugin
*
*/

namespace LEIOCevents\Base;

class Deactivate
{
    public static function deactivate(){
        flush_rewrite_rules();
    }
}