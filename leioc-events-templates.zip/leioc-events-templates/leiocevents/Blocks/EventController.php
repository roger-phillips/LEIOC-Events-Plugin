<?php
/**
* @package leioc-events-plugin
*
*/

namespace LEIOCevents\Blocks;


class EventController
{
    protected $levelArr = array(
        'a'=>'Major',
        'b'=>'National',
        'c'=>'Regional',
        'd'=>'Local');

    protected $beginnersArr = array(
        'y'=>'Beginners welcome, help and advice available.',
        'n'=>'Not suitable for beginners.');

    protected $groupsArr = array(
        'y'=>'(Youth group, Scouts, Running club etc) should let the Organiser know a week in advance.',
        'n'=>'Not suitable for large groups'
    );

    protected $timesArr = array(
        '10'=>'10:00 am - 12:00 noon',
        '10only'=>'10:00 am',
        '10.30'=>'10:30 am - 12:30 am',
        '11only'=>'11:00 am',
        '11'=>'11:00 am - 12:00 noon',
        '12'=>'12 noon',
        '1.30'=>'1:30 pm',
        '2.00'=>'2:00 pm',
        '2.30'=>'2:30 pm',
        '6.15'=>'6:15 pm - 7:00 pm',
        '6.30'=>'6:30 pm - 7:15 pm',
        '6.31'=>'6:30 pm - 8:30 pm',
        '7.30'=>'7:30 pm - 9:00 pm',
        '7.31'=>'7:30 pm - 9:30 pm',
        '8.15'=>'8:15 pm',
        'club'=>'6:30 pm - 8:00 pm',
        'other' => 'other',
    );
 
    protected $courseArr = array(
        'white'=>array(
                    'level'=>'novice',
                    'text'=>'Beginners, families and juniors.'),
        'yellow'=>array(
                    'level'=>'novice',
                    'text'=>'Beginners, families and juniors.'),
        'orange'=>array(
                    'level'=>'intermediate',
                    'text'=>'Improvers, runners and pairs.'),
        'lightgreen'=>array(
                    'level'=>'intermediate',
                    'text'=>'Improvers, runners and pairs.'),
        'shortgreen'=>array(
                    'level'=>'experienced',
                    'text'=>'Experienced orienteerers.'),
        'green'=>array(
                    'level'=>'experienced',
                    'text'=>'Experienced orienteerers.'),
        'shortblue'=>array(
                    'level'=>'experienced',
                    'text'=>'Experienced orienteerers.'),
        'blue'=>array(
                    'level'=>'experienced',
                    'text'=>'Experienced orienteerers.'),
        'shortbrown'=>array(
                    'level'=>'experienced',
                    'text'=>'Experienced orienteerers.'),
        'brown'=>array(
                    'level'=>'experienced',
                    'text'=>'Experienced orienteerers.'),
        'black'=>array(
                    'level'=>'experienced',
                    'text'=>'Experienced orienteerers.'),
     );
}