<?php
/**
* @package leioc-events-plugin
*
*/

namespace LEIOCevents\Blocks;

use \LEIOCevents\Api\LeiocDbCall;
use \LEIOCevents\Blocks\EventFunctions;

class EventData
{
   
    /**
     * 
     * @param 1st param should be the event details link
     * @param 2nd param should be the search parameter
     * 
     */
    public static function getAllEvents( array $data )
    {
        $today = date("Y-m-d"); 

        $db = new LeiocDbCall();

        //Adds Search pramater if present
        $search =  (!empty($data[1]) ? ($data[1] == 'all' ? '' :' AND event_flag ="'.esc_attr($data[1]).'"') : '') ;

        $sql = 'SELECT event_id, event_flag, event_date, 
                DAYNAME(event_date) AS day, MONTHNAME(event_date) AS month, 
                DAYOFMONTH(event_date) AS date, YEAR(event_date) AS year, event_title, 
                (SELECT ecat_name FROM event_category WHERE ecat_id = event_category) AS v_category,
                (SELECT etype_name FROM event_type WHERE etype_id = event_type) AS v_type,
                event_details_link, event_cp_grid FROM events WHERE event_date >= "'.$today.'"'.$search.' 
                ORDER BY event_date ASC, event_id ASC';

        $result = $db->dataquery($sql);
        $events = new EventFunctions();

        return $events->eventsToHtml($result, $data[0]);
    }

    public static function eventbyIDdata($ID)
    {
        //Sanitize ID to number to prevent SQL injections
        $ID = intval( esc_attr($ID) );
        $db = new LeiocDbCall();
        
        $sql = 'SELECT event_id, event_flag, event_date, event_title, 
                (SELECT ecat_name FROM event_category WHERE ecat_id = event_category) AS event_category, 
                event_type, event_type_other, event_org, event_org_phone, event_org_email, event_planner, 
                event_controller, event_courses, event_si, event_siac, event_fees, event_fees_other, event_reg, 
                event_reg_other, event_starts, event_starts_other, event_course_close, event_course_close_other, 
                event_time, event_time_other, event_cp_grid, event_cp_desc, event_postcode, event_dogs, event_notes, 
                event_social, event_level, event_beginners, event_groups, event_details_link, event_toilets, 
                event_updated FROM events';

        //bind search parameter to prevent SQL injection
        $result = $db->bindDataQuery($sql.' WHERE event_id= ?', array($ID) );

        if(empty($result) ) return;

        $event = new EventFunctions();

        return $event->eventDataToHtml($result);

    }

    public function ajaxAllEvents()
    {
        $search = esc_attr($_POST['leioc-fixtures-search']);
        $event_details_url = $_POST['event_details_link'];
        
        $events = self::getAllEvents( array($event_details_url, $search) );

        $status = empty($events) ? 'error' : 'success';

        $return = array(
            'status' => $status,
            'result' => $events,
        );

        wp_send_json( $return );

        wp_die();
    }
}