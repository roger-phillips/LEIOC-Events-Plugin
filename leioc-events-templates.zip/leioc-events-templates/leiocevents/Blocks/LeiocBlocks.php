<?php
/**
* @package leioc-events-plugin
*
*/

namespace LEIOCevents\Blocks;

use function Genesis\CustomBlocks\add_block;

class LeiocBlocks
{
    public function register(){
        add_action( 'genesis_custom_blocks_add_blocks',array($this,'eventDetails' ) );
        add_action( 'genesis_custom_blocks_add_blocks',array($this,'eventSearch' ) );
        add_action( 'genesis_custom_blocks_add_blocks',array($this,'results' ) );
        add_action( 'genesis_custom_blocks_add_blocks',array($this,'event_admin' ) );
        add_action( 'genesis_custom_blocks_add_blocks',array($this,'results_admin' ) );
    }

    /**
     * Defines the controls for the Event Details Block
     */
    public function eventDetails() {
        add_block( 
            'leioc-event-details', 
            array(  'title'=>'Event Details Block',
                    'icon' => 'place',
                    'fields'=> array(
                        'redirect-url' => array(
                            'label'   => 'Redirect Page URL',
                            'control' => 'url',
                            'default' => 'http://www.leioc.org.uk/',
                        ),
                    )
            )
        );
    }

    public function eventSearch(){
        add_block( 
            'leioc-event-search', 
            array(  'title'=>'Event Search Block',
                    'icon' => 'place',
            )
        );
    }

    public function results(){
        add_block( 
            'leioc-results', 
            array(  'title'=>'LEIOC Results Block',
                    'icon' => 'book',
                    'fields'=> array(
                        'results-info' => array(
                            'label'   => 'Results Information',
                            'control' => 'textarea',
                            'default' => 'Click on an event to see the results for that event.<ul><li><a href="https://www.leioc.routegadget.co.uk/rg2/index.php#112">LEI RouteGadet</a></li><li><a href="https://www.routegadget.co.uk/">Notes on using RouteGadget</a></li></ul>',
                        ),
                    )
            )
        );
    }

    public function event_admin(){
        add_block( 
            'leioc-admin-database', 
            array(  'title'=>'LEIOC Admin Block',
                    'icon' => 'place',
                    'fields'=> array(
                        'leioc-filepath' => array(
                            'label'   => 'File Upload Path',
                            'control' => 'text',
                            'default' => '/wordpress/lei_fixtures/uploads/',
                        ),
                    )
                )
        );
    }

    public function results_admin(){
        add_block( 
            'leioc-results-admin-database', 
            array(  'title'=>'LEIOC Results Admin Block',
                    'icon' => 'book',
                    'fields'=> array(
                        'leioc-filepath' => array(
                            'label'   => 'File Upload Path',
                            'control' => 'text',
                            'default' => '/wordpress/lei_results/',
                        ),
                    )
                )
        );
    }

}