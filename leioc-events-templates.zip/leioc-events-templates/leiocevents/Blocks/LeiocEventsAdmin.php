<?php
/**
* @package leioc-events-plugin
*
*/

namespace LEIOCevents\Blocks;

use \LEIOCevents\Api\LeiocDbCall;
use \LEIOCevents\Base\BaseController;



class LeiocEventsAdmin
{
    private $db;

    private $base;

    public function __construct()
    {
        $this->db = new LeiocDbCall();
        $this->base = new BaseController;
    }

    public function eventsSanitize()
    {
        $db = $this->db;

        if( isset($_POST['edit_event']) )
        {
            $sql = "SELECT * FROM events WHERE event_id = ?";
            $result = $db->bindDataQuery($sql, [$_POST['edit_event']]);

            $result = $result[0];
            return $result;
        }


        if( isset($_POST['remove']) ) 
        {
            $sql = "DELETE FROM events WHERE event_id = ?";
            $result = $db->bindDataQuery($sql, [$_POST['remove']], 'return');
            return;
        }

        if( !isset($_POST['event_submit']) ) return;

        $event = $_POST;
        //Sets Page Updated to current day
        $event['event_updated'] = date("Y-m-d");

        //Sets Car Park Description for Google Maps
        if(! empty($event['event_cp_grid']) && empty($event['event_cp_desc'])) $event['event_cp_desc'] = '-';

        foreach($event as $key => $value)
        {
            if( is_array( $value) ) $value = join('; ', $value);
            //Sanitize text area with allowed html
            if( $key == 'event_notes' || $key == 'event_social'){
                $event[$key] = wp_kses( $value , $this->base->allowed_html );
            } else {
                $event[$key] = sanitize_text_field( trim($value) );
            }
        }

        $this->addEvent($event);
        return;
    }

    private function addEvent($event)
    {
        $db = $this->db;
        $sqlFields = 'event_id, event_flag, event_title, event_type, event_type_other, event_date, event_org, event_org_phone, event_org_email, event_planner, event_controller, event_courses, event_string, event_fees, event_fees_other, event_si, event_siac, event_reg, event_reg_other, event_starts, event_starts_other, event_course_close, event_course_close_other, event_time, event_time_other, event_cp_grid, event_cp_desc, event_postcode, event_dogs, event_notes, event_social, event_level, event_beginners, event_groups, event_social_postcode, event_details_link, event_toilets, event_updated';

        $fields = explode(',',$sqlFields);

        $values = '';
        //New array used to get fields in correct order
        $newArr = array();

        foreach($fields as $field){
            $name = trim($field);
            if( !isset($event[$name]) ) {
                $event[$name] = '';
            }
            $values .= '? ';
            $newArr[] = $event[$name];
        }

        $values = str_replace(' ',', ',trim($values));

        $sql = 'REPLACE INTO events ('.$sqlFields.') VALUES ('.$values.')';

        $result = $db->bindDataQuery($sql, $newArr, 'return');
        return;
    }

    public function showEvents()
    {
        $db = $this->db;
        $today = date('Y-m-d');

        $sql = 'SELECT event_id, event_title, event_date, event_flag FROM events WHERE event_date >="'.$today.'" ORDER BY event_date ASC, event_id ASC';
        $result = $db->dataquery($sql);

        $table = '';

        foreach($result as $value){
            $edit = $this->addEdit($value['event_id']).' '.$this->addDelete($value['event_id']);
            $table .= sprintf('<tr><td>%s</td><td>%s</td><td class="leioc-admin-%s">%s</td><td>%s</td></tr>', $value['event_id'], date('D jS M Y',strtotime($value['event_date'])), $value['event_flag'], $value['event_title'], $edit );
        }

        return $table;
    }

    private function addDelete($arg)
    {

        $form = sprintf('<form method="post" class="inline-block"><input type="hidden" name="remove" value="%s"><input type="submit" value="Delete" class="leioc-admin-btn" onclick="return confirm(\'Are you sure you wish to delete this event?\')"></form>', $arg);

        return $form;
    }

    private function addEdit($arg)
    {
        $form = sprintf('<form  method="post" class="inline-block"><input type="hidden" name="edit_event" value="%s"><input type="submit" value="Edit" class="leioc-admin-btn leioc-edit-btn"></form>', $arg);

        return $form;
    }

    public function ckDB()
    {
        $db = $this->db;

        if($db->checkDB() == false) return  false; 
        return  true;
    }

    public function uploadEventsFile()
    {
        $root = ABSPATH;

        $folder = isset( $_POST['upload_path'] ) ? $_POST['upload_path'] : '/wordpress/lei_fixtures/uploads/';
        $filename = basename( $_FILES['uploaded_file']['name']);

        $path = $root. $folder;

        if (! is_dir($path) ) { 
            wp_mkdir_p($path);
        }

        $path .= $filename;

        if(move_uploaded_file($_FILES['uploaded_file']['tmp_name'], $path)){
            $message = 'The file '. $filename . 
            ' has been uploaded.';

            $return = array(
                'status' => 'success',
                'msg' => $message,
                'filepath' => site_url($folder) . $filename,
            );

            wp_send_json( $return );
            wp_die();
        }

        $return = array(
            'status' => 'error',
        );

        wp_send_json( $return );
        wp_die();
    }

    public function getPostCode()
    {
        $db = $this->db;

        $search = trim($_POST['leioc_cp_search']);

        $sql = "SELECT event_title, event_postcode, event_cp_grid, event_cp_desc, event_date FROM events WHERE event_title LIKE '%".$search."%' ORDER BY event_date DESC LIMIT 10";

        $result = $db->dataquery($sql);
        if( empty($result) ) $result = array('status' => 'error');

        wp_send_json( $result );
        wp_die();
    }

    public function get_course_options($array, $event)
    {
        $courses = str_replace(';', ',', ( isset($event['event_courses']) ? strtolower($event['event_courses']) : '0') );
        $courses = explode(', ', $courses);
        $html = '';
        foreach($array as $value){
            $html .= $this->build_course_options($value, $courses);
        }

        return $html;
    }

    private function build_course_options($arg, $courses)
    { 
        if( empty($arg) ) return;

        $label = str_replace(' ','_', strtolower($arg) );
        $label = substr($label, 0, 8);
        $course = ucfirst($arg);
        $chk = in_array(strtolower($arg), $courses) ? 'checked': ''; 

        return sprintf('<div class="leioc-ui-toggle"><input type="checkbox" id="course_%s" name="event_courses[]" value="%s" %s aria-describedby="Event course - %s"><label for="course_%s">%s</label></div>', $label, $course, $chk, $course, $label, $course);
    }

    /* 
    * @param $arr[ [ID, Value, Describe By, Title] ]
    */
    public function get_checkbox_group( $arr, $form_field, $event, $other_label = null)
    {
        $html = '';
        $chk = ( isset($event[$form_field]) ? strtolower($event[$form_field]) : '0');

        $other = array(
            'group_name' => $form_field.'_other',
            'other_show' => (isset($event[$form_field]) ? ($event[$form_field] == 'other' ? 'other-show' : 'other-hide') : 'other-hide'),
            'value' => isset($event[$form_field.'_other']) ? $event[$form_field.'_other'] : '',
            'label' => $other_label,
        );

        foreach($arr as $value)
        {
            $arg = array(
                'id'=> $value[0],
                'form_field'=> $form_field,
                'value' => $value[1],
                'chk' => ($chk == strtolower($value[1]) ? 'checked': ''),
                'describe' => $value[2],
                'title' => $value[3],
            );

            $html .= $this->build_checkbox_group( $arg );

            if( !empty($other_label) && strtolower($value[1]) == 'other' ){
                $html .= $this->build_other_input_group( $other );
            }
        }
        return $html; 
    }

    private function build_checkbox_group( $arg )
    {
        $id = esc_attr__($arg['id']);
        $name = esc_attr__($arg['form_field'] . '[]');
        $value = esc_attr__($arg['value']);
        $chk = esc_attr__($arg['chk']);
        $describe = esc_attr__($arg['describe']);
        $title = esc_attr__($arg['title']);
        $other = esc_attr__( strtolower($value) == 'other' ? 'other' : '' );

        return sprintf('<div class="leioc-ui-toggle leioc-group %s"><input type="checkbox" id="%s" name="%s" value="%s" %s aria-describedby="%s"><label for="%s">%s</label></div>', $other, $id, $name, $value, $chk, $describe, $id, $title);
    }

    private function build_other_input_group( $arg )
    {
        $id = esc_attr__($arg['group_name']);
        $other_show = esc_attr__($arg['other_show']);
        $value = esc_attr__( $arg['value'] );
        $label = esc_attr__( $arg['label'] );

        return sprintf('<div class="leioc-form-group %s"><label for="%s">%s</label><input type="text" maxlength="30" id="%s" name="%s" value="%s" aria-describedby="%s"></div>', $other_show, $id, $label, $id, $id, $value, $label);
    }

    public function leioc_esc_html__( $arg )
    {
        return esc_html__( isset($arg) ? $arg : '');
    }
}