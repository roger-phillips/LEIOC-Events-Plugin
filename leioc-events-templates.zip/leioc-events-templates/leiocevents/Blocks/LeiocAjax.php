<?php
/**
* @package leioc-events-plugin
*
*/

namespace LEIOCevents\Blocks;

use \LEIOCevents\Pages\Dashboard;
use \LEIOCevents\Base\FeesWPListTable;
use \LEIOCevents\Base\EventsWPListTable;
use \LEIOCevents\Blocks\EventData;
use \LEIOCevents\Blocks\ResultsData;
use \LEIOCevents\Blocks\LeiocEventsAdmin;
use \LEIOCevents\Blocks\LeiocResultsAdmin;

class LeiocAjax
{
    public function register()
    {
        add_action( 'wp_ajax_leioc_file_upload' , array( $this, 'leioc_file_upload') );

        add_action( 'wp_ajax_leioc_event_cp_search' , array( $this, 'leioc_event_cp_search') );

        add_action( 'wp_ajax_leioc_results_file_upload' , array( $this, 'leioc_results_file_upload') );

        //Events Search
        add_action( 'wp_ajax_leioc_event_search' , array( $this, 'leioc_event_search') );
        add_action( 'wp_ajax_nopriv_leioc_event_search' , array( $this, 'leioc_event_search') );

        //Results Search
        add_action( 'wp_ajax_leioc_results_search' , array( $this, 'leioc_results_search') );
        add_action( 'wp_ajax_nopriv_leioc_results_search' , array( $this, 'leioc_results_search') );

        //Admin Event Fees Dashboard Submit
        add_action( 'wp_ajax_leioc_events_fees_submit' , array( $this, 'fees_submit') );

        //Admin Event Fees WP_List_Table
        add_action( 'wp_ajax_admin_fee_wp_list' , array( $this, 'admin_fee_wp_list') );

        //Admin Events WP_List_Table
        add_action( 'wp_ajax_admin_event_template_wp_list' , array( $this, 'admin_event_template_wp_list') );
    }

    public function fees_submit()
    {
        $dash = new Dashboard;
        return $dash->leioc_fees_submit();
        
        wp_die();
    }

    public function admin_fee_wp_list()
    {
        $wp_list_table = new FeesWPListTable;
        return $wp_list_table->ajax_response();
        
        wp_die();
    }

    public function admin_event_template_wp_list()
    {
        $wp_list_table = new EventsWPListTable;
        return $wp_list_table->ajax_response();
        
        wp_die();
    }

    public function leioc_file_upload(){

        if ( ! DOING_AJAX || ! check_ajax_referer( 'leioc_file_upload_nonce', 'nonce') ) {

            return $this->ajax_error('error');

        }

        $admin = new LeiocEventsAdmin;

        $admin->uploadEventsFile();

        wp_die();
    }

    public function leioc_results_file_upload(){

        if ( ! DOING_AJAX || ! check_ajax_referer( 'leioc_file_upload_nonce', 'nonce') ) {

            return $this->ajax_error('error');

        }

        $admin = new LeiocResultsAdmin;

        $admin->uploadResultsFile();

        wp_die();
    }

    public function leioc_event_cp_search(){

        if ( ! DOING_AJAX || ! check_ajax_referer( 'leioc_cp_search_nonce', 'nonce') ) {

            return $this->ajax_error('error');

        }

        $admin = new LeiocEventsAdmin;

        $admin->getPostCode();

        wp_die();
    }

    public function leioc_event_search()
    {
        if ( ! DOING_AJAX || ! check_ajax_referer( 'leioc_event_search_nonce', 'nonce') ) {
            return $this->ajax_error('error');
        }

        $events = new EventData;
        $events->ajaxAllEvents();

        wp_die();
    }

    public function leioc_results_search()
    {
        if ( ! DOING_AJAX || ! check_ajax_referer( 'leioc_results_search_nonce', 'nonce') ) {
            return $this->ajax_error('error');
        }

        $results = new ResultsData;
        $results->ajaxResults();

        wp_die();
    }

    public function ajax_error( $status )
    {
        $return = array(
            'status' => $status,
        );

        wp_send_json( $return );
        wp_die();
    }

}