<?php
/**
* @package leioc-events-plugin
*
*/

namespace LEIOCevents\Blocks;

use \LEIOCevents\Api\LeiocDbCall;
use \LEIOCevents\Blocks\ResultsFunctions;

class ResultsData
{
    
    public function getResults($data)
    {
        $db = new LeiocDbCall();

        //Sanitize $year to number to prevent SQL injections
        $year = intval( esc_attr($data['year']) );
        if( empty($year) ) return;

        //Winter League Start Start and end date = '-09-01', '-03-31', else set to actual search year
        $start = empty($data['start']) ? $year.'-01-01' : ($year - 1).'-'.date('m-01',strtotime($data['start']) );
        $end = empty($data['end']) ? $year.'-12-31' : ($year + 1).'-'.date('m-t',strtotime($data['end']) );

        $sql = 'SELECT res_id, res_name, res_type, res_date, res_link FROM results';

        //bind search parameter to prevent SQL injection
        $query = $db->bindDataQuery($sql.' WHERE res_date >=? AND res_date <=? ORDER BY res_date DESC, res_id ASC', array($start, $end) );

        $results = new ResultsFunctions();

        $data['end'] = $year.'-'.date('m-d',strtotime($end));

        return $results->setResults($query,$data);

    }

    public function ajaxResults()
    {
        $formdata = json_decode( stripslashes($_POST['results_data']), true );
        $result = $this->getResults($formdata);

        $status = empty($result) ? 'error' : 'success';

        $return = array(
            'status' => $status,
            'result' => $result,
            'year'   => $formdata['year'],
        );

        wp_send_json( $return );

        wp_die();
    }

    public function getYears($page, $search, $numPag = 4)
    {
        $db = new LeiocDbCall();
        $year = date('Y');
        //Year Greater than 2010 to fix older results not in the results database
        $sql = "SELECT 'prev' as year FROM results UNION SELECT {$year} as year FROM results UNION SELECT DISTINCT YEAR(res_date) as year FROM results WHERE YEAR(res_date) > 2010 Order BY year DESC";

        $offset = self::offset($db->dataquery($sql), $search, $numPag);
        $limit = ' LIMIT '. $offset .', '. ($numPag+2);
        $query = $db->dataquery($sql . $limit);

        $years = new ResultsFunctions();

        return $years->setPagination($query, $page, $numPag);
    }

    private function offset($years, $search, $numPag)
    {
        if(empty($years) || empty($search)) return 0;
        $i = 0;
        //Removes prev from the list to correct the starting position
        array_shift($years);
        foreach($years as $year){
            if($year['year'] == $search) break;
            $i++;
        }
        //Sets $i to 0 if search year doesn't find a match
        $i = ($i > count($years) - 1 ? 0 : $i);
        //Sets $i to mimium from end to $numPag
        $i = (count($years) - $i < $numPag ? count($years) - $numPag : $i);
        //Checks that $i is not less than 0
        $i = $i < 0 ? 0 : $i;

        return $i;
    }

}