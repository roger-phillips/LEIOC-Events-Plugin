<?php
/**
* @package leioc-events-plugin
*
*/

namespace LEIOCevents\Blocks;

use \LEIOCevents\Blocks\EventController;
use \LEIOCevents\Api\MapsApi;

class EventFunctions extends EventController
{
    protected $eventDate;
    protected $event = array();

    protected $detailsLink;
    protected $html;
    protected $eventYear;
    protected $year;

    protected $wpdb;

    public function eventsToHtml($events, $detailsLink)
    {
        $str = explode('?',$detailsLink);
        $this->detailsLink = $str[0];

        if(empty($events) ) return '<tr><td colspan="3" class="text-center">Sorry nothing found.</td></tr>';

        foreach($events as $key => $value){
            $this->event = $value;
            $this->eventDate = $this->event['event_date'];
            $this->setDayMonth('day')->setSearchYear('year')->setSearchTable();
        }

        return $this->html;
    }

    public function eventDataToHtml( array $rowdata )
    {
        $this->event = $rowdata[0];

        $this->eventDate = $this->event['event_date'];

        $this->setType('event_type')->setDayMonthYr('day')->setBeginners('event_beginners')->setLevel('event_level')->setFees('event_fees')->setTimes()->setDayMonthYear('event_updated')->setDogs()->setGroups()->setCourses()->set_email_note('event_org_email')->set_phone_note('event_org_phone');

        return $this->event;
    }

    private function set_email_note($arg)
    {
        $value = $this->event[$arg];
        $this->event['event_org_email_note'] = '';
        if($value == ''){
            $this->event[$arg] = trim($value) ;
            return $this;
        }

        $split = explode(' ', $value);
        $this->event[$arg] = trim($split[0]);
        if( isset($split[1]) ){
            unset($split[0]);
            $note = implode(' ',$split);
            $this->event['event_org_email_note'] = $note;
        }
        return $this;
    }

    private function set_phone_note($arg)
    {
        $value = $this->event[$arg];
        $this->event['event_org_phone_note'] = '';
        if($value == ''){
            $this->event[$arg] = trim($value);
            return $this;
        }

        $matches = array();
        // returns all results in array $matches
        preg_match_all('/[0-9]{3}[\-][0-9]{8}|[0-9]{3}[\s][0-9]{8}|[0-9]{3}[\s][0-9]{3}[\s][0-9]{5}|[0-9]{11}|[0-9]{3}[\-][0-9]{3}[\-][0-9]{5}/', $value, $matches);
        $matches = $matches[0];

        if( isset($matches[0]) ){
            if( !empty($matches[0])){
                $this->event[$arg] = str_replace(' ', '', $matches[0]);
                $note = str_replace( $matches[0], '', $value);
                $this->event['event_org_phone_note'] = trim($note);
            }
        }        
        return $this;
    }

     /**
     * @param $arg where new Day, Month with ordinal stored
     */
    private function setDayMonth($arg)
    {
        $value = $this->eventDate;

        if( empty($value) ) return $this;

        $this->event[$arg] = date('l jS F',strtotime($value) );

        return $this;
    }
    /**
     * @param $arg where new Day, Month, Year with ordinal stored
     */
    private function setDayMonthYr($arg)
    {
        $value = $this->eventDate;

        if( empty($value) ) return $this;

        $this->event[$arg] = date('l jS F Y',strtotime($value) );
       
        return $this;
    }

    private function setDayMonthYear($arg)
    {
        $value = $this->event[$arg];

        if( empty( $value ) ) return $this;

        $this->event[$arg] = date('d-m-Y',strtotime($value) );

        return $this;
    }

    private function setSearchYear($arg)
    {
        if($this->event[$arg] == $this->year) return $this;
        $this->year = $this->event[$arg];
        $this->html .= sprintf('<tr class="leioc-search-year"><td colspan="3">%s</td></tr>', esc_attr($this->event[$arg]) );

        return $this;
    }

    private function setSearchTable()
    {
        if(empty($this->event) ) return $this;

        $event_flag = strtolower( esc_attr($this->event['event_flag']) );

        $class = 'leioc-search-' .$event_flag;
        $linkid = rawurlencode(' ' . esc_attr($this->event['event_id']) );

        $mapbtn = $this->setMapbtn($this->event['event_cp_grid'], $this->event['event_title'] );
        $link = $event_flag == 'x'? '': $mapbtn.'<a href="'. esc_attr($this->detailsLink) .'?item='. $linkid . '">Details</a>';
        $day = $event_flag == 'n' ? '' : esc_attr($this->event['day']);

        $this->html .= sprintf('<tr class="leioc-events-search"><td class="%s">%s</td><td class="%s">%s</td><td>%s</td></tr>', $class, $day, $class, esc_attr($this->event['event_title']), $link );

        return $this;
    }

    private function setMapbtn($gref, $title)
    {
        $target = '#leioc-search-map-modal';

        $mapApi = new MapsApi;
        $mapChk = $mapApi->chkGoogleApi();
        $chk = $mapApi->checkGrid($gref);
        $btn = '>';

        if( !empty($gref) && !empty($mapChk) && !empty($chk) )
        { 
            $mapData = $mapApi->getMapData($gref,12);
            $btn = 'data-toggle="modal" data-target="'. esc_attr($target) . '" data-map='. esc_attr($mapData) .' data-title="'. esc_attr($title).'"><a href="javascript:void(0)"><i class="fas fa-map-marker-alt"></i></a>';
        }
        return sprintf('<button type="button" class="leioc-map-btn" %s</button>',$btn);
    }

    private function setBeginners($arg)
    {
        $value = $this->event[$arg];

        if( empty($value) ) return $this;

        $value = strtolower( $value );
        $this->event[$arg] = $this->beginnersArr[$value];

        return $this;
    }

    private function setType($arg)
    {
        $value = $this->event[$arg];

        if( empty($value) ) return $this;
        if( strpos($value, 'Other') !== false ){

            if( empty( trim($this->event[$arg.'_other']) ) ) return $this;

            $this->event[$arg] = str_replace('Other',$this->event[$arg.'_other'],$value);
        }

        return $this;
    }

    private function setLevel($arg)
    {
        $value = $this->event[$arg];

        if( empty($value) ) return $this;

        $value = strtolower( $value );
        $this->event[$arg] = $this->levelArr[$value];

        return $this;
    }

    private function setFees($arg)
    {
        $date = $this->eventDate;
        $data = strtolower( $this->event[$arg] );

        if( empty($data) || empty ($date) ) return $this;

        $type = ($data == 'other' ? 'district' : $data);

        //Get Fees Data
        global $wpdb;
        $table = $wpdb->prefix . 'leioc_events_fees';

        $sql = $wpdb->prepare("SELECT fee_details FROM {$table} WHERE fee_type=%s AND fee_trash = 1 AND fee_date <=%s ORDER BY fee_date DESC", $type, $date);
        $fee =  maybe_unserialize( $wpdb->get_var( $sql ) );

        $this->event[$arg] = ( $data == 'other' ? $this->event[$arg.'_other'] : $fee['fee'] );
        if( !empty($this->event['event_si']) ) $this->setSiac( $fee );

        return $this;
    }

    private function setSiac( $args )
    {
        $si = $this->event['event_si'];
        $siac = strtolower($this->event['event_siac']) == 'yes' ? ' - Contactless SIAC available' : ' - Contactless SIAC not available';

        $si = ($si == 'y' ? $args['siac'] . $siac : ($si == 'n' ? 'Si not available' : ($si == 'tbc' ? 'Si Dibbers TBC' : 'Si Dibbers N/A') ) );

        $this->event['event_si'] = $si;
        return $this;
    }

    private function setTimes()
    {
        $times = array(
            'event_reg',
            'event_starts',
            'event_course_close',
            'event_time',
        );

        $event = $this->event;
        foreach($times as $time){
            $value = strtolower( str_replace(':', '.',$event[$time]) );

            $value = ($time == 'event_starts' && $value == '10' ? '10.30' : $value);
            $value = ($time == 'event_time' && $value == '6.30' ? '6.31' : $value);

            $other = $time . '_other';

            if( !isset($this->timesArr[$value]) ) continue;
            
            $this->event[$time] = (strtolower($value) == 'other' ? $this->event[$other] : $this->timesArr[$value]);
        }

        return $this;
    }

    private function setDogs()
    {
        $value = $this->event['event_dogs']; 

        if( empty( $value ) ) return $this;

        $value = strtolower($value);

        $this->event['event_dogs'] = ($value == 'lead' ? 'On lead only': ($value == 'no' ? 'No dogs allowed': ($value == 'yes' ? 'No restrictions' : ($value == 'cp' ? 'In car park only' : '') ) ) );

        return $this;
    }

    private function setGroups()
    {
        $value = $this->event['event_groups'];

        if( empty( $value ) ) return $this;

        $value = strtolower($value);
	    $this->event['event_groups'] = ($value == "y" ? $this->groupsArr['y'] : ($value== 'n' ? $this->groupsArr['n'] : "") );
                    
        return $this;
    }

    private function setCourses()
    {
        $value = $this->event['event_courses'];
        if( empty( $value ) ) return $this;

        $value = str_replace(';', ',',$value);

        $courses = explode(',', $value);
        $courseArr = $this->courseArr;

        $courseBlock = array();
		$matchChk = false;
		//Matchs course levels to stored info
		foreach($courses as $course){
			$arrMatch = preg_replace('/\s+/', '', (strtolower($course)));
            $matchChk = isset($courseArr[$arrMatch]) ?: false;

            $level = isset($courseArr[$arrMatch]['level']) ? $courseArr[$arrMatch]['level'] : '';
            $text = isset($courseArr[$arrMatch]['text']) ? $courseArr[$arrMatch]['text'] : '';
            
			array_push($courseBlock,array(trim($course), $level, $text ) );
        }
        
        $cLength = count($courseBlock);
	
        $courseTable = esc_attr($courseBlock[0][0]); //Displays first course
        //Builds Course Table
		for($i = 1; $i < $cLength; $i++){
            $block =  esc_attr($courseBlock[$i][0]);

			if ($courseBlock[$i-1][1] == $courseBlock[$i][1]) {
                $courseTable .= ( $i % 5 == 0 && $matchChk == false ? '</td><tr><td>' : ', ') . $block;
			} else {
				$courseTable.= sprintf('</td><td>%s</td></tr><tr><td>%s', ( $matchChk == true ? esc_attr($courseBlock[$i-1][2]): ''),  $block ); //Adds Course Description
			}
        };
        
        if($matchChk == true) $courseTable .='</td><td>'.$courseBlock[$cLength-1][2]; //Adds last course description

        $thead = sprintf('<thead><tr><th>Courses Available</th>%s</tr></thead>', ($matchChk === true ? '<th>Ideal For</th>' : '') );
        $table = sprintf('<table class="leioc-course-table %s" style="background: inherit;">%s<tbody><tr><td>%s</td></tr></tbody></table>', ($cLength >= 18 ? '.leioc-sm' : ''),$thead, $courseTable);

        $this->event['event_courses'] = $table;

        return $this;
    }
}