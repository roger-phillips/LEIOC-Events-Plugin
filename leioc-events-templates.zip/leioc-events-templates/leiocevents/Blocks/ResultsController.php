<?php
/**
* @package leioc-events-plugin
*
*/

namespace LEIOCevents\Blocks;


class ResultsController
{
    /**
     * Order of array is also Print Order 
     * wl2 = the Previous Years Winter League
     */
    protected $type = array(
        'level c'   => 'Level C and above',
        'wl'        => 'Winter League',
        'sl'        => 'Summer League',
        'sch'       => 'Schools Events',
        'wl2'       => 'Winter League',
        'cn'        => 'Club Night',
        'ul'        => 'Urban League',
        'bis'       => 'Beginners Introductory Series',
        'as'        => '5 Parks Challenge',
        'as2'       => 'Autum Series',
        'ss'        => 'Spring Series',
        'sv'        => 'StreetView O',
        'coach'     => 'Coaching Event',
    );
}