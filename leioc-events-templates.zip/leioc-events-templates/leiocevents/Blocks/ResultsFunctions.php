<?php
/**
* @package leioc-events-plugin
*
*/

namespace LEIOCevents\Blocks;

use \LEIOCevents\Blocks\ResultsController;

class ResultsFunctions extends ResultsController
{

    public $resultType = array();

    public $html;

    public $year;

    public $wlEnd;

    public function setResults($results,$data)
    {
        if( empty($results) ) return '<div class="leioc-no-results">Sorry, no results found in our database.</div>';

        $this->year = esc_attr($data['year']);
        $this->wlEnd =  esc_attr($data['end']) ?:  $this->year.'-03-31';
        $this->setResultType($results);

        $this->setHtml();

        //Sets out Print order
        foreach($this->type as $key => $value){
            if($key == 'wl' && empty($this->resultType[$key])) $key = $key.$this->year.'/'.($this->year+1);
            if($key == 'wl2') $key = 'wl'.($this->year-1).'/'.$this->year;

            isset($this->resultType[$key]) ? $this->html .= $this->resultType[$key] : '';
        }

        return $this->html;
    }

    public function setPagination($years, $page, $numPag)
    {
        if(empty($years) ) return;

        $page = $page . '?item=';
        $class = $numPag == 1 ? 'leioc-xs-display' : '';

        $first = count($years) > 1 ? array_shift($years) : 'prev';
        $first = ($first['year'] == 'prev' ? '#' : $page . $first['year']);
        $last = count($years) > $numPag ? array_pop($years) : '#';
        $last = $last == '#' ? $last : $page . $last['year'];

        $prev = $this->set_pag_end( ($first == '#' ? ' class="disabled"' : '') , $first, 'Previous','left');
        $next= $this->set_pag_end( ($last == '#' ? ' class="disabled"' : '') , $last, 'Next','right');
        
        $num = '';
        foreach($years as $key => $year)
        {
            $yr= esc_attr($year['year']);
            $num .= sprintf('<li><a href="%s%d">%d</a></li>', $page, $yr, $yr);
        }

        $small_last = count($years) > 1 ? $years[1] : '#';
        $small_last = $small_last == '#' ? $small_last : $page . $small_last['year'];

        $pag = sprintf('<div class="leioc-results-pagination '. $class . '"><nav><ul>%s %s %s</ul></nav></div>', $prev,$num, $next);

        return $pag;
    }

    private function set_pag_end( $disabled, $link, $label, $arrow)
    {
        return sprintf('<li %s><a href="%s"><i aria-hidden="true" aria-label="%s" class="fas fa-chevron-%s"></i></a></li>', $disabled, $link, $label, $arrow);
    }

    private function setResultType($results)
    {
        foreach($results as $result)
        {
            $type = strtolower( esc_attr($result['res_type']) );
            //This deals with the as tag is reused for the 5 Parks Challenge
            if($type == 'as' && $this->year < '2011') $type = 'as2';

            $res_year = date('Y',strtotime($result['res_date'] ) );
            if($type != 'wl' && ($res_year != $this->year) ) continue; //Removes data not in Winter League and search year
            $this->resultType[$type][] = $result;
        }

        $this->setWinterLeague();

        return;
    }

    private function setWinterLeague()
    {
        $wl = isset($this->resultType['wl']) ? $this->resultType['wl'] :'';
        if( empty($wl) ) return;

        $wlSplit = [];

        foreach($wl as $result){
            $prevYear = $this->year -1;
            $nextYear = $this->year + 1;
            $result['res_year'] = strtotime($result['res_date']) <= strtotime($this->wlEnd) ? ( $prevYear.'/'.$this->year ): ($this->year . '/'.$nextYear);

            strtotime($result['res_date']) <= strtotime($this->wlEnd) ? $wlSplit[$this->year][] = $result : $wlSplit[$nextYear][] = $result;
        }

        $this->resultType['wl'] = $wlSplit;

        return;
    }

    private function setHtml()
    {
        foreach($this->resultType as $key => $value){
            $this->setList($key);
        }

        return;
    }

    private function setList($key)
    {
        $type = $this->resultType[$key];

        $title = '<div class="leioc-results-title">'.$this->type[$key];
        $links = '';

        if($key == 'wl') {
            //Deals with 2 Winter Leagues in a Search Year
            foreach($type as $value){
                $links = '';
                $links .= $title .' '.$value[0]['res_year'].'</div><ul class="leioc-results">';
                $links .= $this->setLinks($value) . '</ul>';

                $this->resultType[$key.$value[0]['res_year']] = $links;
            }

            unset($this->resultType[$key]);

        } else {
            $links .= $title .'</h3></div><ul class="leioc-results">';
            $links .= $this->setLinks($type) . '</ul>';

            $this->resultType[$key] = $links;
        }

        return ;
    }

    private function setLinks($results)
    {
        $links = '';
        foreach($results as $result){
            $title = esc_attr($result['res_name']).' - ' . $this->setDayMonth($result['res_date'] );
            $links .= sprintf('<li><a href="%s">%s</a></li>', esc_attr($result['res_link']), $title );
        }

        return $links;
    } 

    /**
     * @param $value where new Day, Month with ordinal stored
     */
    private function setDayMonth($value)
    {
        if( empty($value) ) return;

        return date('jS F Y',strtotime($value) );
    }
}