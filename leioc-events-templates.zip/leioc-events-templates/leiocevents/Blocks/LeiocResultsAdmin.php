<?php
/**
* @package leioc-events-plugin
*
*/

namespace LEIOCevents\Blocks;

use \LEIOCevents\Api\LeiocDbCall;

class LeiocResultsAdmin
{

    public function resultsSanitize(){

        $db = new LeiocDbCall();

        if( isset($_POST['edit_result']) ){

            $sql = "SELECT * FROM results WHERE res_id = ?";

            $result = $db->bindDataQuery($sql, [$_POST['edit_result']] );

            $result = $result[0];

            return $result;
        }


        if( isset($_POST['remove']) ) {

            $sql = "DELETE FROM results WHERE res_id = ?";

            $result = $db->bindDataQuery($sql, [$_POST['remove']], 'return');

            return;
        }
        

        if( !isset($_POST['result_submit']) ) return;

        $result = $_POST;


        foreach($result as $key => $value){

            $result[$key] = trim( esc_attr($value) );

        }

        $result['res_year'] = date('Y',strtotime($result['res_date']) );

        $this->addResult($result);

        return;
    }

    private function addResult($result){

        $db = new LeiocDbCall();

        $sql = "REPLACE INTO results (res_id, res_name, res_type, res_date, res_year, res_link) 
        VALUES ( ?, ?, ?, ?, ?, ? )";

        $values = [$result['res_id'], $result['res_name'], $result['res_type'], $result['res_date'], $result['res_year'], $result['res_link']];

        $result = $db->bindDataQuery($sql, $values, 'return');

        return;
    }

    public function showResults(){

        $db = new LeiocDbCall();

        $today = date('Y-m-d');

        $sql = 'SELECT res_id, res_name, res_date FROM results ORDER BY res_date DESC, res_id ASC';

        $result = $db->dataquery($sql);

        $table = '';
        $year = '';

        foreach($result as $value){
            $edit = $this->addEdit($value['res_id']).' '.$this->addDelete($value['res_id']);

            $res_year = date('Y',strtotime($value['res_date']) );
            if($res_year != $year){
                $table .= '<tr class="leioc-year"><td colspan=4>'.$res_year.'</td></tr>';
                $year = $res_year;
            }

            $table .= '<tr><td>'.$value['res_id'].'</td><td>'.date('D jS M Y',strtotime($value['res_date'])).'</td><td>'.$value['res_name'].'</td><td>'.$edit.'</td></tr>';
        }

        return $table;
    }

    private function addDelete($arg){

        $form  = '<form method="post" class="inline-block">';
        $form .= '<input type="hidden" name="remove" value="'.$arg.'">';
        $form .= '<input type="submit" value="Delete" class="leioc-admin-btn" onclick="return confirm(\'Are you sure you wish to delete this result?\')">';
        $form .= '</form>';

        return $form;
    }

    private function addEdit($arg){

        $form  = '<form method="post" class="inline-block">';
        $form .= '<input type="hidden" name="edit_result" value="'.$arg.'">';
        $form .= '<input type="submit" value="Edit" class="leioc-admin-btn leioc-edit-btn">';
        $form .= '</form>';

        return $form;
    }

    public function ckDB(){
        $db = new LeiocDbCall();

        if($db->checkDB() == false) return  false;
         
        return  true;
    }

    public function uploadResultsFile(){

        $root = ABSPATH;

        $folder = isset( $_POST['upload_path'] ) ? $_POST['upload_path'] : '/wordpress/lei_results/';

        $folder = $folder . trim($_POST['leioc-result-folder']);

        $path = $root. $folder;

        if (! is_dir($path) ) { 
            wp_mkdir_p($path);
        }

        if( isset($_FILES['uploaded_file']) ){
            
            $files = [];

            foreach ($_FILES['uploaded_file']['name'] as $i => $filename) {

                $filename = basename( $filename );
                
                if( move_uploaded_file($_FILES['uploaded_file']['tmp_name'][$i], $path . $filename) ){
                    array_push($files, $filename);
                }

            }

            $message = count($files) > 1 ? 'The files '. join(', ',$files) . ' have been uploaded.' : 'The file '. join(', ',$files) .' has been uploaded.';

            $return = array(
                'status' => 'success',
                'msg' => $message,
                'filepath' => site_url($folder) . $_FILES['uploaded_file']['name'][( isset($_POST['file_choice'])  ? $_POST['file_choice'] : 0 )],
            );

            wp_send_json( $return );
            wp_die();
        }

        $return = array(
            'status' => 'error',
        );

        wp_send_json( $return );
    
        wp_die();
    }

}