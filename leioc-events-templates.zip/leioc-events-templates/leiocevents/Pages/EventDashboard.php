<?php
/**
*@package leioc-events-plugin
*
*/

namespace LEIOCevents\Pages;

use \LEIOCevents\Api\SettingsApi;
use LEIOCevents\Base\BaseController;
use \LEIOCevents\Api\Callbacks\AdminCallbacks;
use \LEIOCevents\Api\Callbacks\EventsCallbacks;

class EventDashboard extends BaseController
{

    public $callbacks;

    public $subpages = array();
    

    public function register(){

        $this->settings = new SettingsApi();

        $this->callbacks = new AdminCallbacks();

        $this->setSubpages();

        $this->settings->addSubPages( $this->subpages )->register();

    }

    public function setSubpages(){
        $this->subpages = array(
            array(
                'parent_slug' => 'leioc_events_dashboard',
                'page_title'  => 'Events' , 
                'menu_title'  => 'Events' ,
                'capability'  => 'edit_posts' , 
                'menu_slug'   => 'leioc_events_database', 
                'callback'    => array( $this->callbacks, 'EventsDashboard'),
            )
        );
    }
}