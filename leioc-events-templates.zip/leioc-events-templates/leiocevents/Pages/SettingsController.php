<?php
/**
*@package leioc-events-plugin
*
*/

namespace LEIOCevents\Pages;

use \LEIOCevents\Api\SettingsApi;
use LEIOCevents\Base\BaseController;
use \LEIOCevents\Api\Callbacks\AdminCallbacks;
use \LEIOCevents\Api\Callbacks\SettingsCallbacks;

class SettingsController extends BaseController
{
    public $callbacks;

    public $settings_callbacks;

    public $subpages = array();


    public function register(){

        $this->settings = new SettingsApi();

        $this->callbacks = new AdminCallbacks();

        $this->settings_callbacks = new SettingsCallbacks();

        $this->setSettings();

		$this->setSections();

		$this->setFields();

        $this->setSubpages();

        $this->settings->addSubPages( $this->subpages )->register();

    }

    public function setSubpages(){
        $this->subpages = array(
            array(
                'parent_slug' => 'leioc_events_dashboard',
                'page_title'  => 'Settings' , 
                'menu_title'  => 'Settings' ,
                'capability'  => 'manage_options' , 
                'menu_slug'   => 'leioc_events_settings', 
                'callback'    => array( $this->callbacks, 'settingsDashboard'),
            )
        );
    }

    public function setSettings(){

        $args = array(
            array(
                'option_group' => 'leioc_events_settings_dashboard',
                'option_name'  => 'leioc_events_settings',
                'callback'     => array( $this->settings_callbacks, 'settingsSanitize' ),
            ),
            array(
                'option_group' => 'leioc_map_settings_dashboard',
                'option_name'  => 'leioc_events_settings',
                'callback'     => array( $this->settings_callbacks, 'mapsettingsSanitize' ),
            ),
            array(
                'option_group' => 'leioc_database_dashboard',
                'option_name'  => 'leioc_events_database',
                'callback'     => array( $this->settings_callbacks, 'leiocdatabaseSanitize' ),
            ),
        );

        $this->settings->setSettings( $args );
    }

    public function setSections(){
        $args = array(
            array(
                'id'       => 'leioc_events_settings_index',
                'title'    => 'Event Details Manager',
                'callback' => array( $this->settings_callbacks, 'settingsSectionManger' ),
                'page'     => 'leioc_events_settings',
            ),
            array(
                'id'       => 'leioc_map_index',
                'title'    => 'Maps API Manager',
                'callback' => array( $this->settings_callbacks, 'mapSectionManger' ),
                'page'     => 'leioc_map_settings',
            ),
            array(
                'id'       => 'leioc_database_index',
                'title'    => 'LEIOC Database Manager',
                'callback' => array( $this->settings_callbacks, 'databaseSectionManger' ),
                'page'     => 'leioc_database_settings',
            ),
        );

        $this->settings->setSections( $args );
    }

    public function setFields(){

        $args = array(
            array(
				'id' => 'default_act_text',
				'title' => 'Default Activity Text',
				'callback' => array( $this->settings_callbacks, 'textArea' ),
				'page' => 'leioc_events_settings',
				'section' => 'leioc_events_settings_index',
				'args' => array(
                    'option_name' => 'leioc_events_settings',
                    'label_for' => 'default_act_text',
                    'placeholder' => '',
				)
            ),
            array(
				'id' => 'privacy_policy_url',
				'title' => 'Event Privacy Policy URL',
				'callback' => array( $this->settings_callbacks, 'textField' ),
				'page' => 'leioc_events_settings',
				'section' => 'leioc_events_settings_index',
				'args' => array(
                    'option_name' => 'leioc_events_settings',
                    'label_for' => 'privacy_policy_url',
                    'placeholder' => '',
                    'type' => 'url',
				)
            ),
            array(
				'id' => 'first-event-url',
				'title' => 'First Event Details URL',
				'callback' => array( $this->settings_callbacks, 'textField' ),
				'page' => 'leioc_events_settings',
				'section' => 'leioc_events_settings_index',
				'args' => array(
                    'option_name' => 'leioc_events_settings',
                    'label_for' => 'first-event-url',
                    'placeholder' => '',
                    'type' => 'url',
				)
            ),
            array(
				'id' => 'event-details-url',
				'title' => 'Event Details Page URL',
				'callback' => array( $this->settings_callbacks, 'textField' ),
				'page' => 'leioc_events_settings',
				'section' => 'leioc_events_settings_index',
				'args' => array(
                    'option_name' => 'leioc_events_settings',
                    'label_for' => 'event-details-url',
                    'placeholder' => '',
                    'type' => 'url',
				)
            ),
            array(
				'id' => 'leioc_map_api',
				'title' => 'Google Map API Key',
				'callback' => array( $this->settings_callbacks, 'textField' ),
				'page' => 'leioc_map_settings',
				'section' => 'leioc_map_index',
				'args' => array(
					'option_name' => 'leioc_events_settings',
					'label_for' => 'leioc_map_api',
                    'placeholder' => 'Google API key',
				)
			),
			array(
				'id' => 'leioc_map_use',
				'title' => 'Use Google Maps',
				'callback' => array( $this->settings_callbacks, 'checkboxField' ),
				'page' => 'leioc_map_settings',
				'section' => 'leioc_map_index',
				'args' => array(
					'option_name' => 'leioc_events_settings',
					'label_for' => 'leioc_map_use',
                    'class' => 'ui-toggle',
				)
            ),
            array(
                'id' => 'leioc_database_host',
                'title' => 'Database Host',
                'callback' => array( $this->settings_callbacks, 'textField' ),
                'page' => 'leioc_database_settings',
                'section' => 'leioc_database_index',
                'args' => array(
                    'option_name' => 'leioc_events_database',
                    'label_for' => 'leioc_database_host',
                    'placeholder' => 'Database Host',
                )
            ),
            array(
                'id' => 'leioc_database_user',
                'title' => 'Database User',
                'callback' => array( $this->settings_callbacks, 'textField' ),
                'page' => 'leioc_database_settings',
                'section' => 'leioc_database_index',
                'args' => array(
                    'option_name' => 'leioc_events_database',
                    'label_for' => 'leioc_database_user',
                    'placeholder' => 'Database User',
                )
            ),
            array(
                'id' => 'leioc_database_password',
                'title' => 'Database Password',
                'callback' => array( $this->settings_callbacks, 'textField' ),
                'page' => 'leioc_database_settings',
                'section' => 'leioc_database_index',
                'args' => array(
                    'option_name' => 'leioc_events_database',
                    'label_for' => 'leioc_database_password',
                    'placeholder' => 'Database Password',
                    'type' => 'password',
                )
            ),
            array(
                'id' => 'leioc_database_name',
                'title' => 'Database Name',
                'callback' => array( $this->settings_callbacks, 'textField' ),
                'page' => 'leioc_database_settings',
                'section' => 'leioc_database_index',
                'args' => array(
                    'option_name' => 'leioc_events_database',
                    'label_for' => 'leioc_database_name',
                    'placeholder' => 'Database Name',
                )
            ),
        );

        $this->settings->setFields( $args );
    }
}