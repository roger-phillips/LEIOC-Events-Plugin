<?php
/**
* @package leioc-events-plugin
*
*/

namespace LEIOCevents\Pages;

use \LEIOCevents\Api\SettingsApi;
use \LEIOCevents\Base\BaseController;
use \LEIOCevents\Api\Callbacks\AdminCallbacks;
use \LEIOCevents\Api\Callbacks\MangerCallbacks;

class Dashboard extends BaseController
{
    public $settings;

    public $callbacks;

    public $callbacks_mngr;

    public $pages = array();

    public function register(){
        $this->settings = new SettingsApi();

        $this->callbacks = new AdminCallbacks();

        $this->callbacks_mngr = new MangerCallbacks();

        $this->setPages();

        $this->setSettings();

        $this->setSections();

        $this->setFields();

        $this->settings->addPages( $this->pages )->withSubPage( 'Fees' )->register();
    }

    public function setPages(){
        $this->pages = array(
            array(
                'page_title' => 'LEIOC Events Plugin' , 
                'menu_title' => 'LEIOC Events' ,
                'capability' => 'manage_options' , 
                'menu_slug'  => 'leioc_events_dashboard', 
                'callback'   => array( $this->callbacks, 'adminDashboard'),
                'icon_url'   => 'dashicons-location', 
                'position'    =>  110
            )
        );
    }

    public function setSettings(){

        $args = array(
            array(
                'option_group' => 'leioc_events_fees_settings',
                'option_name'  => 'leioc_events_fees',
                'callback'     => array( $this->callbacks_mngr, 'feesSanitize' ),
            ),
        );

        $this->settings->setSettings( $args );
    }

    public function setSections(){
        $args = array(
            array(
                'id'       => 'leioc_fees_index',
                'title'    => 'Settings Manager',
                'callback' => array( $this->callbacks_mngr, 'feesSectionManger' ),
                'page'     => 'leioc_fees_settings',
            )
        );

        $this->settings->setSections( $args );
    }

    public function setFields(){

        $args = array(
			array(
				'id' => 'id',
				'title' => '',
				'callback' => array( $this->callbacks_mngr, 'textField' ),
				'page' => 'leioc_fees_settings',
				'section' => 'leioc_fees_index',
				'args' => array(
					'option_name' => 'leioc_events_fees',
					'label_for' => 'id',
                    'placeholder' => '',
                    'type' => 'hidden',
				)
			),
            array(
				'id' => 'type',
				'title' => 'Event Type',
				'callback' => array( $this->callbacks_mngr, 'optionField' ),
				'page' => 'leioc_fees_settings',
				'section' => 'leioc_fees_index',
				'args' => array(
                    'option_name' => 'leioc_events_fees',
                    'options' => array(
                        'local' => 'Local',
                        'regional' => 'Regional',
                        'activity' => 'Activity',
                    ),
					'label_for' => 'type',
				)
            ),
			array(
				'id' => 'fee',
				'title' => 'Event Fees',
				'callback' => array( $this->callbacks_mngr, 'textArea' ),
				'page' => 'leioc_fees_settings',
				'section' => 'leioc_fees_index',
				'args' => array(
					'option_name' => 'leioc_events_fees',
					'label_for' => 'fee',
                    'placeholder' => 'Set Fees',
				)
            ),
            array(
				'id' => 'siac',
				'title' => 'Si Dibber Hire',
				'callback' => array( $this->callbacks_mngr, 'textArea' ),
				'page' => 'leioc_fees_settings',
				'section' => 'leioc_fees_index',
				'args' => array(
					'option_name' => 'leioc_events_fees',
					'label_for' => 'siac',
                    'placeholder' => 'Set Fees',
				)
            ),
            array(
				'id' => 'date',
				'title' => 'Fee Start Date',
				'callback' => array( $this->callbacks_mngr, 'textField' ),
				'page' => 'leioc_fees_settings',
				'section' => 'leioc_fees_index',
				'args' => array(
					'option_name' => 'leioc_events_fees',
					'label_for' => 'date',
                    'type' => 'date',
                    'placeholder' => '',
				)
			),
            array(
				'id' => 'fee_trash',
				'title' => '',
				'callback' => array( $this->callbacks_mngr, 'textField' ),
				'page' => 'leioc_fees_settings',
				'section' => 'leioc_fees_index',
				'args' => array(
					'option_name' => 'leioc_events_fees',
					'label_for' => 'fee_trash',
                    'type' => 'hidden',
                    'placeholder' => '',
				)
			),
		);

        $this->settings->setFields( $args );
    }

    public function leioc_fees_submit()
	{
		if (! DOING_AJAX || ! check_ajax_referer('leioc-events-fees-nonce', 'nonce') ) {
			return $this->return_json('error');
        }

        global $wpdb;
        $table = $wpdb->prefix . 'leioc_events_fees';

        $id = sanitize_text_field( trim( intval($_POST['id']) ) );

        $type = sanitize_text_field( trim($_POST['type']) );
        $this->check_valid($type);
        $date = sanitize_text_field( trim($_POST['date']) );
        $this->check_valid($date);
        //Saves allowed html like br tags etc
        $fee = wp_kses( trim($_POST['fee']), $this->allowed_html);
        $this->check_valid($fee);
        $siac = sanitize_text_field( trim($_POST['siac']) );
        $this->check_valid($siac);

        $trash = sanitize_text_field(  trim($_POST['fee_trash']) );

        $details = array( 
            'type' => $type,
            'fee' => $fee,
            'date' => $date,
            'siac' => $siac,
        );

        $args = array(
            'id' => $id,
            'fee_type' => $type,
            'fee_date' => $date,
            'fee_details' =>  maybe_serialize( $details ),
            'fee_publish' => 1,
            'fee_trash' => !empty($trash) ? $trash : 1,
        );

        $sql = $wpdb->prepare( "SELECT id FROM $table WHERE id = %d", $id);
		$check = $wpdb->get_col( $sql );
        
		if(count($check) >= 1){
			$update = $wpdb->update($table, $args, array( 'id' => $id ));
			return $this->return_json('success', 'Updated in the fees database.');
		} else {
			$form = $wpdb->insert($table, $args);
			if ($form) {
				return $this->return_json( 'success', 'Added to the fees database.');
			}
		}

        return $this->return_json('error');
    }

    public function check_valid( $arg )
    {
        if( $arg != '' ) return;
        return $this->return_json('error');
    }

    public function return_json($status, $data = null)
	{
		$return = array(
            'status' => $status,
			'data' => $data,
		);
		wp_send_json($return);

		wp_die();
	}

}