<?php
/**
* 
* @author Roger Phillips
*
* @package leioc-events-plugin
*
*/

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

use \LEIOCevents\Base\BaseController;
$base = new BaseController;

$results_info =  nl2br( wp_kses( block_value('results-info'), $base->allowed_html) );

include $base->plugin_path.'blocks/leioc-results/templates/shortcode-shared.php';