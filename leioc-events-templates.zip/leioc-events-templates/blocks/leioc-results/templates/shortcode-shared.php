<?php
/**
* 
* @author Roger Phillips
*
* @package leioc-events-plugin
*
*/

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

//Results info set by Block value or Shortcode value

use \LEIOCevents\Blocks\ResultsData;
global $wp;

$year = !isset($_GET['item']) ? date('Y') : intval( esc_attr($_GET['item']) );
$current_url = home_url( add_query_arg( array(), $wp->request ) );
//Sets Winter League Year
$data = array(
    'year'  => $year,
    'start' => 'September',
    'end'   => 'March',
);

$resultData = new ResultsData;
$result = $resultData->getResults($data);
$years = $resultData->getYears($current_url, $year) . $resultData->getYears($current_url, $year, 1);

?>

<div class="leioc-results-wrapper">
    
    <div class="leioc-results-year"> 
        <div class="leioc-title"><?php echo esc_attr($year) ?></div>
    </div>

    <form id="leioc-results-search-form" method="get" action="#" data-url="<?php echo admin_url('admin-ajax.php'); ?>">
        <div id="leioc-search-year">
            <?php echo $years; ?>
        </div>

        <input type="hidden" id="leioc_result_data" name="results_data" value='<?php echo wp_json_encode($data); ?>' aria-hidden="true">
        <input type="hidden" name="action" value="leioc_results_search" aria-hidden="true"> 
        <input type="hidden" name="nonce" value="<?php echo wp_create_nonce( 'leioc_results_search_nonce' ); ?>" aria-hidden="true"> 
    </form>

    <div class="leioc-spinner"></div>

    <div class="leioc-results-info">     
        <?php echo isset($results_info) ? $results_info : ''; ?>
    </div>

    <div class="leioc-results-block">
        <?php echo $result; ?>
    </div>

</div>