<?php
/**
* 
* @author Roger Phillips
*
* @package leioc-events-plugin
*
*/

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

use \LEIOCevents\Blocks\LeiocResultsAdmin;


$admin = new LeiocResultsAdmin;

$edit = $admin->resultsSanitize();

$dbcheck = $admin->ckDB();

if(is_user_logged_in() == false){

    echo 'You need to be logged in to use this page';

    return;
}

//Set File Upload File Path
$path = esc_attr( block_value('leioc-filepath') ) ?: '/wordpress/lei_results/';

$results = $admin->showResults();

?>

<div id="leioc-results-admin-wrapper">

    <?php echo isset($_POST['result_submit']) ? '
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>'.$_POST['res_name'].'</strong> saved to the results database.
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>' : '' ; ?>

    <ul class="leioc-nav-tabs">
        <li class="<?php echo !isset($_POST['edit_result']) ? 'active' : '' ?>"><a href="#tab-1">Manage Results</a><li>
        <li class="
            <?php echo isset($_POST['edit_result']) ? 'active' : '' ?>
            <?php if($dbcheck == false) echo ' leioc-db-error' ?>"><a href="#tab-2" id="form-tab"><?php echo !isset($_POST['edit_result']) ? 'Add New Result' : 'Edit Result' ?></a><li>
        <li><a href="#tab-3">File Upload</a><li>
    </ul>


    <div class="tab-content">

        <div id="tab-1" class="tab-pane <?php echo !isset($_POST['edit_result']) ? 'active' : '' ?>">
            <div>
                <h4>Results Listed in the LEIOC Results Database.</h4>
            </div>
            <div style="overflow-x:auto;">
                <table id="leioc-events-admin-table">
                    <thead>
                        <tr>
                            <th>ID</th><th>Date</th><th>Name</th><th>Edit</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php echo $results ?>
                    </tbody>
                </table>
                <?php if($dbcheck == false) echo '<h5 class="leioc-db-error">Check Database settings on the LEIOC Events Dashboard</h5>';?>
            </div>
        </div>

        <div id="tab-2" class="tab-pane <?php echo isset($_POST['edit_result']) ? 'active' : ''; ?>">
        <div class="leioc-admin-form-title">
            <?php echo isset($_POST['edit_result']) ? 'Edit Result':'Add New Result' ?>
        </div>

        <input class="leioc-admin-reset" type="button" value="<?php echo isset($_POST['edit_result']) ? 'Add New Result' : 'Clear Form'; ?>">

        <form method="post" action="" id="leioc-results-form">

            <hr>

            <div class="required"> 
                <label class="leioc-info" style="color:red;">required</label>
            </div>

            <div class="row">
                <div class="col-lg-4">
                    <div class="form-group">
                        <label for="res_id" class="leioc-form-label">ID</label>
                        <input type="text" id="res_id" name="res_id" class="form-control" value="<?php echo $edit['res_id'] ?: ''?>" readonly>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="form-group required">
                        <label for="event_flag" class="leioc-form-label">Result Type</label>
                        <select class="form-control" id="res_type" name="res_type" required>
                            <option value="">Choose...</option>
                            <option <?php echo $edit['res_type'] == 'level c' ? 'Selected': ''?> value="level c">Level C or above</option>
                            <option <?php echo $edit['res_type'] == 'sl' ? 'Selected': ''?> value="sl">Summer League Event</option>
                            <option <?php echo $edit['res_type'] == 'wl' ? 'Selected': ''?> value="wl">Winter League Event</option>
                            <option <?php echo $edit['res_type'] == 'sch' ? 'Selected': ''?> value="sch">Schools Event</option>
                            <option <?php echo $edit['res_type'] == 'ul' ? 'Selected': ''?> value="ul">Urban League</option>
                            <option <?php echo $edit['res_type'] == 'cn' ? 'Selected': ''?> value="cn">Club Night Event</option>
                            <option <?php echo $edit['res_type'] == 'bis' ? 'Selected': ''?> value="bis">Beginners Introductory Series</option>
                            <option <?php echo $edit['res_type'] == 'as' ? 'Selected': ''?> value="as">Autumn Series</option>
                            <option <?php echo $edit['res_type'] == 'ss' ? 'Selected': ''?> value="ss">Spring Series</option>
                            <option <?php echo $edit['res_type'] == 'sv' ? 'Selected': ''?> value="sv">Street View O</option>
                            <option <?php echo $edit['res_type'] == 'coach' ? 'Selected': ''?> value="coach">Coaching Event</option>
                        </select>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="form-group required">
                        <label for="res_date" class="leioc-form-label">Result Date</label>
                        <input type="date" id="res_date" name="res_date" class="form-control" value="<?php echo $edit['res_date'] ?: ''?>" required>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-12">
                    <div class="form-group required">
                        <label for="res_name" class="leioc-form-label">Result Name</label>
                        <input type="text" maxlength="500" id="res_name" name="res_name" class="form-control" value="<?php echo $edit['res_name'] ?: ''?>" required>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-12">
                    <div class="form-group required">
                        <label for="res_link" class="leioc-form-label">Result Link</label>
                        <input type="url" maxlength="100" id="res_link" name="res_link" class="form-control" value="<?php echo $edit['res_link'] ?: site_url($path) ?>" required>
                        <small class="text-muted">Default path is <?php echo site_url($path);?></small>  
                    </div>
                    <div data-toggle="modal" data-target="#resultsModal" data-title="Results Details Upload" id="result-details-modal-btn"><i class="fas fa-file-upload"></i> Upload Results</div>
                </div>
            </div>

            <div class="form-group">
                <input type="submit" id="result_submit" name="result_submit" class="form-control btn-primary">
            </div>

        </form>

        </div>

        <div id="tab-3" class="tab-pane">
            <div class="col-12">

            <div class="leioc-event-form-result"></div>

            <div class="leioc-admin-form-title">
                Upload files to Results Database
            </div>
            <form enctype="multipart/form-data" action="#" method="post" class="leioc-event-form-upload" id="leioc-result-form-upload" data-url="<?php echo admin_url('admin-ajax.php'); ?>">
                <div class="row">
                    <div class="col-12">
                        <div class="form-group row">
                            <div class="col-8">
                                <input type="text" maxlength="500" id="leioc-result-folder" name="leioc-result-folder" class="form-control" value="<?php echo date('Y').'/'; ?>" placeholder="2020/summer-league/">
                                <small class="text-muted">Change folder destination</small>
                            </div>
                            <label for="leioc-result-folder" class="col-lg-4 col-form-label leioc-form-label">Results Folder</label>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-8">
                        <div class="custom-file">
                            <input type="file" class="custom-file-input leioc-event-upload" id="leioc-event-upload" name="uploaded_file[]" multiple>
                            <label class="custom-file-label" for="leioc-event-upload">Choose file . . .</label>
                            <small class="text-muted">Drag and drop files</small>
                        </div>
                    </div>
                    <div class="col-1">
                        <button id="event_file_upload" type="submit" name="event_file_upload" class="leioc-file-upload-btn" disabled>Upload</button>
                    </div>
                </div>
                <input type="hidden" id="upload_path" name="upload_path" value="<?php echo $path; ?>">
                <input type="hidden" name="action" value="leioc_results_file_upload">
                <input type="hidden" name="nonce" value="<?php echo wp_create_nonce( 'leioc_file_upload_nonce' ); ?>">
            </form>

            </div>
            </div>

        </div>

    </div>

    <!-- Modal -->
    <div class="modal fade" id="resultsModal" tabindex="-1" role="dialog" aria-labelledby="resultsModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Upload files to Results Database</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">

                <div class="col-12">

                <div class="leioc-event-form-result"></div>

                <form enctype="multipart/form-data" action="#" method="post" class="leioc-event-form-upload" id="leioc-result-form-upload-modal" data-url="<?php echo admin_url('admin-ajax.php'); ?>">
                    <div class="row">
                        <div class="col-12">
                            <div class="form-group">
                                <label for="leioc-result-folder" class="leioc-form-label">Results Folder</label>
                                <input type="text" maxlength="500" id="leioc-result-folder" name="leioc-result-folder" class="form-control" value="<?php echo date('Y').'/'; ?>" placeholder="2020/summer-league/">
                                <small class="text-muted">Change folder destination</small>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="form-group" id="leioc-result-filechoice"></div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12">
                            <div class="custom-file">
                                <input type="file" class="custom-file-input leioc-event-upload" id="leioc-result-upload" name="uploaded_file[]" multiple>
                                <label class="custom-file-label" for="leioc-event-upload">Choose file . . .</label>
                                <small class="text-muted">Drag and drop files</small>
                            </div>
                        </div>
                    </div>

                    <input type="hidden" id="upload_path" name="upload_path" value="<?php echo $path; ?>">
                    <input type="hidden" name="action" value="leioc_results_file_upload">
                    <input type="hidden" name="nonce" value="<?php echo wp_create_nonce( 'leioc_file_upload_nonce' ); ?>">

                    <div class="form-group">
                        <input type="submit" class="leioc-file-upload-btn btn btn-primary" id="result_file_upload" name="event_file_upload" value="Upload" disabled>
                    </div>
                    
                </form>

                </div>
                </div>

                </div>
            </div>
        </div>
    </div>

</div>