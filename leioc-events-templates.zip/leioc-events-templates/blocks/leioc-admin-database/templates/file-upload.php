<?php
/**
* 
* @author Roger Phillips
*
* @package leioc-events-plugin
*
*/

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;
?>
<div class="leioc-col-12">
    <div class="leioc-event-form-result"></div>
    <div class="leioc-admin-form-title">Upload files to Events Database</div>
    
    <form enctype="multipart/form-data" action="#" method="post" class="leioc-event-form-upload" data-url="<?php echo admin_url('admin-ajax.php'); ?>">
        <div class="leioc-row">
            <div class="leioc-col-8">
                <div class="custom-file">
                    <input type="file" class="custom-file-input leioc-event-upload" id="leioc-event-upload" name="uploaded_file">
                    <label class="custom-file-label" for="leioc-event-upload">Choose file . . .</label>
                    <small class="text-muted">Drag and drop files</small>
                 </div>
            </div>
            <div class="leioc-col-1">
                <button type="submit" name="event_file_upload" class="leioc-file-upload-btn" disabled>Upload</button>
            </div>
        </div>
        <input type="hidden" name="upload_path" value="<?php echo $path; ?>">
        <input type="hidden" name="action" value="leioc_file_upload">
        <input type="hidden" name="nonce" value="<?php echo wp_create_nonce( 'leioc_file_upload_nonce' ); ?>">
    </form>     
</div>