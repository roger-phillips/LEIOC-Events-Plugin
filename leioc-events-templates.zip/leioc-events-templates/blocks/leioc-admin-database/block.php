<?php
/**
* 
* @author Roger Phillips
*
* @package leioc-events-plugin
*
*/

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

use \LEIOCevents\Blocks\LeiocEventsAdmin;
use \LEIOCevents\Base\BaseController;

$base = new BaseController;
$admin = new LeiocEventsAdmin;

$edit = $admin->eventsSanitize();
$events = $admin->showEvents();

//Set File Upload File Path
$path = esc_attr( block_value('leioc-filepath') ) ?: '/wordpress/lei_fixtures/uploads/';

$template_path = $base->plugin_path . 'blocks/leioc-admin-database/templates/';

$dbcheck = $admin->ckDB();

if(is_user_logged_in() == false)
{
    echo 'You need to be logged in to use this page';
    return;
}
?>

<div id="leioc-events-admin-wrapper">

<?php if( isset($_POST['event_submit']) ): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong><?php echo esc_attr__( $_POST['event_title'] ); ?></strong> saved to the events database.
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
<?php endif; ?>

    <ul class="leioc-nav-tabs">
        <li class="<?php echo !isset($_POST['edit_event']) ? 'active' : ''; ?>"><a href="#tab-1">Manage Events</a></li>
        <li class="<?php echo isset($_POST['edit_event']) ? 'active' : ''; ?><?php if($dbcheck == false) echo ' leioc-db-error' ?>"><a href="#tab-2" id="form-tab"><?php echo !isset($_POST['edit_event']) ? 'Add New Event' : 'Edit Event'; ?></a></li>
        <li><a href="#tab-3">File Upload</a></li>
    </ul>

    <div class="tab-content">
        <div id="tab-1" class="tab-pane <?php echo !isset($_POST['edit_event']) ? 'active' : ''; ?>">
            <div>
                <h4>Forthcoming Events Listed in the LEIOC Events Database.</h4>
            </div>
            <div style="overflow-x:auto;">
                <table id="leioc-events-admin-table">
                    <thead>
                        <tr>
                            <th>ID</th><th>Date</th><th>Title</th><th>Edit</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php echo $events; ?>
                    </tbody>
                </table>
                <?php if($dbcheck == false): ?>
                    <h5 class="leioc-db-error">Check Database settings on the LEIOC Events Dashboard</h5>
                <?php endif; ?>
            </div>
        </div>

        <div id="tab-2" class="tab-pane <?php echo isset($_POST['edit_event']) ? 'active' : ''; ?>">
            <div class="leioc-admin-form-title"><?php echo isset($_POST['edit_event']) ? 'Edit Event':'Add New Event'; ?></div>

            <input class="leioc-admin-reset" type="button" value="<?php echo isset($_POST['edit_event']) ? 'Add New Event' : 'Clear Form'; ?>" aria-describedby="Reset form">
            <form method="post" action="" id="leioc-events-form">

            <hr>
            <div class="required"><label class="leioc-info" style="color:red;">required</label></div>

            <div class="leioc-row">
                <div class="leioc-col-3">
                    <div class="leioc-form-group">
                        <label for="event_id">ID</label>
                        <input type="text" id="event_id" name="event_id" value="<?php echo $admin->leioc_esc_html__( $edit['event_id'] ); ?>" readonly aria-describedby="Event ID">
                    </div>
                </div>
                <div class="leioc-col-3">
                    <div class="leioc-form-group required">
                        <label for="event_flag">LEI Event</label>
                        <select id="event_flag" name="event_flag" required aria-describedby="LEI event type">
                            <option value="">Choose...</option>
                            <option <?php echo $edit['event_flag'] == 'y' ? 'Selected': ''; ?> value="y">LEI Event</option>
                            <option <?php echo $edit['event_flag'] == 'a' ? 'Selected': ''; ?> value="a">Activity</option>
                            <option <?php echo $edit['event_flag'] == 'm' ? 'Selected': ''; ?> value="m">Meeting</option>
                            <option <?php echo $edit['event_flag'] == 'n' ? 'Selected': ''; ?> value="n">Non LEI Event</option>
                            <option <?php echo $edit['event_flag'] == 'x' ? 'Selected': ''; ?> value="x">Note</option>
                        </select>
                    </div>
                </div>
                <div class="leioc-col-3">
                    <div class="leioc-form-group">
                        <label for="event_level">Event Level</label>
                        <select id="event_level" name="event_level" aria-describedby="Event level">
                            <option value="">Choose...</option>
                            <option <?php echo $edit['event_level'] == 'd' ? 'Selected': ''; ?> value="d">Local (D)</option>
                            <option <?php echo $edit['event_level'] == 'c' ? 'Selected': ''; ?> value="c">Regional (C)</option>
                            <option <?php echo $edit['event_level'] == 'b' ? 'Selected': ''; ?> value="b">National (B)</option>
                            <option <?php echo $edit['event_level'] == 'a' ? 'Selected': ''; ?> value="a">Major (A)</option>
                        </select>
                    </div>
                </div>
                <div class="leioc-col-3">
                    <div class="leioc-form-group required">
                        <label for="event_date">Event Date</label>
                        <input type="date" id="event_date" name="event_date" value="<?php echo $admin->leioc_esc_html__( $edit['event_date'] ); ?>" required aria-describedby="Event date">
                    </div>
                </div>
            </div>

            <div class="leioc-row">
                <div class="col-12">
                    <div class="leioc-form-group required">
                        <label for="event_title">Title</label>
                        <input type="text" maxlength="500" id="event_title" name="event_title" value="<?php echo $admin->leioc_esc_html__( $edit['event_title'] ); ?>" required aria-describedby="Event title">
                    </div>
                </div>
            </div>

            <div class="leioc-row">
                <div class="leioc-col-6">
                    <div class="leioc-form-group">
                        <label for="event_postcode">Post Code</label>
                        <input type="text" maxlength="8" id="event_postcode" name="event_postcode" value="<?php echo $admin->leioc_esc_html__( $edit['event_postcode'] ); ?>" aria-describedby="Postcode">
                    </div>
                </div>
                <div class="leioc-col-6">
                    <div class="leioc-form-group">
                        <label for="event_cp_grid">Car Park Grid Reference</label>
                        <input type="text" maxlength="8" id="event_cp_grid" name="event_cp_grid" value="<?php echo $admin->leioc_esc_html__( $edit['event_cp_grid'] ); ?>" aria-describedby="Car parl grid reference">
                    </div>
                </div>
                <div class="leioc-col-12">
                    <div class="leioc-form-group">
                        <label for="event_cp_desc">Car Park Description</label>
                        <input type="text" maxlength="255" id="event_cp_desc" name="event_cp_desc" value="<?php echo $admin->leioc_esc_html__($edit['event_cp_desc'] ); ?>" aria-describedby="Car park description">
                        <small class="text-muted">no brackets please as they confuse Google Maps</small>
                    </div>
                    <div data-toggle="modal" data-target="#eventsModal" data-title="Event Postcode Search" id="event-search-modal-btn"><i class="fas fa-search-location"></i> Event Postcode Search</div>
                </div>
            </div>

            <hr>
            <div class="leioc-row">
                <div class="leioc-col-12">
                    <div>
                        <label class="leioc-form-label">Event Fees</label>
                    </div>
                    <?php $arr = [
                            ['fees_local','local','Event fees local', 'Level D'],
                            ['fees_district','regional','Event fees regional', 'Level C'],
                            ['fees_activity','activity','Event fees activity', 'Activity'],
                            ['fees_other','other','Set other for event fees', 'Other'],
                            ];
                    echo $admin->get_checkbox_group($arr, 'event_fees', $edit, 'If Event Fees Other, then enter here');?>
                </div>
            </div>

            <hr>
            <div class="leioc-row">
                <div class="leioc-col-12">
                    <div class="leioc-form-group">
                        <label for="event_details_link">Event Details Link</label>
                        <input type="url" maxlength="500" id="event_details_link" name="event_details_link" value="<?php echo $edit['event_details_link'] ?: ''?>" aria-describedby="Event details link">
                        <small class="text-muted">Default path is <?php echo esc_url( site_url($path) );?>**Filename**</small>  
                    </div>
                    <div data-toggle="modal" data-target="#eventsModal" data-title="Events Details Upload" id="event-details-modal-btn"><i class="fas fa-file-upload"></i> Upload Event Details</div>
                </div>
            </div>

            <hr>
            <div class="leioc-row">
                <div class="leioc-col-12">
                    <div>
                        <label class="leioc-form-label">Event Type</label>
                        <div class="leioc-info"><i class="fas fa-info-circle"></i> Select all that apply</div>
                    </div>
                    <?php $type = (isset($edit['event_type']) ? strtolower($edit['event_type']) :'0'); ?>
                    <div class="leioc-ui-toggle">
                        <input type="checkbox" id="classic" name="event_type[]" value="Classic" <?php echo strpos($type, 'classic') !== false ? 'checked': ''?> aria-describedby="Event type - classic">
                        <label for="classic">Classic</label>
                    </div>
                    <div class="leioc-ui-toggle">
                        <input type="checkbox" id="forest" name="event_type[]" value="Forest" <?php echo strpos($type, 'forest') !== false ? 'checked': ''?> aria-describedby="Event type - forest">
                        <label for="forest">Forest</label>
                    </div>
                    <div class="leioc-ui-toggle">
                        <input type="checkbox" id="middle-distance" name="event_type[]" value="Middle Distance" <?php echo strpos($type, 'middle distance') !== false ? 'checked': ''?>>
                        <label for="middle-distance">Middle Distance</label>
                    </div>
                    <div class="leioc-ui-toggle">
                        <input type="checkbox" id="sprint" name="event_type[]" value="Sprint" <?php echo strpos($type, 'sprint') !== false ? 'checked': ''?>>
                        <label for="sprint">Sprint</label>
                    </div>
                    <div class="leioc-ui-toggle">
                        <input type="checkbox" id="urban" name="event_type[]" value="Urban" <?php echo strpos($type, 'urban') !== false ? 'checked': ''?>>
                        <label for="urban">Urban</label>
                    </div>
                    <div class="leioc-ui-toggle">
                        <input type="checkbox" id="score" name="event_type[]" value="Score" <?php echo strpos($type, 'score') !== false ? 'checked': ''?>>
                        <label for="score">Score</label>
                    </div>
                    <div class="leioc-ui-toggle">
                        <input type="checkbox" id="night" name="event_type[]" value="Night" <?php echo strpos($type, 'night') !== false ? 'checked': ''?>>
                        <label for="night">Night</label>
                    </div>
                    <div class="leioc-ui-toggle">
                        <input type="checkbox" id="city-park" name="event_type[]" value="City Park" <?php echo strpos($type, 'city park') !== false ? 'checked': ''?> aria-describedby="Event type - city park">
                        <label for="city-park">City Park</label>
                    </div>
                    <div class="leioc-ui-toggle">
                        <input type="checkbox" id="country-park" name="event_type[]" value="Country Park" <?php echo strpos($type, 'country park') !== false ? 'checked': ''?> aria-describedby="Event type - country park">
                        <label for="country-park">Country Park</label>
                    </div>
                    <div class="leioc-ui-toggle other">
                        <input type="checkbox" id="type-other" name="event_type[]" value="Other" <?php echo strpos($type, 'other') !== false ? 'checked': ''?> aria-describedby="Event type - other select">
                        <label for="type-other">Other</label>
                    </div>
                    <div class="leioc-form-group <?php echo strpos($type, 'other') !== false ? 'other-show': 'other-hide'?>">
                        <label for="event_type_other">If Event Type Other, then enter here</label>
                        <input type="text" maxlength="255" id="event_type_other" name="event_type_other" value="<?php echo $edit['event_type_other'] ?: ''?>" aria-describedby="Event type - other">
                    </div>
                </div>
            </div>

            <hr>
            <div class="leioc-row">
                <div class="leioc-col-6">
                    <div class="leioc-form-group">
                        <label for="event_org">Organiser</label>
                        <input type="text" maxlength="25" id="event_org" name="event_org"  value="<?php echo $admin->leioc_esc_html__( $edit['event_org'] );?>" aria-describedby="Event organiser">
                    </div>
                </div>
                <div class="leioc-col-6">
                    <div class="leioc-form-group">
                        <label for="event_org">Organiser's Phone Number</label>
                        <input type="tel" maxlength="20" id="event_org_phone" name="event_org_phone" value="<?php echo $admin->leioc_esc_html__( $edit['event_org_phone'] );?>" aria-describedby="Organiser's phone number">
                    </div>
                </div>
                <div class="leioc-col-12">
                    <div class="leioc-form-group">
                        <label for="event_org_email">Organiser's Email Address</label>
                        <input type="email" maxlength="75" id="event_org_email" name="event_org_email" value="<?php echo $admin->leioc_esc_html__( $edit['event_org_email'] ); ?>" aria-describedby="Oraniser's Email Address">
                    </div>
                </div>
                <div class="leioc-col-6">
                    <div class="leioc-form-group">
                        <label for="event_planner">Planner</label>
                        <input type="text" maxlength="25" id="event_planner" name="event_planner" value="<?php echo $admin->leioc_esc_html__( $edit['event_planner'] ); ?>" aria-describedby="Planner's name">
                    </div>
                </div>
                <div class="leioc-col-6">
                    <div class="leioc-form-group">
                        <label for="event_controller">Controller</label>
                        <input type="text" maxlength="25" id="event_controller" name="event_controller" value="<?php echo $admin->leioc_esc_html__( $edit['event_controller'] ); ?>" aria-describedby="Controller name">
                    </div>
                </div>
            </div>

            <hr>
            <div class="leioc-row">
                <div class="leioc-col-12">
                    <div>
                        <label class="leioc-form-label">Registration Times</label>
                    </div>
                    <?php $arr = [
                            ['reg_10','10','Registration time - 10:00 am - 12 noon', '10:00 am - 12 noon'],
                            ['reg_11','11','Registration time - 11:00 am - 12 noon', '11:00 am - 12 noon'],
                            ['reg_615','6.15','Registration time - 6:15 pm - 7:00 pm', '6:15 am - 7:00 pm'],
                            ['reg_na','n/a','not applicable for registration time', 'N/A'],
                            ['reg_other','other','Set other for registration time', 'Other'],
                            ];
                    echo $admin->get_checkbox_group($arr, 'event_reg', $edit, 'If Registration Times Other, then enter here');?>
                </div>
            </div>

            <hr>
            <div class="leioc-row">
                <div class="leioc-col-12">
                    <div>
                        <label class="leioc-form-label">Start Times</label>
                    </div>
                    <?php $arr = [
                            ['starts_11Only','11Only','Start time - 11:00 am', '11:00 am'],
                            ['starts_10','10','Start time - 10:30 am - 12:30', '10:30 am - 12:30 pm'],
                            ['starts_11','11','Start time - 11:00 am - 12:00 noon', '11:00 am - 12:00 noon'],
                            ['starts_630','6.30','Start time - 6:30 pm - 7:15 pm', '6:30 pm - 7:15 pm'],
                            ['starts_na','n/a','not applicable for start time', 'N/A'],
                            ['starts_other','other','Set other for start time', 'Other'],
                            ];
                    echo $admin->get_checkbox_group($arr, 'event_starts', $edit, 'If Starts Times Other, then enter here');?>
                </div>
            </div>

            <hr>
            <div class="leioc-row">
                <div class="leioc-col-12">
                    <div>
                        <label class="leioc-form-label">Courses Close Time</label>
                    </div>
                    <?php $arr = [
                            ['close_12','12','Course close time - 12 noon', '12 noon'],
                            ['close_130','1.30','Course close time - 1.30 pm', '1:30 pm'],
                            ['close_200','2.00','Course close time - 2.00 pm', '2:00 pm'],
                            ['close_230','2.30','Course close time - 2.30 pm', '2:30 pm'],
                            ['close_8150','8.15','Course close time - 8.15 pm', '8:15 pm'],
                            ['close_na','n/a','not applicable for course close time', 'N/A'],
                            ['close_other','other','Set other course close time', 'Other'],
                            ];
                    echo $admin->get_checkbox_group($arr, 'event_course_close', $edit, 'If Course Close Times Other, then enter here');?>
                </div>
            </div>

            <hr>
            <div class="leioc-row">
                <div class="leioc-col-12">
                    <div>
                        <label class="leioc-form-label">Time</label>
                    </div>
                    <?php $arr = [
                            ['time_630','6.30','set time - 6:30 pm - 8:00 pm', '6:30 pm - 8:00pm'],
                            ['time_730','7.30','set time - 7:30 pm - 9:00 pm', '7:30 pm - 9:00pm'],
                            ['time_731','7.31','set time - 7:30 pm - 9:30 pm', '7:30 pm - 9:30pm'],
                            ['time_na','n/a','not applicable to set time', 'N/A'],
                            ['time_other','other','Set other time', 'Other'],
                            ];
                    echo $admin->get_checkbox_group($arr, 'event_time', $edit, 'If Time Other, then enter here');?>
                </div>
            </div>

            <hr>
            <div class="leioc-row">
                <div class="leioc-col-12">
                    <div class="leioc-form-group">
                        <label for="event_notes">Event Notes</label>
                        <textarea id="event_notes" name="event_notes" rows="6" aria-describedby="Event notes"><?php echo $base->br2nl( $base->leioc_esc_html($edit['event_notes'] ) ); ?></textarea>
                    </div>
                </div>
            </div>

            <hr>
            <div class="leioc-row">
                <div class="leioc-col-12">
                    <div>
                        <label class="leioc-form-label" class="leioc-form-label">Courses Available</label>
                        <div class="leioc-info"><i class="fas fa-info-circle"></i> Select all that apply</div>
                    </div>

                    <hr>
                    <div class="leioc-ui-toggle">
                        <input type="checkbox" id="course_all_colours" class="set-default-courses" aria-describedby="Select all standard colour courses">
                        <label for="course_all_colours"><span>Select All Standard </span>Colour Courses</label>
                    </div>
                    <div class="leioc-ui-toggle">
                        <input type="checkbox" id="course_all_d" class="set-default-courses" aria-describedby="Select short, medium and long courses">
                        <label for="course_all_d"><span>Select Short, Medium and </span>Long Courses</label>
                    </div>

                    <hr>
                    <?php echo $admin->get_course_options(['White', 'Yellow', 'Orange', 'Light Green', 'Short Green','Green', 'Short Blue', 'Blue', 'Short Brown', 'Brown', 'Black'], $edit); ?>

                    <hr>
                    <?php echo $admin->get_course_options(['short','medium', 'long'], $edit); ?>

                    <div class="leioc-events-form-toggler" data-leioctarget="#more-course-options">More Course Options <i class="fas fa-angle-down"></i></i></div>
                    <div class="leioc-results-widget-collapse" id="more-course-options">

                        <hr>
                        <?php echo $admin->get_course_options(['45 Minute Score', '60 Minute Score'], $edit); ?> 

                        <hr>
                        <?php echo $admin->get_course_options(['Introductory Level (short)', 'Intermediate Level (medium)', 'Technical Level (long)'], $edit); ?>

                        <hr>
                        <?php echo $admin->get_course_options(['Usual Age Classes', 'Usual Urban Age Classes'], $edit); ?>

                        <hr>
                        <?php echo $admin->get_course_options(['String', 'See Notes'], $edit); ?>

                    </div>

                </div>
            </div>

            <hr>
            <div class="leioc-row">
                <div class="leioc-col-6">
                    <div>
                        <label class="leioc-form-label">Si Available</label>
                    </div>
                    <?php $arr = [
                            ['si_yes','y','Si available', 'Yes'],
                            ['si_no','n','Si not available', 'No'],
                            ['si_tbc','tbc','Si atvailable to be confirmed', 'TBC'],
                            ['si_n/a','na','Not applicable Si', 'N/A'],
                            ];
                    echo $admin->get_checkbox_group($arr, 'event_si', $edit);?>
                </div>
                <div class="leioc-col-6">
                    <div>
                        <label class="leioc-form-label">SIAC</label>
                    </div>
                    <div class="leioc-ui-toggle">
                        <input type="checkbox" id="event_siac" name="event_siac[]" value="yes" <?php echo strpos(strtolower($edit['event_siac']), 'yes') !== false ? 'checked': ''?> aria-describedby="SIAC avaialble - yes">
                        <label for="event_siac">Yes</label>
                    </div>
                </div>
            </div>

            <hr>
            <div class="leioc-row">
                <div class="leioc-col-6">
                    <div>
                        <label class="leioc-form-label">Suitable for Beginners</label>
                    </div>
                    <?php $arr = [
                            ['beginner_yes','y','Suitable for event beginners - yes', 'Yes'],
                            ['beginner_no','n','Not suitable for event beginners', 'No'],
                            ['beginner_n/a','x','Not applicable for event beginners', 'N/A'],
                            ];
                    echo $admin->get_checkbox_group($arr, 'event_beginners', $edit);?>
                </div>
                <div class="leioc-col-6">
                    <div>
                        <label class="leioc-form-label">Suitable for Large Groups</label>
                    </div>
                    <?php $arr = [
                            ['group_yes','y','Suitable for large groups', 'Yes'],
                            ['groups_no','n','Not suitable for large groups', 'No'],
                            ['groups_n/a','x','Not applicable for large grups', 'N/A'],
                            ];
                    echo $admin->get_checkbox_group($arr, 'event_groups', $edit);?>
                </div>
            </div>

            <hr>
            <div class="leioc-row">
                <div class="leioc-col-12">
                    <div>
                        <label class="leioc-form-label">Dogs</label>
                    </div>
                    <?php $arr = [
                            ['dogs_lead','lead','Dogs on Lead', 'On Leads'],
                            ['dogs_no','no','Dogs not allowed', 'Not Allowed'],
                            ['dogs_yes','yes','No Restrictions on dogs', 'No Restrictions'],
                            ['dogs_cp','cp','Dogs in car park only', 'Car Park Only'],
                            ['dogs_tbc','tbc','Dogs to be confirmed', 'TBC'],
                            ];
                    echo $admin->get_checkbox_group($arr, 'event_dogs', $edit);?>
                </div>
            </div>

            <hr>
            <div class="leioc-row">
                <div class="leioc-col-6">
                    <div class="leioc-form-group">
                        <label for="event_social">Social Venue</label>
                        <textarea id="event_social" name="event_social" rows="3" aria-describedby="Social venue"><?php echo $base->br2nl( $base->leioc_esc_html( $edit['event_social'] ) );?></textarea>
                    </div>
                </div>

                <div class="leioc-col-6">
                    <div class="leioc-form-group">
                        <label for="event_toilets">Toilets</label>
                        <input type="text" maxlength="100" id="event_toilets" name="event_toilets" value="<?php echo $admin->leioc_esc_html__( $edit['event_toilets'] );?>" aria-describedby="Toilet information">
                    </div>
                </div>
            </div>

            <div class="leioc-form-group">
                <input type="submit" id="event_submit" name="event_submit" class="btn-primary" aria-describedby="Submit">
            </div>
            </form>
        </div>

        <div id="tab-3" class="tab-pane">
            <?php include $template_path . 'file-upload.php'; ?>
        </div>

    </div>

    <!-- Modal -->
    <div class="modal fade" id="eventsModal" tabindex="-1" role="dialog" aria-labelledby="eventsModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Events Details Upload</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">

                    <div id="leioc-modal-upload">
                        <?php include $template_path . 'file-upload.php'; ?>
                    </div>

                    <div id="leioc-modal-search">
                        <div class="col-12">
                        <form action="#" method="post" class="leioc-event-form-upload" id="leioc-event-form-search-modal" data-url="<?php echo admin_url('admin-ajax.php'); ?>">
                            <div class="row">
                                <div class="col-12">
                                <div class="form-group">
                                    <label for="leioc_cp_search">Search by event title</label>
                                    <input type="text" id="leioc_cp_search" name="leioc_cp_search" class="form-control" placeholder="Search Events">
                                    <small class="leioc-searching">Searching database . . .</small>
                                </div>
                                </div>
                            </div>
                            <input type="hidden" name="action" value="leioc_event_cp_search"> 
                            <input type="hidden" name="nonce" value="<?php echo wp_create_nonce( 'leioc_cp_search_nonce' ); ?>"> 
                        </form>

                        <div class="leioc-event-form-result"></div>

                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>

</div>