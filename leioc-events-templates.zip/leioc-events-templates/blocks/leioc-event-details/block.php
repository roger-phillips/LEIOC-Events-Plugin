<?php
/**
* 
* @author Roger Phillips
*
* @package leioc-events-plugin
*
*/

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

use \LEIOCevents\Base\BaseController;
$base = new BaseController;

//Define Block Values
/*Fields from Block Lab Plugin
 *
 * - redirect-url
 * 
 * */
$event_redirect_url =  esc_url( block_value('redirect-url') ) ;


include $base->plugin_path.'blocks/leioc-event-details/templates/shortcode-shared.php';
