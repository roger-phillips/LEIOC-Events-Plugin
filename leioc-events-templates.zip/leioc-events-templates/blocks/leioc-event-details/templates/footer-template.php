<?php

 /**
  *
  *
  *@package leioc-events-plugin 
  */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

if( shortcode_exists( 'leioc-entry-table' ) ){
  echo '<div class="leioc-no-print">';
  echo do_shortcode('[leioc-entry-table id="' . $item_id . '"]');
  echo '</div>';
}
?>

<!-- Events Footer and Basic O Form shortcode-->
<div class="leioc-row" id="leioc-event-details-footer">
    <div class="leioc-col">
		<div class="leioc-footer">Event Id: <?php echo $item_id; ?></div>
	</div>
</div>