<?php

 /**
  *
  *
  *@package leioc-events-plugin 
  */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

?>
<!-- Activities Template -->
<div class="leioc-row" id="activities-details-times">
	<?php if(!empty($event_act_text) && !empty($event_beginners)): ?>
        <div class="leioc-col-8">
			<div class="event-times bg-leioc-activities-details">
				<div class="icon-space"><i class="fas fa-info-circle"></i></div> <?php echo $event_beginners;?>
				<div class="activities-text"><?php echo $event_act_text; ?></div>
			</div>
		</div>
	<?php endif; ?>

	<?php if(!empty($event_type) || !empty($event_reg) || !empty($event_starts) || !empty($event_course_close) || !empty($event_time) ) $display = true; ?>

	<div class="<?php echo isset($display) ? 'leioc-col-4' : ''; //Removes class if all items are empty?>">
		<div class="<?php echo isset($display) ? 'event-times bg-leioc-activities-details' : ''; //Removes class if all items are empty?>">	
			<ul class="leioc-unstyled">
				<?php if(!empty($event_type) ): ?>
					<li><span class="leioc-bold">Event Type - </span><?php echo $event_type; ?></li><br>
				<?php endif; ?>
				<?php if(!empty($event_reg) ): ?>
					<li><span class="leioc-bold">Registration Times</span></li>
					<li class="li-event"><?php echo $event_reg; ?></li>
				<?php endif; ?>
				<?php if(!empty($event_starts) ): ?>
					<li><span class="leioc-bold">Start Times</span></li>
					<li class="li-event"><?php echo $event_starts; ?></li>
				<?php endif; ?>
				<?php if(!empty($event_course_close) ): ?>
					<li><span class="leioc-bold">Course Closing Time</span></li>
					<li class="li-event"><?php echo $event_course_close; ?></li>
				<?php endif; ?>
				<?php if(!empty($event_time) ): ?>
					<li><span class="leioc-bold">Event Time</span></li>
					<li class="li-event"><?php echo $event_time; ?></li>
				<?php endif; ?>
			</ul>
		</div>
	</div>
</div>

<div class="leioc-row bg-leioc-activities-details" id="activities-details-fees">
	<div class="leioc-col-8">
		<?php if(!empty($event_fees) ): ?>
			<span class="leioc-bold">Fees</span><br><?php echo $event_fees; ?>
		<?php endif; ?>
	</div>
	<div class="leioc-col-4">
		<?php if(!empty($event_si) ): ?> 
			<span class="leioc-bold">Electronic Punching</span><br><?php echo $event_si; ?>
		<?php endif; ?>
	</div>
</div>

<div class="leioc-row" id="activities-details-notes">
	<?php if(!empty($event_notes) ): ?>
		<div class="leioc-col"><?php echo $event_notes; ?></div>
	<?php endif; ?>
	<?php if(!empty($event_details_link) ): ?>
		<div class="leioc-col event-link">
			<span class="leioc-bold">Event Details</span> <a href="<?php echo $event_details_link; ?>"><?php echo $event_details_link; ?></a>
		</div>
	<?php endif; ?>
</div>

<div class="leioc-row" id="activities-details-contact">
	<div class="leioc-col-4 bg-leioc-activities-details">
		<?php if(!empty($event_org) ): ?>
			<span class="leioc-bold">Organiser -</span> <?php echo $event_org;?>
		<?php endif; ?>
	</div>
	<div class="leioc-col-4 bg-leioc-activities-details">
		<ul class="leioc-unstyled">
			<?php if(!empty($event_org_email) ):?>
				<li>
					<i class="fas fa-envelope"></i><a href="mailto:<?php echo $event_org_email; ?>"><?php echo $event_org_email; ?></a>
					<?php if( !empty($event_org_email_note) ): ?>
					<span class="leioc-org-notes"><?php echo $event_org_email_note; ?></span>
					<?php endif; ?>
				</li>
			<?php endif; ?>
			<?php if(!empty($event_org_phone) ): ?>
				<li>
					<i class="fas fa-phone"></i><a href="tel:<?php echo $event_org_phone; ?>" rel="nofollow"><?php echo $event_org_phone; ?></a>
					<?php if( !empty($event_org_phone_note) ): ?>
					<span class="leioc-org-notes"><?php echo $event_org_phone_note; ?></span>
					<?php endif; ?>
				</li>
			<?php endif; ?>
		</ul>
	</div>
	<div class="leioc-col-4 bg-leioc-activities-details">
		Page Updated <?php echo $event_updated; ?>
	</div>
</div>

<div class="leioc-row" id="activities-details-other">
	<div class="leioc-col-4">
		<ul class="leioc-unstyled">
			<?php if(!empty($event_priv_policy)): ?>
				<li>
					<span class="leioc-bold">Privacy Policy <a href="<?php echo $event_priv_policy; ?>">Click Here</a></span>
				</li>
			<?php endif; ?>
		</ul>
	</div>
	<div class="leioc-col-8">
		<ul class="leioc-unstyled">
			<?php if(!empty($event_toilets) ): ?>
				<li>
					<span class="leioc-bold">Toilets</span> <?php echo $event_toilets; ?>
				</li>
			<?php endif; ?>
			<?php if(!empty($event_groups) ): ?>
				<li>
					<span class="leioc-bold">Large Groups</span> <?php echo $event_groups; ?>
				</li>
			<?php endif; ?>
			<?php if(!empty($event_dogs) ): ?>
				<li>
					<span class="leioc-bold">Dogs</span> <?php echo $event_dogs; ?>
				</li>
			<?php endif; ?>
			<?php if(!empty($event_social) ): ?>
				<li>
					<span class="leioc-bold">Social Venue</span> <?php echo $event_social; ?>
				</li>
			<?php endif; ?>
		</ul>
	</div>
</div>