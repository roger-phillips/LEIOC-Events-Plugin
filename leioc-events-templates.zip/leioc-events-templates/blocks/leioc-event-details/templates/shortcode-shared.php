<?php
/**
* 
* @author Roger Phillips
*
* @package leioc-events-plugin
*
*/

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

use \LEIOCevents\Blocks\EventData;
use \LEIOCevents\Base\BaseController;

$base = new BaseController;
$template_path = $base->plugin_path . 'blocks/leioc-event-details/templates/';

//Sanitize $_GET['item']
$item_id = isset($_GET['item']) ? intval( esc_attr($_GET['item']) ) : '';
$item_id = $item_id != 0 ? $item_id : null;

// $event_redirect_url set via block or shortcode

if (!isset($item_id)) {
    echo '<br>';
    esc_html_e('No event selected - you will be redirected to the LEI Fixtures page shortly');
	printf('<META HTTP-EQUIV="Refresh" Content="0; URL=%s">', esc_url( $event_redirect_url ?: get_home_url() ) );
} else {
    $admin = new EventData;
    $result = $admin->eventbyIDdata($item_id);

    $option = get_option( 'leioc_events_settings' );
    $event_priv_policy = isset($option['privacy_policy_url']) ? esc_url( $option['privacy_policy_url']): '';
    $event_act_text =  isset($option['default_act_text']) ? $base->leioc_esc_html( $option['default_act_text']): '';
    $event_beginners_link =  isset($option['first-event-url']) ? esc_url( $option['first-event-url']): '';

    //Event Type
    $event_flag = esc_attr__($result['event_flag']);

    //leioc-event-details-title
    $event_title = esc_html__($result['event_title']);
    $day = esc_html__($result['day']);
 
    //leioc-event-details-map
    $event_postcode = esc_html__($result['event_postcode']);
    $event_cp_grid = esc_html__($result['event_cp_grid']);
    $event_cp_desc = esc_html__($result['event_cp_desc']);

    //event-details-beginner
    $event_beginners = esc_html__($result['event_beginners']);

    //event-details-times
    $event_type = esc_html__($result['event_type']);
    $event_reg = esc_html__($result['event_reg']);
    $event_starts = esc_html__($result['event_starts']);
    $event_course_close = esc_html__($result['event_course_close']);
    $event_time = esc_html__($result['event_time']);
    $event_level = esc_html__($result['event_level']);
    $event_courses = $base->leioc_esc_html($result['event_courses']);

    //event-details-fees
    $event_fees = $base->leioc_esc_html($result['event_fees']);
    $event_si = esc_html__($result['event_si']);

    //event-details-notes
    $event_notes =  $base->leioc_esc_html( $result['event_notes'] );
    $event_details_link = esc_url($result['event_details_link']);

    //event-details-contact
    $event_org = esc_html__($result['event_org']);
    $event_org_email = esc_html__($result['event_org_email']);
    $event_org_email_note = esc_html__($result['event_org_email_note']);
    $event_org_phone = esc_html__($result['event_org_phone']);
    $event_org_phone_note = esc_html__($result['event_org_phone_note']);
    
    $event_updated = esc_html__($result['event_updated']);

    //event-details-other
    $event_planner = esc_html__($result['event_planner']);
    $event_controller = esc_html__($result['event_controller']);
    $event_toilets = esc_html__($result['event_toilets']);
    $event_groups = esc_html__($result['event_groups']);
    $event_dogs = esc_html__($result['event_dogs']);
    $event_social = $base->leioc_esc_html( $result['event_social'] );
}
?>

<div class="leioc-events-wrapper leioc-print">

    <?php if(!empty($result) ) : ?>

        <?php include $template_path . 'header-template.php'; ?>

        <?php if($event_flag == 'y') :?>

            <?php include $template_path . 'event-template.php' ;?>

        <?php elseif($event_flag == 'a') :?>

            <?php include $template_path . 'activity-template.php' ;?>

        <?php elseif($event_flag == 'm') :?>

            <?php include $template_path . 'meeting-template.php' ;?>

        <?php else : ?>

            <?php include $template_path . 'default-template.php' ;?>

        <?php endif; ?>

        <?php include $template_path . 'footer-template.php' ;?>

    <?php endif; ?>

</div>