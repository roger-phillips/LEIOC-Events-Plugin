<?php

 /**
  *
  *
  *@package leioc-events-plugin 
  */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

?>
<!-- meeting Template -->
<div class="leioc-row" id="meeting-details-times">
	<?php if(!empty($event_time) ): ?>
		<div class="leioc-col"><span class="leioc-bold">Meeting Time </span><?php echo $event_time; ?></div>
	<?php endif; ?>
</div>

<div class="leioc-row" id="meeting-details-notes">
	<?php if(!empty($event_notes) ): ?>
		<div class="leioc-col"><?php echo $event_notes; ?></div>
	<?php endif;?>
	<?php if(!empty($event_details_link) ): ?>
		<div class="leioc-col event-link"><span class="leioc-bold">Event Details </span><a href="<?php echo $event_details_link; ?>"><?php echo $event_details_link;?></a></div>
	<?php endif;?>
</div>

<div class="leioc-row" id="meeting-details-contact">
	<div class="leioc-col-4 bg-leioc-meeting-details">
		<?php if(!empty($event_org) ): ?>
			<span class="leioc-bold">Organiser - </span><?php echo $event_org;?>
		<?php endif;?>
	</div>
	<div class="leioc-col-4 bg-leioc-meeting-details">
		<ul class="leioc-unstyled">
			<?php if(!empty($event_org_email) ): ?>
				<li>
					<i class="fas fa-envelope"></i><a href="mailto:<?php echo $event_org_email; ?>"><?php echo $event_org_email;?></a>
					<?php if( !empty($event_org_email_note) ): ?>
					<span class="leioc-org-notes"><?php echo $event_org_email_note; ?></span>
					<?php endif; ?>
				</li>
			<?php endif; ?>
			<?php if(!empty($event_org_phone) ): ?>
				<li>
					<i class="fas fa-phone"></i><a href="tel:<?php echo $event_org_phone; ?>" rel="nofollow"><?php echo $event_org_phone;?></a>
					<?php if( !empty($event_org_phone_note) ): ?>
					<span class="leioc-org-notes"><?php echo $event_org_phone_note; ?></span>
					<?php endif; ?>
				</li>
			<?php endif;?>
		</ul>
	</div>
	<div class="leioc-col-4 bg-leioc-meeting-details">
		Page Updated <?php echo $event_updated; ?>
	</div>
</div>

<div class="leioc-row" id="meeting-details-other">
	<div class="leioc-col-4">
		<ul class="leioc-unstyled">
			<?php if(!empty($event_priv_policy)): ?>
				<li>
					<span class="leioc-bold">Privacy Policy <a href="<?php echo $event_priv_policy;?>">Click Here</a></span>
				</li>
			<?php endif; ?>
		</ul>
	</div>
	<div class="leioc-col-8">
		<ul class="leioc-unstyled">
			<?php if(!empty($event_toilets) ): ?>
				<li>
					<span class="leioc-bold">Toilets </span><?php echo $event_toilets;?>
				</li>
			<?php endif; ?>
			<?php if(!empty($event_groups) ): ?>
				<li>
					<span class="leioc-bold">Large Groups </span><?php echo $event_groups;?>
				</li>
			<?php endif; ?>
			<?php if(!empty($event_dogs) ): ?>
				<li>
					<span class="leioc-bold">Dogs </span><?php echo $event_dogs; ?>
				</li>
			<?php endif; ?>
			<?php if(!empty($event_social) ): ?>
				<li>
					<span class="leioc-bold">Social Venue </span><?php echo $event_social;?>
				</li>
			<?php endif; ?>
		</ul>
	</div>
</div>