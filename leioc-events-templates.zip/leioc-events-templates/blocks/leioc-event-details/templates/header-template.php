<?php

 /**
  *
  *
  *@package leioc-events-plugin 
  */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

use \LEIOCevents\Api\MapsApi;

$mapApi = new MapsApi;

$event_streetmap =  $mapApi->streetmapLink($event_cp_grid);
$event_googlelink = $mapApi->googleMapLink($event_cp_grid, $event_cp_desc);
$mapData = ($mapApi->getMapData($event_cp_grid) ? $mapApi->getMapData($event_cp_grid) : '{"blank":"blank"}');
if(!empty($event_cp_grid) ) $mapApi->setGoogleScript() ;

?>
<!-- Events Header Title & Map-->
<div class="leioc-row bg-leioc-event-details" id="leioc-event-details-title">
	<div class="leioc-col">
		<strong>
			<?php echo $day; ?>
		</strong>
	</div>
	<div class="leioc-col event-title">
		<div>
			<strong>
				<?php echo $event_title; ?>
			</strong>
		</div>
		<div class="lei-print-btn">
			<a href="#" aria-label="Print Event"><i class="fas fa-print fa-sm"></i></a>
		</div>
	</div>
</div>

<div class="leioc-row" id="leioc-event-details-map">
	<div class="leioc-col leioc-event-map-wrapper " id="leioc-event-map-wrapper" <?php if(!empty($event_cp_grid) ) echo 'data-map='.$mapData ?> >
		<div class="leioc-map <?php echo (empty($mapApi->chkGoogleApi()) ? 'no-map-api':'');?>" id="leioc-event-map">
			<?php if(!empty($event_cp_grid) && strtolower($event_cp_grid) == 'tbc') echo 'TBC'; ?>
		</div>
		<div class="leioc-map-text" id="leioc-event-map-text"></div>
	</div> 
	<div class="leioc-col-4 bg-leioc-event-details">
		<?php if( !empty($event_postcode) ): ?>
			<i class="fas fa-map-marker-alt"></i><span class="leioc-bold">Postcode </span><?php echo strtoupper($event_postcode); ?>
		<?php endif; ?>
	</div>
	<div class="leioc-col-4 bg-leioc-event-details">
		<?php if(!empty($event_cp_desc) && $event_cp_desc != '-') echo $event_cp_desc; ?>
		<?php if(!empty($event_streetmap) ): ?>
			view in <a href="<?php echo $event_streetmap?>"><span class="leioc-bold">Streetmap</span></a> or <a href="<?php echo $event_googlelink;?> "><span class="leioc-bold">Google Maps</span></a>
		<?php endif;?>
	</div>
	<div class="leioc-col-4 bg-leioc-event-details">
		<?php if(!empty($event_cp_grid) ): ?>
			<span class="leioc-bold">Grid Refrence </span><?php echo strtoupper($event_cp_grid); ?>
		<?php endif;?>
	</div>
</div>


