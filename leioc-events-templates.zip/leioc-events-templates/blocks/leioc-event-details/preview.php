<?php
/**
* 
* @author Roger Phillips
*
* @package leioc-events-plugin
*
*/

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

use \LEIOCevents\Base\BaseController;
$base = new BaseController;

$option = get_option( 'leioc_events_settings' );
$event_priv_policy = isset($option['privacy_policy_url']) ? esc_url( $option['privacy_policy_url']): '';
$event_act_text =  isset($option['default_act_text']) ? $base->leioc_esc_html( $option['default_act_text']): '';
$event_beginners_link =  isset($option['first-event-url']) ? esc_url( $option['first-event-url']): '';

?>
<div class="leioc-row bg-leioc-event-details" id="leioc-event-details-title">
	<div class="leioc-col" style="padding-top: 0.5rem; padding-bottom:0.5rem;">
		<strong>
			Monday 1st January 1970
		</strong>
	</div>
	<div class="leioc-col" style="padding:0.5rem; margin-bottom: 0.25rem; display: flex;">
		<div style="flex: 1 auto">
			<strong>
				EMOA Martinshaw Woods
			</strong>
		</div>
		<div class="lei-print-btn text-right">
			<a href="#"><i class="fas fa-print fa-sm"></i></a>
		</div>
	</div>
</div>

<div class="leioc-row" id="leioc-event-details-map">
	<div class="leioc-col leioc-map-wrapper" style="margin: 0.5rem 0; padding: 0;">
		<div class="leioc-map" id="leioc-event-map"></div>
		<div class="leioc-map-text" id="leioc-event-map-text"></div>
	</div>
	<div class="leioc-col-4 bg-leioc-event-details" style="padding: 0.25rem 0.25rem 0.25rem 0.5rem;">
		<i class="fas fa-map-marker-alt"></i><span class="leioc-bold">Postcode </span>LE6 0FP
	</div>
	<div class="leioc-col-4 bg-leioc-event-details" style="padding: 0.25rem 0.25rem 0.25rem 0.5rem;">
		Brookvale Learning Campus
		 view in <a href="#"><span class="leioc-bold">Streetmap</span></a> or <a href="#"><span class="leioc-bold">Google Maps</span></a>
	</div>
	<div class="leioc-col-4 bg-leioc-event-details" style="padding: 0.25rem 0.25rem 0.25rem 0.5rem;">
		<span class="leioc-bold">Grid Refrence </span>SK123456
	</div>
</div>

<!-- Event Template -->
<div class="leioc-row" id="event-details-beginner">
	<div class="leioc-col-4" style="padding: 0.5rem;">
		<div class="float-left icon-space"><i class="fas fa-info-circle"></i></div>Beginners welcome, help and advice available.
	</div>
	<div class="leioc-col-8" style="padding: 0.5rem;">
        <?php if(!empty($event_beginners_link) ): ?>
        	For more information about what to expect at an orienteering event, please follow the link to the webage - <span class="leioc-bold"><a href="<?php echo $event_beginners_link;?>">Your First Event</a></span>
		<?php endif;?>
	</div>
</div>

<div class="leioc-row" id="event-details-times">
	<div class="leioc-col-4" style="padding: 0.5rem;">
		<div class="event-times bg-leioc-event-details" style="margin: 0 auto;">
			<ul class="leioc-unstyled" style="list-style:none;">
				<li>
					<span class="leioc-bold">Event Type - </span>Forest
				</li>
				<li><span class="leioc-bold">Registration Times</span></li>
				<li style="margin-left: 1rem;">10:00 am - 12:00 pm</li>
				<li><span class="leioc-bold">Start Times</span></li>
				<li style="margin-left: 1rem;">10:30 am - 12:30 pm</li>
				<li><span class="leioc-bold">Course Closing Time</span></li>
				<li style="margin-left: 1rem;">2:00 pm</li>
			</ul>
		</div>
	</div>
		<div class="leioc-col-8" style="padding: 0.5rem; margin: 0 auto;">
			<div class="event-times bg-leioc-event-details">
			<span class="leioc-bold">Event Level - </span>Regional<br><br>
			<?php if(!empty($event_courses) ) echo $event_courses; //Displays Course Table ?>
		</div>
	</div>
</div>

<div class="leioc-row bg-leioc-event-details" id="event-details-fees">
	<div class="leioc-col-8"  style="padding: 0.25rem 0.25rem 0.25rem 0.5rem;">
		<?php if(!empty($event_fees) ):?>
			<span class="leioc-bold">Fees</span><br><?php echo $event_fees;?>
		<?php endif;?>
	</div>
	<div class="leioc-col-4" style="padding: 0.25rem 0.25rem 0.25rem 0.5rem;">
		<?php if(!empty($event_si) ) echo $event_si ?>
	</div>
</div>

<div class="leioc-row" id="event-details-notes">
	<?php if(!empty($event_notes) ): ?>
		<div class="leioc-col" style="padding: 0.5rem;"><?php echo $event_notes;?></div>
	<?php endif;?>
	<?php if(!empty($event_details_link) ): ?>
		<div class="leioc-col event-link" style="padding: 0.5rem;">
			<span class="leioc-bold">Event Details</span> <a href="<?php echo $event_details_link; ?>"><?php echo $event_details_link; ?></a>
		</div>
	<?php endif;?>
</div>

<div class="leioc-row" id="event-details-contact">
	<div class="leioc-col-4 bg-leioc-event-details" style="padding: 0.25rem 0.25rem 0.25rem 0.5rem;">
		<span class="leioc-bold">Organiser -</span>
	</div>
	<div class="leioc-col-4 bg-leioc-event-details" style="padding: 0.25rem 0.25rem 0.25rem 0.5rem;">
		<ul class="list-unstyled" style="list-style:none;">
			<li>
				<i class="fas fa-envelope"></i><a href="mailto:#">info@leioc.org.uk</a>
			</li>
			<li>
				<i class="fas fa-phone"></i><a href="tel:#">123 456 789</a>
			</li>
		</ul>
	</div>
	<div class="leioc-col-4 bg-leioc-event-details" style="padding: 0.25rem 0.5rem 0.25rem 0.5rem;">
		Page Updated
	</div>
</div>

<div class="leioc-row" id="event-details-other" style="padding-top: 0.25rem;">
	<div class="leioc-col-4" style="padding: 0.5rem;">
		<ul class="leioc-unstyled" style="list-style:none;">
			<li>
				<span class="leioc-bold">Planner -</span>
			</li>
			<li>
				<span class="leioc-bold">Controller -</span>
			</li>
		<br>
			<?php if(!empty($event_priv_policy)): ?>
				<li>
					<span class="leioc-bold">Privacy Policy <a href="<?php echo $event_priv_policy; ?>">Click Here</a></span>
				</li>
			<?php endif; ?>
		</ul>
	</div>
	<div class="leioc-col-8" style="padding: 0.5rem;">
		<ul class="leioc-unstyled" style="list-style:none;">
			<li>
				<span class="leioc-bold">Toilets</span>
			</li>
			<li>
				<span class="leioc-bold">Large Groups</span>
			</li>
			<li>
				<span class="leioc-bold">Dogs</span>
			</li>
			<li>
				<span class="leioc-bold">Social Venue</span>
			</li>
		</ul>
	</div>
</div>