<?php
/**
* 
* @author Roger Phillips
*
* @package leioc-events-plugin
*
*/

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

// $event_details_url from Shortcode or block call

use \LEIOCevents\Api\MapsApi;
use \LEIOCevents\Blocks\EventData;

$mapApi = new MapsApi;
$mapApi->setGoogleScript();

$eventdata = new EventData;

?>
<div class="leioc-event-search-wrapper">
  <!-- Event Search page -->
  <div>
    <div class="leioc-event-search-box">

      <form class="leioc-event-search-form" method="post" action="#" data-url="<?php echo admin_url('admin-ajax.php'); ?>">
      <div>
          <select class="leioc-fixtures-search" name="leioc-fixtures-search" aria-label="Fixtures select">
              <option selected value="all">Choose...</option>
              <option value="all">All</option>
              <option value="y">LEI Events</option>
              <option value="a">Activties</option>
              <option value="m">Meetings</option>
          </select>
      </div>
        <input type="hidden" name="event_details_link" value="<?php echo $event_details_url; ?>" aria-hidden="true">
        <input type="hidden" name="action" value="leioc_event_search" aria-hidden="true"> 
        <input type="hidden" name="nonce" value="<?php echo wp_create_nonce( 'leioc_event_search_nonce' ); ?>" aria-hidden="true"> 
      </form>

    </div>

    <div class="leioc-spinner"></div>

  </div>

  <table width="100%" class="leioc-events-table">
      <tbody>
          <?php echo $eventdata->getAllEvents( array($event_details_url,'') ); ?>
      </tbody>
  </table>

  <!-- Map Modal - Based on Bootstrap Modal-->
  <div class="modal fade" id="leioc-search-map-modal" class="leioc-search-map-modal" tabindex="-1" role="dialog" aria-labelledby="leioc-search-map-title" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="leioc-modal-content">

        <div class="leioc-modal-header">
          <h5 id="leioc-search-map-title"></h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>

        <div class="leioc-modal-body">
          <div class="leioc-map" id="leioc-search-map"></div>
          <div class="leioc-map-text" id="leioc-search-map-text"></div>
        </div>

        <div class="leioc-modal-footer">
          <button type="button" data-dismiss="modal" aria-label="Close">Close</button>
        </div>

      </div>
    </div>
  </div>

</div>