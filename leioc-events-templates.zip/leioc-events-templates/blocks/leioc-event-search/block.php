<?php
/**
* 
* @author Roger Phillips
*
* @package leioc-events-plugin
*
*/

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

$option = get_option( 'leioc_events_settings' );
$event_details_url = ( isset($option['event-details-url']) ? esc_url( $option['event-details-url'] ) : get_home_url() );

use \LEIOCevents\Base\BaseController;
$base = new BaseController;

include $base->plugin_path.'blocks/leioc-event-search/templates/shortcode-shared.php';
