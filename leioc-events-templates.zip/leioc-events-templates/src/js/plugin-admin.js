import App from './modules/app.js';
import feesWpList from './modules/feesWpList.js';
import eventWpList from './modules/eventWpList.js';

const app = new App();

jQuery(document).ready(function ($) {

    handle_widget_loading();

    $(document).on('widget-updated widget-added', handle_widget_loading );
    $('.leioc-widget-toggle').on('change', function (e) {
        if($(this).is(':checked')){
            $(this).parent().prev().hide();
        } else {
            $(this).parent().prev().show();
        }
    });

    function handle_widget_loading(){
        if($('.leioc-widget-toggle').is(':checked')) {
            $('.leioc-widget-toggle').each(function (e) {
                if($(this).is(':checked')){
                    $(this).parent().prev().hide();
                } else {
                    $(this).parent().prev().show();
                }
              });
        }
    }
    
});
