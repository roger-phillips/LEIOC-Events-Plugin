(function( $ ) {
 
    $.fn.leiocEventSearch = function() {

        const form = this;
        const result = $('.leioc-events-table tbody');
        const spinner = $('.leioc-spinner');

        spinner.show();

        let url = form.data('url');
        let params = new FormData(form[0]);

        const fail = '<tr><td style="text-align:center">Sorry no events listed in the database.</td></tr>';

        fetch(url, {
            method: 'POST',
            body: params
        }).then(res => res.json())
            .catch(error => {
                result.html(fail);
                spinner.hide();
            })
            .then(response => {

                if(response === 0 || response.status === 'error'){
                    result.html(fail);
                    spinner.hide();
                    return;
                }

                result.html(response.result);
                spinner.hide();
            });
    
 
        return this;
 
    };
 
})( jQuery );