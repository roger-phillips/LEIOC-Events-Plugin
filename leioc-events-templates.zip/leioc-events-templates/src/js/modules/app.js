class App {
    constructor() {
        window.addEventListener('load', (event) => this.listeners() );
    }

    listeners(){
        const tabs = document.querySelectorAll( 'ul.leioc-nav-tabs > li' );
		tabs.forEach( el => {
			el.addEventListener( 'click', this.switchTabs );
        } );
        
        return tabs;
    }

    switchTabs(event){
        event.preventDefault();

        document.querySelector('ul.leioc-nav-tabs li.active').classList.remove('active');
        document.querySelector('.tab-pane.active').classList.remove('active');

        const clickedTab = event.currentTarget;
        const anchor = event.target;
        const activePaneId = anchor.getAttribute('href');
        
        clickedTab.classList.add('active');
        document.querySelector(activePaneId).classList.add('active'); 
    }
    
}

export default App;