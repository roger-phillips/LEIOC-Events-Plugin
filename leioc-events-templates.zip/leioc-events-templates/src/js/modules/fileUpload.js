(function( $ ) {
 
    $.fn.leiocFileUpload = function( link ) {

        let returnPath = '' || link;
        const form = this;
        const result = this.parent('div').find('.leioc-event-form-result');

        const url = form.data('url');
        const params = new FormData($(this)[0]);

        result.empty();

        const fail = '<div class="alert alert-danger alert-dismissible fade show" role="alert"><strong>There was an error uploading the file, please try again!</strong><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>';

        form.find('.leioc-file-upload-btn').prop('disabled', true);

        fetch(url, {
            method: 'POST',
            body: params
        }).then(res => res.json())
            .catch(error => {
                $(result).html(fail);
                form.find('.leioc-file-upload-btn').prop('disabled', false);
            })
            .then(response => {
            
                if(response === 0 || response.status === 'error'){
                    $(result).html(fail);
                    form.find('.leioc-file-upload-btn').prop('disabled', false);
                    return;
                }
            
                $(result).html('<div class="alert alert-success alert-dismissible fade show" role="alert"><strong>Success! </strong>'+response.msg+'<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
            
                form.find('.leioc-file-upload-btn').prop('disabled', true);

                if(form.parents().hasClass('modal-body')  && returnPath != '') $(returnPath).val(response.filepath);
            });
 
        return this;
 
    };
 
}( jQuery ));