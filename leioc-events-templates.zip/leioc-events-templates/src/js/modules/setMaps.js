import MapApi from './mapApi.js';

class SetMaps{

    constructor(){

        this.listeners();
        return;
    }

    listeners(){
        const modal = document.querySelectorAll( '[data-target]' );
        this.mapWrapper = document.querySelectorAll('.leioc-event-map-wrapper');

		modal.forEach( el => {
			el.addEventListener( 'click', this.setModal);
        } );

        this.mapWrapper.forEach( el => {
            let mapId = '#' + el.id;

            let mapData = JSON.parse(el.getAttribute('data-map') );

            this.map = new MapApi(mapId,mapData); 
        } );
        
        return;
    }

    setModal(event){
        this.button = event.currentTarget;

        this.target = this.button.getAttribute('data-target');
        if(this.target != '#leioc-search-map-modal') return;

        this.eventTitle = this.button.getAttribute('data-title'); // Extract info from data-* attributes

        this.modal = document.querySelector( this.target );
        this.modal.querySelector('#leioc-search-map-title').innerText = this.eventTitle;

        let mapData = JSON.parse(this.button.getAttribute('data-map') );

        this.map = new MapApi(this.target,mapData);

        return;
    }

}

export default SetMaps;