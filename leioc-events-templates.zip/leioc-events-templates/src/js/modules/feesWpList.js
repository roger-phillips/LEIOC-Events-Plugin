jQuery(document).ready(function($){

    feesWpList();
    function feesWpList(){
        const wp_table = '#leioc_event_fees';

        //Submit Event Fees
        $('#leioc-event-fees').on('submit', function(e){
            e.preventDefault();
            let form = $(this);

            form.find('.field-msg').hide();
            form.find('.js-form-submission').show();

            $.ajax({
                type: "post",
                dataType: "json",
                url: form.data('url'),
                data: $(form).serialize(),
                success: function(response){
                    form.find('.field-msg').hide();
                    //Resets error message
                    $('.js-form-error').text('There was a problem with the form, please try again!');

                    if (response === 0 || response.status === 'error') {
                        form.find('.js-form-error').show();
                        return;
                    }
                    ajaxWPList();
                    resetForm(form);
                    form.find('.js-form-success').text(response.data).show();
                },
                error: function(response){
                        form.find('.field-msg').hide();
                        form.find('.js-form-error').show();
                }
            });
        });

        $('#reset_event').on('click', function(e){
            resetForm( $(this).closest('form') );
        });

        //Clears hidden fields on form reset
        function resetForm(form, msg = true){
            //Use this method to avoid reseting hidden Nonce and Action fields
            let hidden = ['id', 'fee_trash'];
            if( msg == true ) $(form).closest('.tab-pane').find('.field-msg').hide();
            //Reset Hidden fields
            $.each(hidden, function(i, val){
                form.find('input[name="' + val + '"]').val('');
            })
            form.trigger('reset');
        }

        //Ajax Edit Event data
        $(wp_table).on('click','button[name="edit_fee[]"]',function(e){

            $(wp_table).find('.field-msg').hide();

            const id = $(this).val(),
                  entry = getFormData(wp_table) + '&edit_fee=' + id;

                  $.ajax({
                    type: "post",
                    dataType: "json",
                    url: $(wp_table).data('url'),
                    data: entry,
                    success: function(response){
                        $(wp_table + ' .field-msg').hide();
                        const data = response.data;
                        $.each(data, function(key,value){

                            //Sets Time & Date input values
                            let regexp = /([01][0-9]|[02][0-3]):[0-5][0-9]/;
                            if( regexp.test( value ) == true ){
                                //Adds T to set Times
                                value = value.replace(' ','T');

                                $('input[name="' + key + '"').val( value );
                                return;
                            }
                            
                            $('input[name="' + key + '"').val(value);
                            $('select[name="' + key + '"').val(value);
                            $('textarea[name="' + key + '"').val(value);
                            
                            //Sets Checkboxs if database contains true or 1 value
                            if(value == false || value == true || value == 1 || value == 0){
                                value = ( value == true ? true : ( value == 1 ? true : false) );
                                $('input[name="' + key + '"').prop('checked', value);
                                return;
                            }
                        });
    
                        $("ul.leioc-nav-tabs li.active").removeClass('active');
                        $(".tab-pane.active").removeClass('active');
                        $('a[href="#tab-2"]').parent('li').addClass('active');
                        $('#tab-2').addClass('active');
                        $('.field-msg').hide();
                    },
                    error: function(response){
                        $(wp_table).find('.field-msg').hide();
                        $(wp_table).find('.js-database-error').show();
                    }
                });
        });

        //Ajax WP_list Table
        $(wp_table).on('submit', function(e){
            e.preventDefault();
            ajaxWPList();
        });

        // Pagination links, sortable link
        $(wp_table).on('click', '.tablenav-pages a, .manage-column.sortable a, .manage-column.sorted a',function(e) {
            // We don't want to actually follow these links
            e.preventDefault();

            let str = this.search.substring( 1 ),
                order = query( str, 'order' ) || 'desc',
                orderby = query( str, 'orderby' ) || 'form_date';

            $('input[name=order]').val( order );
            $('input[name=orderby]').val( orderby );

            addNum( $(this) );
            ajaxWPList();
        });

        //Publish & Draft links
        $(wp_table).on('click','li.publish a, li.draft a',function(e){
            e.preventDefault();

            let str = this.search.substring( 1 ),
                status = query( str, 'status' ) || 1;

            $('input[name=status]').val( status );

            addNum( $(this) );
            ajaxWPList();
        });

        $(wp_table).on('click','#search-submit', function(e){
            if( $(this).prev('input').val().length > 0 )
                $(wp_table + ' #current-page-selector').val(1);
        });

        //Gets WP_LIST_Table entries data
        function ajaxWPList(){
            const form = $(wp_table),
                  wp_list = getFormData(wp_table);

            $.ajax({
                type: "post",
                dataType: "json",
                url: form.data('url'),
                data: wp_list,
                success: function(response){
                    form.find('.field-msg').hide();
        
                    if (response === 0 || response.status === 'error') {
                        form.find('.js-database-error').show();
                        return;
                    }

                    // Add the requested rows
                    if ( response.data.rows.length )
                        form.find(' #the-list').html( response.data.rows );
                    // Update column headers for sorting
                    if ( response.data.column_headers.length )
                        form.find(' thead tr, tfoot tr').html( response.data.column_headers );
                    //Update pagination for navigation
                    if ( response.data.pagination.bottom.length )
                        form.find(' .tablenav.top .tablenav-pages').html( $(response.data.pagination.top).html() );
                    if ( response.data.pagination.top.length )
                        form.find(' .tablenav.bottom .tablenav-pages').html( $(response.data.pagination.bottom).html() );
                    //Sets pagination for one page
                    form.find(' .tablenav-pages').removeClass('one-page no-pages');
                    if ( response.data.one_page.length )
                        form.find(' .tablenav-pages').addClass( response.data.one_page );
                    //Update Search box
                    form.find('.search-box').hide();
                    if ( response.data.count != 0 ){
                        if( !form.find('.search-box').length )
                            form.find('.subsubsub').after('<p class="search-box"></p>');
                        form.find('.search-box').show();
                        form.find('.search-box').replaceWith( response.data.search );
                    }
                    //Update bulk actions
                    form.find(' .alignleft.actions.bulkactions').hide();
                    if ( response.data.count != 0 ){
                        form.find('.tablenav.top .alignleft.actions.bulkactions').show();
                        if ( response.data.bulk_actions_top.length ){
                            let bulk = '<div class="alignleft actions bulkactions">' + response.data.bulk_actions_top + '</div>';
                            if( !form.find(' .alignleft.actions.bulkactions').length ){
                                form.find(' .tablenav.top').prepend(bulk);
                            } else {
                                form.find(' .tablenav.top .alignleft.actions.bulkactions').replaceWith(bulk);
                            }
                        }
                        if ( response.data.bulk_actions_bottom.length ){
                            let bulk = '<div class="alignleft actions bulkactions">' + response.data.bulk_actions_bottom + '</div>';
                            if( !form.find('.tablenav.bottom .alignleft.actions.bulkactions').length ){
                                form.find('.tablenav.bottom').prepend(bulk);
                            } else {
                                form.find('.tablenav.bottom .alignleft.actions.bulkactions').replaceWith(bulk);
                            }
                        }
                           
                    }
                    //Update Sub menu
                    if( response.data.sub_menu.length )
                        form.find('.subsubsub').replaceWith( response.data.sub_menu );  
                },
                error: function(response){
                    form.find('.field-msg').hide();
                    form.find('.js-database-error').show();
                }
            });
        };

        function getFormData(form){
            const action = '&action=' + $(form + ' input[name=ajax_action').val();

            $(form + ' .field-msg').hide();
            $(form + ' .js-database-submission').show();
    
            let wp_list = $(form).serialize();
            //Action3 need to replace action for Ajax Action
            let str = wp_list + "&action3=" + $('select[name=action]').val();
            wp_list = (str.indexOf('&action=') !== -1 ?  str.replace(/&action=(.*?)&/gi,action+'&') : str += action);

            return wp_list;
        }

        //Corrects page number for Searches
        function addNum(e){
            let num = 1
            if($(e).prop('href').indexOf('paged=') != -1){
                const page = $(e).prop('href').split(/paged/gi)[1].replace(/[^0-9]/g,'');
                num = page;
            }
            $('#leioc_events_fees_id #current-page-selector').val(num);
            return;
        };

        //Gets query from URL
        function query( query, variable ) {
 
            var vars = query.split("&");
            for ( var i = 0; i <vars.length; i++ ) {
                var pair = vars[ i ].split("=");
                if ( pair[0] == variable )
                    return pair[1];
            }
            return false;
        }
    }

});

