/**
 * MapApi
 * Class to load google maps 
 * 
 */

class MapApi {

    constructor(mapId, mapdata) {

        if(!mapdata || !mapdata.lat || !mapdata.lng || !mapId) return;

        let mapTarget = mapId.split('-').slice(0, -1).join('-');

        let mapText = '<i class=\"fas fa-globe\"></i>' + '('+ mapdata.lat +' , '+ mapdata.lng +')';
        
        document.querySelector(mapTarget+'-text').innerHTML = mapText;

        this.mapInit(mapTarget, mapdata);

        return;
    }

    mapInit(mapId, data){

        const googleDefined = (callback) => typeof google !== 'undefined' ? callback() : setTimeout(() => googleDefined(callback), 100)

        googleDefined(() => {
            // init map

            let zoom = data.zoom ? parseFloat(data.zoom) : 15;
            let title = data.title ? data.title : 'LEI Event Location';

            mapId = mapId || '#leioc-event-map';
          
            let myLatLng = {lat: parseFloat(data.lat), lng: parseFloat(data.lng)};

            let map = new google.maps.Map(document.querySelector(mapId),
                {
                    center: myLatLng,
                    zoom: zoom,
                    gestureHandling: 'cooperative'
                });
            //The marker, positioned at default of Leicester
            let marker = new google.maps.Marker(
                {
                    position: myLatLng, 
                    map: map,
                    title: title,
                });

            return map;
        });
    }
    
}

export default MapApi;