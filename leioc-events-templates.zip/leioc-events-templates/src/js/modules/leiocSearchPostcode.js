(function( $ ) {
 
    $.fn.leiocSearchPostcode = function() {

        const form = this;
        const result = this.parent('div').find('.leioc-event-form-result');

        form.find('.leioc-searching').show();

        let url = form.data('url');
        let params = new FormData(form[0]);

        result.empty();

        const fail = 'Sorry no match found in the database.';

        fetch(url, {
            method: 'POST',
            body: params
        }).then(res => res.json())
            .catch(error => {
                result.html(fail);
                form.find('.leioc-searching').hide();
            })
            .then(response => {

                form.find('.leioc-searching').hide();

                if(response === 0 || response.status === 'error'){
                    result.html(fail);
                    return;
                }

                let table = displayPostcode(response);
                result.html(table);

            });

            function displayPostcode(response){

                let rows ='<small class="text-muted">Click on row to add postcode to event form</small><br><table><tbody>';
                
                response.forEach( function(e){
            
                    rows += '<tr data-postcode="'+e.event_postcode+'" data-grid="'+e.event_cp_grid+'" data-desc="'+e.event_cp_desc+'"><td><strong>Event:</strong> '+e.event_title + '</td><td><strong>Postcode:</strong> '+e.event_postcode+' <strong>Grid Ref:</strong> '+e.event_cp_grid+' <strong>Car Park:</strong> '+e.event_cp_desc+'</td></tr>';
            
                });
            
                rows += '</tbody></table>'
            
                return rows;
            }
    
 
        return this;
 
    };
 
})( jQuery );