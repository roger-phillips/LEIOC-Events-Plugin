(function( $ ) {
 
    $.fn.leiocResultSearch = function() {

        const form = this;
        const result = $('.leioc-results-block');
        const spinner = $('.leioc-spinner');

        spinner.show();

        let url = form.data('url');
        let params = new FormData(form[0]);

        const fail = '<table><tbody><tr><td style="text-align:center">Sorry no results listed in the database.</td></tr></tbody></table>';

        fetch(url, {
            method: 'POST',
            body: params
        }).then(res => res.json())
            .catch(error => {
                result.html(fail);
                spinner.hide();
            })
            .then(response => {

                if(response === 0 || response.status === 'error'){
                    result.html(fail);
                    spinner.hide();
                    return;
                }

                $('div.leioc-title').text(response.year);
                result.html(response.result);
                insertUrlParam('item', response.year);
                spinner.hide();
            });
    
 
        return this;
 
    };

    function insertUrlParam(key, value) {
        if (history.pushState) {
            let searchParams = new URLSearchParams(window.location.search);
            searchParams.set(key, value);
            let newurl = window.location.protocol + "//" + window.location.host + window.location.pathname + '?' + searchParams.toString();
            window.history.pushState({path: newurl}, '', newurl);
        }
    }
 
})( jQuery );