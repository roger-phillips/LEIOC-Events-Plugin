class ClearForm{

    constructor(form) {
        this.form = form;

        this.reset();
        
    }

    reset(){

        const input = document.querySelectorAll(this.form+' input, select, textarea');

        input.forEach(el => {

            if(el.type == 'checkbox' || el.type == 'radio'){

                el.removeAttribute('checked');
                el.checked = false;

            } else {
                if(el.type == 'submit' || el.type == 'button'|| el.type == 'reset' || el.type == 'hidden') return;

                if(el.type == 'select-one') {
                    el.value = ''; 
                    return;
                }

                if(el.type == 'textarea') {
                    el.innerHTML = ''; 
                    el.value = '';
                    return;
                }
             
                el.setAttribute('value','');
                el.value = '';
                
            }
        });
        
    }


}

export default ClearForm;