import App from './modules/app.js';
import SetMaps from './modules/setMaps.js';
import ClearForm from './modules/clearForm.js';
import leiocFileUpload from './modules/fileUpload';
import leiocEventSearch from './modules/leiocEventSearch';
import leiocResultSearch from './modules/leiocResultSearch';
import leiocSearchPostcode from './modules/leiocSearchPostcode';
import bsCustomFileInput from 'bs-custom-file-input';
import bs_modal from './modules/bootstrap.bundle';

new App();

jQuery(document).ready(function ($) {
    bsCustomFileInput.init();
    new SetMaps();

	$('.leioc-results-widget-toggler, .leioc-events-form-toggler').on('click', function(e){
        e.preventDefault();
        $($(this).data('leioctarget')).slideToggle();
    });

    $('.leioc-ui-toggle.other').on('change', function(e) { 
        let div = $(this).next('div.other-hide, div.other-show');
        $(this).children('input').is(':checked') ? div.slideDown('slow') : div.slideUp('slow');
    });

    //Event Admin Form functions
    $('.leioc-group').on('change', function(e) {
        const selected = $(this).children('input');
        const group = 'input[name="'+$(this).children('input').prop('name')+'"]';

        if(selected.val().toLowerCase() != 'other') $('.other '+group).parent('div').next('div.other-hide, div.other-show').slideUp('slow');;

        $(group).each( function(i) {
            if ($(this).prop('id') !== selected.prop('id')) $(this).prop( 'checked', false );
        });   
    });

    $('#leioc-events-admin-wrapper leioc.nav-tabs li').on('click', function(){
        $('div.alert').alert('close');
    })

    $('#event_siac').on('change', function(e) {
        if($(this).is(':checked')) {
            $('input[name="event_si[]"]').prop('checked', false);
            $('#si_yes').prop('checked', true)
        };
    });

    $('.leioc-admin-reset').on('click', function() {
        const formid = $(this).next('form').prop('id');

        new ClearForm('#'+formid);
        $(this).val('Clear Form');
        $('.leioc-admin-form-title').text('Add New Event');
        $('#form-tab').text('Add New Event');
    })

    $('.set-default-courses').on('change', function() {
        const id = $(this).prop('id');
        if(id == 'course_all_colours' && $(this).is(':checked') ) {
            const colours = 'input[id="course_white"],'+
                            'input[id="course_yellow"],'+
                            'input[id="course_orange"],'+
                            'input[id="course_light_gr"],'+
                            'input[id="course_short_gr"],'+
                            'input[id="course_green"],'+
                            'input[id="course_blue"],'+
                            'input[id="course_brown"]';

            $(colours).prop('checked',true);
        }
        if(id == 'course_all_d' && $(this).is(':checked') ) {
            $('input[id="course_short"], input[id="course_medium"], input[id="course_long"]').prop('checked', true);
        }
    });

    //Results File Uploader
    $('#leioc-result-form-upload, #leioc-result-form-upload-modal').on('submit', function(e) {
        e.preventDefault();
        const folder = $('input[name="leioc-result-folder"]').val().trim();
        //validate form
        if(folder != '' && !folder.endsWith('/')){
            alert('Folder destination needs to end with a single forward /');
            return;
        }

        $(this).leiocFileUpload('#res_link');
    });

    $('#leioc-result-upload').on('change',function(){
        const files = $(this)[0].files;
        const choice = $('#leioc-result-filechoice');

        choice.empty();

        let chkbox = '<input type="hidden" value="0" name="file_choice">';

        if(files.length > 1) {
            chkbox = '';
            chkbox = '<label class="leioc-form-label">Select the result file</label>';
            for(var i = 0; i < files.length; i++){
                chkbox += '<div class="form-check"><input type="radio" class="form-check-input" id="filename'+i+'" name="file_choice" value="'+i+'" ';
                if(i == 0) chkbox += 'checked';
                chkbox += '><label class="form-check-label" for="filename'+i+'">'+files[i].name+'</label></div>';
            }
        }

        choice.html(chkbox);
    })

    //Postcode Search & Event File Uploader functions
    $('#eventsModal').on('show.bs.modal', function(event) {
        let button = $(event.relatedTarget);
        let title = button.data('title');

        let id = button.prop('id');

        let modal = $(this);
        modal.find('.modal-body .leioc-event-form-result').empty();
        modal.find('.modal-body #leioc-modal-upload, .modal-body #leioc-modal-search').hide();
        modal.find('.leioc-searching').hide();

        modal.find('.modal-title').text(title);
        if(id == 'event-details-modal-btn'){
            modal.find('.modal-body #leioc-modal-upload').show();
        }

        if(id == 'event-search-modal-btn'){
            modal.find('.modal-body #leioc-modal-search').show();
            $('#leioc_cp_search').val('');
        }
    });
    
    $('#leioc-event-form-search-modal').on('submit', function(e){
        e.preventDefault();
    });

    $('#leioc_cp_search').on('keyup',function() {
        if($(this).val() == '' ) return;
        $('#leioc-event-form-search-modal').leiocSearchPostcode();
    });

    $('#leioc-modal-search .leioc-event-form-result').on('click', 'tr', function() {
        $('#event_postcode').val($(this).data('postcode'));
        $('#event_cp_grid').val($(this).data('grid'));
        $('#event_cp_desc').val($(this).data('desc'));

        $('#eventsModal').modal('hide')
    });

    //Print Button
    $('.lei-print-btn').on('click', function(e){
        e.preventDefault();
        window.print();
    });

    //Event File Upload
    $('.leioc-event-upload').on('change', function(e) {
        const form = $(this.form);
        form.parent('div').find('.leioc-event-form-result').empty();
        if($(this).val() != '') form.find('.leioc-file-upload-btn').prop('disabled', false);
    });
    //Event File Upload
    $('.leioc-event-form-upload').on('submit', function(e) {
        e.preventDefault();
        $(this).leiocFileUpload('#event_details_link');
    });
    
    //Event search form
    $('.leioc-fixtures-search').on('change', function(e) {
        $(this).closest('form').leiocEventSearch();
    });

    //Results search form
    $('.leioc-results-pagination li a').on('click',function(e){
        let href = $(this).prop('href');
        
        if($(this).find('i').length > 0) return;
        e.preventDefault();
        
        const input = $('#leioc_result_data');
        let data = JSON.parse(input.val());
        let newYear = parseInt(href.split('\=').pop() );
        data.year = (newYear == '' ? new Date().getFullYear(): newYear);

        input.val(JSON.stringify(data));
        $('#leioc-results-search-form').leiocResultSearch();
    });
    
    $(window).on('resize', function() {
        if ($(document).width() >= 768) $('.leioc-results-widget-collapse').show();
    });
});
