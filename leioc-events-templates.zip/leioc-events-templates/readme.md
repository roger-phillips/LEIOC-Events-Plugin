#LEIOC Events Templates

This pluging requires the Block Lab plugin to operate.

Styling of this plugin requires the Bootstrap framework and Font Awesome Icons
Full list of features of the LEIOC Events Template plugin has.

* LEIOC Events Details Gutenberg Block
* LEIOC Events Search Gutenberg Block
* LEIOC Results Gutenberg Block
* LEIOC Events, Activties and Meetings Widget
* LEIOC Results Widget
* LEIOC Events & Results Admin Gutenberg Blocks
