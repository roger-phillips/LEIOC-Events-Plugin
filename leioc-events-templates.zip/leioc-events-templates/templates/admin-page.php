<?php
use LEIOCevents\Base\FeesWPListTable;
$feesTable = new FeesWPListTable;
?>

<div class="leioc-dasboard wrap">
    <h1>LEIOC Fees</h1>
    <?php settings_errors(); ?>

    <ul class="nav leioc-nav-tabs">
        <li class="active">
            <a href="#tab-1">Manage Fees</a>
        </li>
        <li>
            <a href="#tab-2">Fees</a>
        </li>
    </ul>

    <div class="tab-content">
        <div id="tab-1" class="tab-pane active">
            <div class="leioc-spacer">
                <p><i class="fas fa-info-circle"></i>Add new fees to the database using the Fees menu link.</p>
                <p>Only use the EDIT option when making minor corrections to the text. If fees are being altered, create a new fee with the Fees Menu.</p>
            </div>
            <?php $feesTable->show_table(); ?>
        </div>

        <div id="tab-2" class="tab-pane">
            <form method="post" action="#" id="leioc-event-fees" data-url="<?php echo admin_url('admin-ajax.php'); ?>">
                <?php 
                    do_settings_sections( 'leioc_fees_settings' ); 
                ?>
                <div class="leioc-btn-group">
                    <button type="submit" name="save_event" class="button button-primary">Save Changes</button>
                    <button type="button" value="reset" id="reset_event" class="button button-secondary">Reset</button>
                    <div class="leioc-msg-group">
                        <span class="field-msg js-form-submission">Submission in process, please wait&hellip;</span>
                        <span class="field-msg success js-form-success">Successfully saved, thank you!</span>
                        <span class="field-msg error js-form-error">There was a problem with the form, please try again!</span>
                    </div>
                </div>

                <input type="hidden" name="action" value="leioc_events_fees_submit">
                <input type="hidden" name="nonce" value="<?php echo wp_create_nonce("leioc-events-fees-nonce") ?>">
            </form>
        </div>

    </div>

</div>