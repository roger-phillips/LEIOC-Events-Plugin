<?php 
use LEIOCevents\Base\EventsWPListTable;
$eventsTable = new EventsWPListTable;
?>
<div class="leioc-dasboard wrap">
    <h1>LEIOC Events Database</h1>
    <?php settings_errors(); ?>

    <ul class="nav leioc-nav-tabs">
        <li class="active"><a href="#tab-1">View Events</a></li>
    </ul>

    <div class="tab-content">
        <div id="tab-1" class="tab-pane active">
            <?php $eventsTable->show_table(); ?>
        </div>
    </div>

</div>