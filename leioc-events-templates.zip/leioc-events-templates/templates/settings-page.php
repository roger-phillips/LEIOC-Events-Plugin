<div class="leioc-dasboard wrap">
    <h1>LEIOC Events Plugin Settings</h1>
    <?php settings_errors(); ?>

    <ul class="nav leioc-nav-tabs">
        <li class="active">
            <a href="#tab-1">Events</a>
        </li>
        <li>
            <a href="#tab-2">Database</a>
        </li>
        <li>
            <a href="#tab-3">Shortcodes</a>
        </li>
        <li>
            <a href="#tab-4">About</a>
        </li>
    </ul>

    <div class="tab-content">
        <div id="tab-1" class="tab-pane active">
            <form method="post" action="options.php">
                <?php 
                    settings_fields( 'leioc_events_settings_dashboard' );
                    do_settings_sections( 'leioc_events_settings' );
 
                    do_settings_sections( 'leioc_map_settings' );
                    submit_button('Save Changes','primary','leioc_settings');
                ?>
            </form>
        </div>

        <div id="tab-2" class="tab-pane">
            <form method="post" action="options.php">
                <?php 
                    settings_fields( 'leioc_database_dashboard' );
                    do_settings_sections( 'leioc_database_settings' );
                    submit_button('Save Changes','primary','leioc_database_settings');
                ?>
            </form> 
        </div>

        <div id="tab-3" class="tab-pane">
            <div>
                <h3>Event Search</h3>
                <p>Add a event search option, use the shortcode leioc-event-search .</p>
                <code class="leioc-shortcode">[leioc-event-search]</code>
            </div>
            <div>
                <h3>Results Search</h3>
                <p>Add a results search option, use the shortcode leioc-results-search.</p>
                <code class="leioc-shortcode">[leioc-results-search]</code>
                <p>To add informtaion to the results search box use the option results-info.</p>
                <code class="leioc-shortcode">[leioc-results-search results-info="Click on an event to see the results for that event."]</code>
            </div>
            <div>
                <h3>Event Details</h3>
                <p>Add a event details block, use the shortcode leioc-event-details.</p>
                <code class="leioc-shortcode">[leioc-event-details]</code>
                <p>To add a page redirect use the option redirect-url.</p>
                <code class="leioc-shortcode">[leioc-event-details redirect-url="http://www.leioc.org.uk/"]</code>
            </div>
        </div>

        <div id="tab-4" class="tab-pane">
            <h3>About this Plugin</h3>
            <h4>Requirements</h4>
            <p>This plugin will require the Genesis Custom Blocks plugin to be installed if using Gutenberg Blocks.</p>
            
            <h4>About</h4>
            <p>This plugin was written by Roger Phillips for Leicestershire Orienteering Club to use with their events and results database.</p>
            <p>The LEIOC Events plugin uses the Bootstrap framework and Font Awesome to provide a mobile first design.</p>

            <h4>License</h4>
            <p>
            This plugin is licensed under the GNU GENERAL PUBLIC LICENSE Version 3 terms and conditions. <a href="https://www.gnu.org/licenses/gpl-3.0.html">www.gnu.org/licenses/gpl-3.0.html</a>
            </p>
            <p>
            &#169; 2021 Roger Phillips
            </p>
        </div>

    </div>

</div>